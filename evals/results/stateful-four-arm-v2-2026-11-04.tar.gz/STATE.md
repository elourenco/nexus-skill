# Stateful benchmark ledger

Authorized task: execute the complete comparative benchmark and return results/receipts; no commit, push, merge, deploy or external publication.

- Initial shared branch elourenco/nexus-readme-illustration at a027f4e with extensive dirty work. Preserved; no stash/reset/pull in shared checkout.
- User steering: update from remote. Fetched origin (27 refs); selected exact origin/main 29ff9ac224ce94571320b1fbb3220e9ba078173c in /private/tmp/nexus-stateful-benchmark-20261103/remote. Initial local snapshot retained separately; no hand-merged skill used.
- Competitors Superpowers22f0b463 and Matt4ae2317d verified byte-for-byte against full-SHA archives.
- Four fixtures and private reference implementations prepared, red/green observed. Independent oracle review saved.
- Pilot baseline discovery original D11 failed only on unsupported empty visit ID rule. Independent reviewer confirmed false positive. Original oracle/failure preserved; corrected before confirmatory freeze; corrected pilot passes.
- Pilot continuity passed both-process handoff, 1 remote acceptance, no resend, fresh B validation. Two pilot deliveries/four sessions excluded from confirmatory results.
- Ruling: no arbitrary internal artifact names required; B is a freshness gate, not necessarily a behavioral regression. Data checks and observed command evidence separate.
- Confirmatory protocol frozen SHA a860530063d2e69097794915c093a2de7bce740000bd9d8a6986d7771068356d. 32 deliveries/48 CLI processes, 2 repetitions; rotating arm order, sequential.
- ACTIVE: controller/run.py confirmatory, unified exec session 56097. Do not restart completed cells. Each cell directory is created with exist_ok=False. CLI receipts are in confirmatory/*/0*/receipt.json; completed deliveries have delivery.json.
- Pending: finish matrix; deterministic grading via controller/grade.py confirmatory (safe incremental: skips existing grade dirs); independent label-masked judgment via controller/judge.py after matrix; second deterministic grade for material failures; aggregate and inspect receipts; export reproducible artifact/report to repository, narrowly append README if complete; run python3 scripts/validate.py; no commit.
- All raw /private/tmp/nexus-real-benchmark-20261103 data untouched.
- Host limitations: requested gpt-6.1-sol/medium; effective model/effort unobserved. CLI host discovery experimental disabled, docs0 loaded explicitly; no global installs changed or auth copied. Preparation/judging separate; root/subagent token usage not exposed.

## Progress update

17/32 deliveries complete, 27/48 sessions complete at last audit; first repetition complete in all four arms/scenarios. Confirmatory process still unified session 56097. Current cell discovery--superpowers--2. All completed session receipts have one turn.completed for one turn.started, no turn.failed/error events and valid cache subset. Locked input hashes unchanged.

Raw oracle failures so far: offline-sync--superpowers--1 and offline-sync--matt--1, both fail only assertion that opId differs across tenants. Second deterministic grading reproduces each. Public API may permit tenant-scoped IDs; candidates use per-tenant dedup, so raw equality is not established tenant leakage. Do NOT call these critical defects before independent blinded adjudication. pending-adjudications.json records hypotheses but must NOT be supplied as judge narrative. Frozen acceptance test stays unchanged. If adjudicated false-positive, preserve raw gate and derive separate documented diagnostic removing only unsupported field inequality, applied to ALL offline submissions; never edit original oracle or solutions.

New judgment machinery is controller/judge.py + judgment-schema.json. Run only after collection so no judging inference overlaps executor latency. It packages labels/metrics masked, pre-owner responses, migration source, continuity handoff/current validation and material failures. Includes actual stage1 stop-boundary criterion already in frozen truth/brief: summary must remain pending for session2, with any artifact layout accepted. No exact internal file names required. root controller scripts/qualitative packager are analysis tooling; immutable run.py/grade.py inputs unchanged.

After collection: deterministic grade all remaining; judge.py; inspect structured response and mapping; adjudicate material failures/source gates twice where needed; summarize raw vs adjudicated separately; export bundle (controller/export.py), JSON and docs/benchmark-stateful-2026-11-04.md; append narrow README comparison without replacing earlier benchmark. Start date local 3 Nov, current client date 4 Nov. Required validation python3 scripts/validate.py, no commit/push/merge/deploy.
