import { open, readFile, realpath, rename, rm, stat } from "node:fs/promises";
import { basename, dirname, join } from "node:path";

export type Row = { visitId: string; crewId: string };
export type State = {
  crews: { tenant: string; id: string; status: "active" | "paused" | "archived"; capacity: number }[];
  assignments: { tenant: string; visitId: string; crewId: string }[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: "applied" | "preview" | "replay" | "rejected";
  assignments: State["assignments"];
  errors: string[];
};

const object = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);
const identifier = (value: unknown): value is string => typeof value === "string";
const validRow = (value: unknown): value is Row =>
  object(value) && identifier(value.visitId) && identifier(value.crewId);
const validAssignment = (value: unknown): value is State["assignments"][number] =>
  validRow(value) && object(value) && identifier(value.tenant);
const rejected = (...errors: string[]): Result => ({ status: "rejected", assignments: [], errors });

function validState(value: unknown): value is State {
  if (!object(value) || !Array.isArray(value.crews) || !Array.isArray(value.assignments) || !object(value.uploads)) return false;
  const crews = new Set<string>();
  for (const crew of value.crews) {
    if (!object(crew) || !identifier(crew.tenant) || !identifier(crew.id) ||
        !["active", "paused", "archived"].includes(crew.status as string) ||
        typeof crew.capacity !== "number" || !Number.isSafeInteger(crew.capacity) || crew.capacity < 0) return false;
    const key = JSON.stringify([crew.tenant, crew.id]);
    if (crews.has(key)) return false;
    crews.add(key);
  }
  const visits = new Set<string>();
  for (const assignment of value.assignments) {
    if (!validAssignment(assignment) || !crews.has(JSON.stringify([assignment.tenant, assignment.crewId]))) return false;
    const key = JSON.stringify([assignment.tenant, assignment.visitId]);
    if (visits.has(key)) return false;
    visits.add(key);
  }
  return true;
}

// The supported consumer uses one Bun process. Serialize the complete transaction,
// including reads and previews, by canonical path; separate files remain independent.
const transactions = new Map<string, Promise<void>>();
async function serialized<T>(file: string, operation: () => Promise<T>): Promise<T> {
  const previous = transactions.get(file) ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>(resolve => { release = resolve; });
  transactions.set(file, current);
  await previous;
  try {
    return await operation();
  } finally {
    release();
    if (transactions.get(file) === current) transactions.delete(file);
  }
}

// Publish assignments and the replay receipt in one same-directory rename.
// Sync the staged file before publishing; power-loss directory durability and
// independent processes/writers are outside this single-process contract.
async function commit(file: string, state: State): Promise<void> {
  const temporary = join(dirname(file), `.${basename(file)}.${crypto.randomUUID()}.tmp`);
  const mode = (await stat(file)).mode & 0o777;
  const handle = await open(temporary, "wx", mode);
  try {
    await handle.writeFile(JSON.stringify(state), "utf8");
    await handle.sync();
    await handle.close();
    await rename(temporary, file);
  } finally {
    await handle.close().catch(() => {});
    await rm(temporary, { force: true }).catch(() => {});
  }
}

function evaluate(state: State, tenant: string, rows: Row[]): Result {
  const crews = new Map(state.crews.filter(c => c.tenant === tenant).map(c => [c.id, c]));
  const visits = new Map<string, string>();
  const counts = new Map<string, number>();
  for (const assignment of state.assignments) {
    if (assignment.tenant !== tenant) continue;
    visits.set(assignment.visitId, assignment.crewId);
    counts.set(assignment.crewId, (counts.get(assignment.crewId) ?? 0) + 1);
  }
  const added: State["assignments"] = [];
  const errors: string[] = [];
  rows.forEach((row, index) => {
    const crew = crews.get(row.crewId);
    const existing = visits.get(row.visitId);
    if (!crew) errors.push(`row ${index + 1}: unknown crew`);
    else if (existing !== undefined && existing !== row.crewId) errors.push(`row ${index + 1}: visit assigned to another crew`);
    else if (existing === row.crewId) return;
    else if (crew.status !== "active") errors.push(`row ${index + 1}: crew is not active`);
    else if ((counts.get(crew.id) ?? 0) >= crew.capacity) errors.push(`row ${index + 1}: crew capacity exceeded`);
    else {
      visits.set(row.visitId, crew.id);
      counts.set(crew.id, (counts.get(crew.id) ?? 0) + 1);
      added.push({ tenant, visitId: row.visitId, crewId: crew.id });
    }
  });
  return errors.length ? rejected(...errors) : { status: "preview", assignments: added, errors: [] };
}

// Existing API. Rows are untrusted JSON; identifiers retain their exact string value.
export async function importRoutes(file: string, tenant: string, uploadId: string, rows: unknown, apply: boolean): Promise<Result> {
  if (!identifier(tenant) || !identifier(uploadId) || typeof apply !== "boolean" || !Array.isArray(rows)) {
    return rejected("invalid import request: rows require string visitId and crewId");
  }
  try {
    // Snapshot before the first await so callers cannot change a queued request.
    const submitted: Row[] = [];
    for (const row of rows) {
      if (!validRow(row)) return rejected("invalid row: visitId and crewId must be strings");
      submitted.push({ visitId: row.visitId, crewId: row.crewId });
    }
    const key = JSON.stringify([tenant, uploadId]);
    const content = JSON.stringify(submitted.map(row => [row.visitId, row.crewId]));
    const canonical = await realpath(file);
    return await serialized(canonical, async () => {
      const state: unknown = JSON.parse(await readFile(canonical, "utf8"));
      if (!validState(state)) return rejected("invalid persisted state; repair is required before importing");
      if (Object.hasOwn(state.uploads, key)) {
        const previous = state.uploads[key];
        if (!object(previous) || previous.content !== content || !Array.isArray(previous.assignments) ||
            !previous.assignments.every(item => validAssignment(item) && item.tenant === tenant)) {
          return rejected("upload identity already exists with different or unreadable content");
        }
        return { status: "replay", assignments: previous.assignments, errors: [] };
      }
      const result = evaluate(state, tenant, submitted);
      if (result.status === "rejected" || !apply) return result;
      state.assignments = state.assignments.concat(result.assignments);
      state.uploads[key] = { content, assignments: result.assignments };
      await commit(canonical, state);
      return { ...result, status: "applied" };
    });
  } catch {
    return rejected("state could not be read or committed");
  }
}
