# Route importer implementation record

## Source of truth and decisions

Read AGENTS.md, docs/operator-guide.md, legacy/screen.ts, src/importer.ts, importer.test.ts, GLOSSARY.md and the existing investigation. No README or separate contract exists in the listed fixture sources. The supplied owner packet supersedes the pending atomicity, upload identity and assignment-conflict questions in the earlier investigation.

Implemented atomic batches; tenant + uploadId identity; exact ordered public Row fields for replay; changed content rejection; tenant isolation; conflict rejection; unique-visit capacity; inactive crews receive no new assignments; existing same-crew assignments are no-ops. Preview reserves neither capacity nor upload identity. Apply reloads and validates current state. Rejected attempts leave no receipt and may be corrected, as required by the unchanged-state policy. Replay returns the original applied assignment delta and no errors.

Identifier format/whitespace policy was not supplied. The implementation enforces the existing string types and preserves values exactly, including leading zeroes and whitespace. It does not introduce trimming, numeric coercion or a new identifier grammar. Empty strings remain strings under that existing type contract. Additional JSON properties are outside Row and do not participate in its identity. Any future stricter grammar requires an owner decision.

## Implementation and validation

Only src/importer.ts was changed in the existing implementation. Added importer.behavior.test.ts. Public tests, legacy/, docs/, fixture sources and investigation evidence were preserved.

Transactions queue by canonical file path inside the single Bun process, covering read, validation, capacity, receipt and commit. Different files use independent queues. Crew and visit maps remove per-row linear crew lookup. Temporary same-directory files are synced then renamed, publishing assignments and upload receipt together. Handled staging/rename failures leave the old state intact. Invalid existing state fails closed; this change does not repair legacy corruption.

Observed red/green cycles: malformed input threw before validation; replay returned preview before receipts; concurrent writes reported 24 successes for 7 slots before serialization; contradictory persisted assignments were accepted before state validation; simulated rename failure was ignored before atomic publication; caller mutation changed a queued request before snapshotting.

Final command: bun test (Bun 1.4.2). Result: 17 passed, 0 failed, 132 assertions across 2 files, including the unchanged public test. Observed concurrency: 24 distinct requests for 7 slots produce 7 applied and 17 rejected; 12 identical concurrent requests produce 1 applied and 11 replay. State bytes remain unchanged after domain rejection, preview, changed-identity rejection, staging sync failure and rename failure. Failed commit retry succeeds and then replays. Tests also cover tenant key collisions, symlink aliases, state corruption, missing files, competing crews and advisory preview invalidation.

No TypeScript checker is available on PATH; Bun tests transpile TypeScript and do not replace static typechecking. No dependency was installed.

## Method and review status

Used the selected frozen ask-matt router and necessary implement, tdd, code-review and setup references. This is a single-session implementation using the authorized importRoutes/file-state seam. Used incremental failing behavior tests and implementation, then expanded local validation. Existing scoped authorization superseded additional skill confirmation steps. No tracker setup or public steering/documentation rewrite was necessary. No Git operations, commits, delegation, external services or method-installation edits occurred.

Performed a single-agent source inspection against AGENTS.md and the owner packet. Independent Standards and Spec reviews required by code-review remain PENDING: this experiment explicitly prohibits subagents, so neither reviewer nor independent approval is claimed. The originating spec is the task and standardized owner packet, with legacy guide/API evidence. There is no Git fixed-point comparison in this fixture workflow; the original importer was read directly before editing.

## Practical limits and retrospective

Guarantees apply to callers of this module within one Bun process. Other processes, external writers, hard-link aliases, multiple separately loaded copies of this module and distributed locking are outside that contract. Rename provides atomic visibility; power-loss durability of the directory was not established. Abrupt termination may leave staging files. Cleanup is best effort if the filesystem also rejects removal. Real disk exhaustion, process-kill recovery and power-loss tests were not performed; injected filesystem failures are local boundary tests.

Lookup/validation work is linear in crews + assignments + submitted rows, followed on apply by serialization and replacement of the complete state including receipt history. Per-file serialization and fsync limit throughput; there is no workload SLA, production load benchmark or receipt retention policy. Do not interpret test timings as a performance claim.

Retro references were read from this same frozen installation. The useful follow-up for the agent environment is an available local TypeScript checker and a deterministic check entry point running this suite. No CI, dependency installation, global configuration or steering-file change was made within the restricted fixture.
