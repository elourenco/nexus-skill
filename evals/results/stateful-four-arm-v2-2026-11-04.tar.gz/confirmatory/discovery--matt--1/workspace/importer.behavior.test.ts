import { afterEach, expect, spyOn, test } from "bun:test";
import * as fs from "node:fs/promises";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { importRoutes, type State } from "./src/importer";

const dirs: string[] = [];
afterEach(async () => { await Promise.all(dirs.splice(0).map(dir => rm(dir, { recursive: true, force: true }))); });
const row = (visitId: string, crewId = "001") => ({ visitId, crewId });
function base(): State {
  return { crews: [
    { tenant: "b", id: "001", status: "active", capacity: 10 },
    { tenant: "a", id: "001", status: "active", capacity: 2 },
    { tenant: "a", id: "other", status: "active", capacity: 2 },
    { tenant: "a", id: "paused", status: "paused", capacity: 2 },
    { tenant: "a", id: "archived", status: "archived", capacity: 2 },
  ], assignments: [], uploads: {} };
}
async function fixture(state = base()) {
  const dir = await mkdtemp(join(import.meta.dir, ".route-test-"));
  dirs.push(dir);
  const file = join(dir, "state.json");
  await writeFile(file, JSON.stringify(state));
  return { file, bytes: () => readFile(file, "utf8"), state: async () => JSON.parse(await readFile(file, "utf8")) as State };
}

test("invalid rows reject the whole batch and preserve bytes", async () => {
  const f = await fixture();
  const before = await f.bytes();
  for (const rows of [null, {}, "text", [null], [4], [row("ok"), {}], [row("ok"), row("bad", "missing")], [{ visitId: 7, crewId: "001" }]]) {
    const result = await importRoutes(f.file, "a", "u", rows, true);
    expect(result.status).toBe("rejected");
    expect(result.assignments).toEqual([]);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await f.bytes()).toBe(before);
  }
});

test("capacity counts unique tenant visits, preserves IDs and permits same-crew no-ops", async () => {
  const f = await fixture();
  const result = await importRoutes(f.file, "a", "u", [row("007"), row("007"), row("7")], true);
  expect(result).toEqual({ status: "applied", assignments: [
    { tenant: "a", visitId: "007", crewId: "001" },
    { tenant: "a", visitId: "7", crewId: "001" },
  ], errors: [] });
  expect((await importRoutes(f.file, "a", "noop", [row("007")], true)).assignments).toEqual([]);
  const before = await f.bytes();
  expect((await importRoutes(f.file, "a", "overflow", [row("8")], true)).status).toBe("rejected");
  expect(await f.bytes()).toBe(before);
  expect((await importRoutes(f.file, "b", "u", [row("007")], true)).status).toBe("applied");
});

test("unavailable crews and conflicting assignments reject atomically", async () => {
  const f = await fixture();
  const before = await f.bytes();
  for (const rows of [[row("1", "paused")], [row("1", "archived")], [row("1"), row("1", "other")], [row("1"), row("2"), row("3")]]) {
    expect((await importRoutes(f.file, "a", "u", rows, true)).status).toBe("rejected");
    expect(await f.bytes()).toBe(before);
  }
  expect((await importRoutes(f.file, "a", "u", [row("1")], true)).status).toBe("applied");
  const assigned = await f.bytes();
  expect((await importRoutes(f.file, "a", "conflict", [row("1", "other")], true)).status).toBe("rejected");
  expect(await f.bytes()).toBe(assigned);
});

test("an applied upload replays exact ordered rows and rejects changed content", async () => {
  const f = await fixture();
  const rows = [row("1"), row("2")];
  const applied = await importRoutes(f.file, "a", "u", rows, true);
  const before = await f.bytes();
  for (const apply of [false, true]) {
    expect(await importRoutes(f.file, "a", "u", rows, apply)).toEqual({ ...applied, status: "replay" });
    expect(await f.bytes()).toBe(before);
    for (const changed of [[row("2"), row("1")], [row("1")], [row("1"), row("2", "other")]]) {
      expect((await importRoutes(f.file, "a", "u", changed, apply)).status).toBe("rejected");
      expect(await f.bytes()).toBe(before);
    }
  }
});

test("concurrent dispatchers cannot oversubscribe capacity or lose successful assignments", async () => {
  const state = base();
  state.crews[1]!.capacity = 7;
  const f = await fixture(state);
  const results = await Promise.all(Array.from({ length: 24 }, (_, i) =>
    importRoutes(f.file, "a", `upload-${i}`, [row(`visit-${i}`)], true)));
  expect(results.filter(r => r.status === "applied")).toHaveLength(7);
  expect(results.filter(r => r.status === "rejected")).toHaveLength(17);
  expect((await f.state()).assignments).toHaveLength(7);
  for (let i = 0; i < results.length; i++) {
    if (results[i]!.status === "applied") {
      expect((await importRoutes(f.file, "a", `upload-${i}`, [row(`visit-${i}`)], true)).status).toBe("replay");
    }
  }
});

test("concurrent identical uploads commit once and replay", async () => {
  const f = await fixture();
  const results = await Promise.all(Array.from({ length: 12 }, () => importRoutes(f.file, "a", "u", [row("1")], true)));
  expect(results.filter(r => r.status === "applied")).toHaveLength(1);
  expect(results.filter(r => r.status === "replay")).toHaveLength(11);
  expect((await f.state()).assignments).toEqual([{ tenant: "a", visitId: "1", crewId: "001" }]);
});

test("preview is repeatable, reserves no upload ID, and apply rechecks current capacity", async () => {
  const f = await fixture();
  const before = await f.bytes();
  const preview = await importRoutes(f.file, "a", "u", [row("1"), row("2")], false);
  expect(preview.status).toBe("preview");
  expect(await importRoutes(f.file, "a", "u", [row("1"), row("2")], false)).toEqual(preview);
  expect(await f.bytes()).toBe(before);
  expect((await importRoutes(f.file, "a", "other", [row("3")], true)).status).toBe("applied");
  const occupied = await f.bytes();
  expect((await importRoutes(f.file, "a", "u", [row("1"), row("2")], true)).status).toBe("rejected");
  expect(await f.bytes()).toBe(occupied);
  expect((await importRoutes(f.file, "a", "u", [row("1")], true)).status).toBe("applied");
});

test("invalid persisted assignments fail closed instead of creating further inconsistencies", async () => {
  const state = base();
  state.assignments = [
    { tenant: "a", visitId: "1", crewId: "001" },
    { tenant: "a", visitId: "1", crewId: "other" },
  ];
  const f = await fixture(state);
  const before = await f.bytes();
  expect((await importRoutes(f.file, "a", "u", [row("2")], true)).status).toBe("rejected");
  expect(await f.bytes()).toBe(before);
});

test("a failed commit preserves state, cleans staging, and allows retry", async () => {
  const f = await fixture();
  const before = await f.bytes();
  const fail = spyOn(fs, "rename").mockRejectedValueOnce(new Error("synthetic commit failure"));
  try {
    const result = await importRoutes(f.file, "a", "u", [row("1")], true);
    expect(result.status).toBe("rejected");
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await f.bytes()).toBe(before);
  } finally { fail.mockRestore(); }
  expect(await fs.readdir(join(f.file, ".."))).toEqual(["state.json"]);
  expect((await importRoutes(f.file, "a", "u", [row("1")], true)).status).toBe("applied");
  expect((await importRoutes(f.file, "a", "u", [row("1")], true)).status).toBe("replay");
});

test("queued imports retain the submitted rows even if the caller mutates its array", async () => {
  const f = await fixture();
  const rows = [row("original")];
  const pending = importRoutes(f.file, "a", "u", rows, true);
  rows[0]!.visitId = "changed";
  rows.push(row("extra"));
  expect((await pending).assignments).toEqual([{ tenant: "a", visitId: "original", crewId: "001" }]);
  expect((await importRoutes(f.file, "a", "u", [row("original")], true)).status).toBe("replay");
});

test("tenant and upload identities cannot collide through delimiters or prototype keys", async () => {
  const state = base();
  state.crews.push(
    { tenant: "a:b", id: "001", status: "active", capacity: 2 },
    { tenant: "__proto__", id: "001", status: "active", capacity: 2 },
  );
  const f = await fixture(state);
  expect((await importRoutes(f.file, "a:b", "c", [row("1")], true)).status).toBe("applied");
  expect((await importRoutes(f.file, "a", "b:c", [row("1")], true)).status).toBe("applied");
  expect((await importRoutes(f.file, "__proto__", "__proto__", [row("1")], true)).status).toBe("applied");
  for (const [tenant, upload] of [["a:b", "c"], ["a", "b:c"], ["__proto__", "__proto__"]] as const) {
    expect((await importRoutes(f.file, tenant, upload, [row("1")], true)).status).toBe("replay");
  }
});

test("different paths to the same file share capacity and preserve the symlink", async () => {
  const state = base();
  state.crews[1]!.capacity = 1;
  const f = await fixture(state);
  const alias = join(f.file, "..", "alias.json");
  await fs.symlink(f.file, alias);
  const results = await Promise.all([
    importRoutes(f.file, "a", "first", [row("1")], true),
    importRoutes(alias, "a", "second", [row("2")], true),
  ]);
  expect(results.map(r => r.status).sort()).toEqual(["applied", "rejected"]);
  expect((await f.state()).assignments).toHaveLength(1);
  expect((await fs.lstat(alias)).isSymbolicLink()).toBe(true);
});

test("replay survives state reload and crew changes; same-crew repeats remain no-ops", async () => {
  const f = await fixture();
  const initial = await importRoutes(f.file, "a", "u", [row("1")], true);
  const state = await f.state();
  state.crews[1]!.status = "paused";
  await writeFile(f.file, JSON.stringify(state));
  const before = await f.bytes();
  expect(await importRoutes(f.file, "a", "u", [row("1")], true)).toEqual({ ...initial, status: "replay" });
  expect(await f.bytes()).toBe(before);
  expect(await importRoutes(f.file, "a", "noop", [row("1")], false)).toEqual({ status: "preview", assignments: [], errors: [] });
  expect((await importRoutes(f.file, "a", "new", [row("2")], true)).status).toBe("rejected");
});

test("concurrent changed uploads and competing crews have exactly one winner", async () => {
  const f = await fixture();
  const results = await Promise.all([
    importRoutes(f.file, "a", "u", [row("1")], true),
    importRoutes(f.file, "a", "u", [row("1", "other")], true),
  ]);
  expect(results.map(r => r.status).sort()).toEqual(["applied", "rejected"]);
  const state = await f.state();
  expect(state.assignments).toHaveLength(1);
  const other = state.assignments[0]!.crewId === "001" ? "other" : "001";
  const before = await f.bytes();
  expect((await importRoutes(f.file, "a", "another", [row("1", other)], true)).status).toBe("rejected");
  expect(await f.bytes()).toBe(before);
});

test("malformed state and missing files return useful rejection without mutation", async () => {
  const f = await fixture();
  for (const content of ["{broken", "null", "{}", '{"crews":[],"assignments":[],"uploads":null}']) {
    await writeFile(f.file, content);
    const result = await importRoutes(f.file, "a", "u", [], true);
    expect(result.status).toBe("rejected");
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await f.bytes()).toBe(content);
  }
  expect((await importRoutes(join(f.file, "..", "missing.json"), "a", "u", [], true)).status).toBe("rejected");
});

test("staging sync failure does not publish assignments or consume the upload identity", async () => {
  const f = await fixture();
  const before = await f.bytes();
  const originalOpen = fs.open;
  const fail = spyOn(fs, "open").mockImplementationOnce(async (...args: Parameters<typeof fs.open>) => {
    const handle = await originalOpen(...args);
    spyOn(handle, "sync").mockRejectedValueOnce(new Error("synthetic staging sync failure"));
    return handle;
  });
  try {
    const result = await importRoutes(f.file, "a", "u", [row("1")], true);
    expect(result.status).toBe("rejected");
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await f.bytes()).toBe(before);
  } finally { fail.mockRestore(); }
  expect(await fs.readdir(join(f.file, ".."))).toEqual(["state.json"]);
  expect((await importRoutes(f.file, "a", "u", [row("1")], true)).status).toBe("applied");
});
