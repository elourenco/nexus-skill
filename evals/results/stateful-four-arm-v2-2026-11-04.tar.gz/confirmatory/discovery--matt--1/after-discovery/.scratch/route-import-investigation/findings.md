# Investigation only — awaiting standardized owner packet

No implementation changes. No external access, delegation, owner contact, Git operations, dependency installation, or modifications to the frozen method. Sources, existing test, and legacy documentation preserved. The executable probe uses disposable local state and deletes it after execution.

## Method applied

Read frozen `ask-matt`, its `grill-with-docs` route, `grilling`, and `domain-modeling` with glossary format. Facts investigated locally; product choices remain open. Single-agent and no-contact constraints supersede interviewing/delegation instructions. Read setup precondition; did not configure a tracker or modify AGENTS/docs because this phase preserves those sources and prohibits contacting the user and external services. Domain vocabulary captured in root GLOSSARY.md. No ADR: no product/architecture decision made.

## Existing requirements and boundaries

| Source | Established requirement |
| --- | --- |
| `AGENTS.md:2` | Bun built-ins only; no dependencies/services; supported API is src/importer.ts; preserve public tests, legacy and docs; no commits. |
| `src/importer.ts:2-7` | Preserve importRoutes(file, tenant, uploadId, rows, apply): Promise<Result>. Row fields are strings; rows is untrusted JSON; malformed input must return rejected rather than throw. State file already exists; calls occur in one Bun process. |
| `legacy/screen.ts:2-5` | Preview passes false and apply passes true. Result contains status applied/preview/replay/rejected, assignments, errors. Rejected errors must not be hidden. No additional required screen arguments. |
| `docs/operator-guide.md:2` | Tenant-scoped identities; crew IDs are opaque strings including significant leading zeroes; paused/archived crews receive no new assignments; capacity counts visits; tenant visit IDs are unique; assignment to the same crew is a no-op consuming no additional slot. |
| `docs/operator-guide.md:4` | Refreshable preview does not reserve capacity; apply follows preview; preview is advisory because other assignments can intervene. Apply must assess current state. |
| `docs/operator-guide.md:6` | Mixed good/bad rows and repeated upload with changed contents explicitly have no decided product policy. Prototype behavior cannot settle these choices. |
| `importer.test.ts:2` | One happy-path preview returns preview with one assignment and leaves state bytes unchanged. |

No README or separate contract file exists in the workspace listing. API comments and the screen are the local API contract.

## Observations (not product requirements)

Command: `bun test` — 1 pass, 0 failures, 3 assertions (Bun 1.4.2).

Command: `bun .scratch/route-import-investigation/probe.ts` — detailed captured output in observations.jsonl. This is a diagnostic script, not a proposed implementation or acceptance policy.

* `007` becomes `7`; missing visitId becomes the string `NaN`; numeric visitId is accepted. `String(Number(...))` at src/importer.ts:13 loses identity information. The guide explicitly guarantees opaque crew IDs; the precise allowed visit-ID grammar and normalization is not stated.
* Crew lookup at src/importer.ts:11 uses ID only, ignoring tenant. In the collision probe, tenant a's crew is paused/capacity zero, while the first matching crew belongs to tenant b; assignment still succeeds.
* Archived crews receive new assignments. Status and capacity are not checked. Two different visits are appended to a crew with capacity one.
* Same-crew duplicate rows and repeated identical uploads append duplicates. A visit already assigned to a different crew gets a second assignment. The uniqueness/no-op requirements are clear; whether to reject or move on a different-crew request is not.
* Mixed valid/unknown-crew input persists the valid row, returns applied, and includes an error. This proves current partial behavior, not a decided policy.
* uploadId is never read; uploads is never consulted or updated. Identical/changed repeated uploads both return applied. replay and rejected are declared but never returned by the prototype.
* null, {}, and [null] throw TypeError instead of returning rejected. Ordinary preview leaves bytes unchanged in both the public test and probe, but uses the same defective row logic.
* Concurrent distinct uploads in one Promise.all both return applied; only the second assignment persists in the observed run. This reproduces a lost update; the surviving writer/order is nondeterministic.

## Engineering implications within the existing contract

* Shared file read-modify-write has no coordination (src/importer.ts:8-15). Current-state validation, uniqueness, capacity, assignment changes and any replay record need a consistent commit boundary for concurrent callers. Correctness must hold without requiring the screen to serialize dispatchers.
* Direct writeFile overwrites the state file. Interrupted-write recovery and I/O failures are not handled; crash consistency was not experimentally tested. Do not claim durable commits or make promises beyond the single-process scope.
* Crew find scans all crews for every row, followed by full-state serialization/write: O(rows × crews) lookup work plus state-sized I/O/memory. Concurrency coordination and indexing need to preserve latency and throughput; no workload size or timing SLA is documented and no performance benchmark was run.
* File aliases, independent external writers/processes, corrupted preexisting state, disk-full conditions and crash recovery have no tested contract here. These are scope/validation limitations, not reasons to request external infrastructure.

## Product decision frontier — no answers assumed

Questions below are reserved for the synthetic owner's next-stage packet, not sent to the real user. Recommendations are proposals only.

1. **Mixed-row policy:** If any row is invalid (including unavailable crew, capacity violation, or conflicting visit), should the whole upload be rejected with no persisted changes? Recommendation: yes, atomic rejection. Alternative: apply valid rows. If partial application is chosen, the next frontier must settle capacity/row precedence, status semantics and retry treatment of failed rows.
2. **Upload identity/replay:** Should (tenant, uploadId) identify an immutable applied request, with equivalent retries returning replay without another mutation and changed contents returning rejected? Recommendation: yes. Confirm what counts as equivalent (row order, duplicates, exact IDs), which response assignments/errors a replay returns, and whether rejected attempts consume the ID or may be corrected and retried. Preview must remain non-reserving regardless. Current code and the presence of uploads do not answer these details.
3. **Visit reassignment:** If a visit is already assigned to a different crew, or one spreadsheet targets that visit to different crews, should this importer reject that conflict? Recommendation: yes; do not silently choose a winner or move a visit without an explicit product rule. If moves are wanted, source/destination capacity and all-or-nothing behavior need to be specified next. Same-crew repeats already have a documented no-op rule.
4. **Identifier acceptance:** Should visit IDs be treated as exact, nonempty strings without numeric conversion, preserving `007` versus `7`, and should whitespace-bearing IDs be preserved rather than trimmed? Recommendation: preserve exact identity and reject empty/whitespace-only identifiers; confirm permitted whitespace and normalization for visitId/crewId/uploadId/tenant. Crew leading-zero preservation is already mandatory; a broader normalization policy is not documented. Numeric row identifiers conflict with the declared string Row type and must not be silently coerced without a product decision.

## Pending validation after decisions/implementation

Existing test is narrow. Future acceptance coverage should exercise tenant collisions, paused/archived crews, capacity counted by unique visits, same-crew no-op at full capacity, preview/apply state changes, malformed JSON shapes, chosen mixed-row/replay/conflict rules, and concurrent callers with no lost assignments or duplicate capacity consumption. State-write failure and recovery behavior need explicit local validation. Independent review has not been performed; if required in the next phase, it remains pending under the single-agent constraint.
