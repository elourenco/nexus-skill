import { importRoutes, type State } from "../../src/importer";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { join } from "node:path";

const dir = await mkdtemp(join(import.meta.dir, "probe-state-"));
const base = (): State => ({
  crews: [
    { tenant: "b", id: "001", status: "active", capacity: 2 },
    { tenant: "a", id: "001", status: "paused", capacity: 0 },
    { tenant: "a", id: "c", status: "active", capacity: 1 },
    { tenant: "a", id: "archived", status: "archived", capacity: 2 },
  ],
  assignments: [], uploads: {},
});
let index = 0;
async function probe(name: string, rows: unknown, options: { state?: State; repeat?: boolean; apply?: boolean; changed?: unknown } = {}) {
  const file = join(dir, `${index++}.json`);
  await writeFile(file, JSON.stringify(options.state ?? base()));
  const before = await readFile(file, "utf8");
  try {
    const result = await importRoutes(file, "a", "upload", rows, options.apply ?? true);
    const next = options.repeat ? await importRoutes(file, "a", "upload", options.changed ?? rows, true) : undefined;
    const after = await readFile(file, "utf8");
    console.log(JSON.stringify({ name, result, next, changed: before !== after, state: JSON.parse(after) }));
  } catch (error) {
    console.log(JSON.stringify({ name, thrown: String(error), changed: before !== await readFile(file, "utf8") }));
  }
}
try {
  await probe("opaque visit identifier", [{ visitId: "007", crewId: "c" }]);
  await probe("tenant collision / paused / zero capacity", [{ visitId: "1", crewId: "001" }]);
  await probe("archived crew", [{ visitId: "1", crewId: "archived" }]);
  await probe("capacity exceeded", [{ visitId: "1", crewId: "c" }, { visitId: "2", crewId: "c" }]);
  await probe("duplicate visit", [{ visitId: "1", crewId: "c" }, { visitId: "1", crewId: "c" }]);
  const assigned = base();
  assigned.assignments.push({ tenant: "a", visitId: "1", crewId: "001" });
  await probe("existing visit assigned to different crew", [{ visitId: "1", crewId: "c" }], { state: assigned });
  await probe("mixed valid and unknown crew", [{ visitId: "1", crewId: "c" }, { visitId: "2", crewId: "missing" }]);
  await probe("same upload repeated", [{ visitId: "1", crewId: "c" }], { repeat: true });
  await probe("same upload changed", [{ visitId: "1", crewId: "c" }], { repeat: true, changed: [{ visitId: "2", crewId: "c" }] });
  await probe("preview", [{ visitId: "1", crewId: "c" }], { apply: false });
  for (const rows of [null, {}, [null], [{ crewId: "c" }], [{ visitId: 2, crewId: "c" }]]) {
    await probe(`malformed ${JSON.stringify(rows)}`, rows);
  }
  const file = join(dir, "concurrent.json");
  await writeFile(file, JSON.stringify(base()));
  const results = await Promise.all([
    importRoutes(file, "a", "u1", [{ visitId: "1", crewId: "c" }], true),
    importRoutes(file, "a", "u2", [{ visitId: "2", crewId: "c" }], true),
  ]);
  console.log(JSON.stringify({ name: "concurrent distinct uploads", results, persisted: await readFile(file, "utf8") }));
} finally {
  await rm(dir, { recursive: true, force: true });
}
