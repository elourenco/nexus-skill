# Route assignment

## Language

**Tenant**:
Namespace within which crew and visit identities are interpreted. Different tenants can use the same identifiers.

**Crew**:
Team receiving visit assignments, with an active, paused, or archived status and a visit capacity.

**Visit**:
Unit of work uniquely identified within a tenant and assigned to a crew.

**Assignment capacity**:
Maximum count of visits assigned to a crew; repeating an existing assignment to that crew does not consume another slot.

**Preview**:
Advisory assessment of a proposed import that reserves no capacity and may be refreshed safely.
