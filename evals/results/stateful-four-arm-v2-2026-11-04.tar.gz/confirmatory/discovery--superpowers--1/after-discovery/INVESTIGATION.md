# Route importer investigation

Investigation only. No implementation changes. Sources, legacy code and public tests were preserved. No owner interaction, external services, dependency installation, Git operations or delegation were performed.

Method: read the frozen `using-superpowers` skill, its Codex reference and `brainstorming`. Applied source-first discovery; design and implementation are deferred until the standardized owner packet. No independent review was performed; it remains pending if required in a later stage.

## Existing requirements and evidence

| Requirement | Source |
| --- | --- |
| Keep `importRoutes(file, tenant, uploadId, rows, apply): Promise<Result>` as the supported API. Screen preview passes false; apply passes true. | `AGENTS.md:2`; `src/importer.ts:7`; `legacy/screen.ts:1-3` |
| Preserve result fields `status`, `assignments`, `errors`, and status vocabulary `applied`, `preview`, `replay`, `rejected`. Rejected results must retain errors. | `src/importer.ts:4`; `legacy/screen.ts:4-5` |
| `rows` is untrusted JSON; malformed input must return rejected rather than throw. State file already exists; calls run in one Bun process. | `src/importer.ts:5-6` |
| Crew IDs are opaque strings; leading zeroes matter. Resolve crews in the requested tenant; tenants may share crew and visit IDs. | `docs/operator-guide.md:2` |
| Paused and archived crews cannot receive new assignments. Capacity counts visits, not spreadsheet rows. Visit IDs are unique within a tenant. | `docs/operator-guide.md:2` |
| A visit already assigned to the same crew is a no-op and consumes no extra slot. | `docs/operator-guide.md:2` |
| Preview is refresh-safe and does not reserve capacity. Apply must account for assignments made after preview; preview is advisory. | `docs/operator-guide.md:4` |
| Use Bun built-ins only, without dependencies or services. Preserve existing tests, legacy sources and docs; no commits. | `AGENTS.md:2` |

There is no README or separate contract file in the workspace. The API comments, legacy consumer and operator guide form the available contract.

## Observed public behavior

`bun test`: 1 passed, 0 failed, 3 expectations. The sole public test (`importer.test.ts:2`) verifies preview status, one returned assignment and byte-for-byte unchanged file content. It does not establish broader correctness.

Additional read-only-to-project probes called the public API using disposable state files under the permitted temporary directory; all temporary data was removed:

| Probe | Observed result |
| --- | --- |
| Same crew ID in tenants b and a; b first, a paused; visit `007` | Applied using the first crew match, returned visit `7`. Tenant and crew status were not checked. |
| Archived crew and active crew with capacity zero | Both accepted assignments. |
| Same visit/crew twice in one upload | Two stored assignments. |
| Known crew row plus unknown crew row | Stored the known row; returned `applied` with `unknown crew` in errors. This is prototype behavior, not a decided partial-import policy. |
| `rows = null` or `rows = [null]` | Threw TypeError rather than returning rejected. |
| Visit ID `visit-A` | Applied with stored visit ID `NaN`. This demonstrates destructive conversion; it does not establish the intended visit-ID grammar. |
| Same tenant/upload ID and identical rows applied twice | Both calls returned applied; duplicated the assignment; uploads remained empty. |
| Two concurrent applies to the same state file | Both promises resolved; only one new assignment survived. One reproduction, not a load or crash-durability test. |

Code explains these outcomes: `src/importer.ts:10-13` assumes iterable, well-formed rows, uses a tenant-blind linear crew lookup and numeric conversion, and appends unconditionally. `src/importer.ts:8,15` performs an uncoordinated read/modify/write. `uploadId` and `state.uploads` are unused. Only preview/applied statuses are emitted (`src/importer.ts:16`).

## Questions for the synthetic product owner

1. **Invalid rows / atomicity:** With a mixture of valid and invalid rows, must apply reject the entire upload with no assignments, or commit valid rows? If partial import is allowed, which existing status represents that outcome and what should preview/returned assignments show? The guide explicitly leaves this undecided (`docs/operator-guide.md:6`). Capacity failures and conflicting rows must follow a coherent version of this policy.
2. **Upload identity and replay:** What identifies a repeated upload (including tenant scope), and what happens when its contents change: reject, treat as a new import, or replace prior intent? What should identical retries return, and should corrected/rejected uploads be retryable under the same ID? Does row order matter to identity? Changed-content semantics are explicitly undecided (`docs/operator-guide.md:6`); the presence of `replay` and `uploads` alone does not define them.
3. **Visit assigned to a different crew:** Reject the conflict or permit reassignment? Apply the same rule to conflicting rows inside one spreadsheet? If moving is allowed, must source and destination capacity changes be atomic? Existing sources define same-crew no-op and tenant uniqueness, but no transfer rule (`docs/operator-guide.md:2`).
4. **Visit-ID acceptance and normalization:** Are visit IDs opaque strings as well, including significant zeroes, or a constrained numeric domain? Should numeric JSON cells, whitespace and empty identifiers be rejected or normalized? Crew IDs are already defined as opaque strings; do not reopen that rule. The `Row` type specifies strings but the guide does not settle visit-ID normalization (`src/importer.ts:2`; `docs/operator-guide.md:2`).

These questions are for the forthcoming standardized synthetic owner packet; no real user decision or authorization is being requested.

## Technical uncertainties and next-stage constraints

- Result arrays for same-crew no-ops, replays and rejected batches need a precise contract compatible with the screen; current sources only establish shape. Resolve alongside the decisions above rather than inventing success semantics.
- Same-file concurrent apply must preserve accepted work and enforce tenant visit uniqueness and capacity against current state. Preview must remain non-reserving. Exact lock/persistence design is an implementation decision, not a product preference.
- Failure recovery expectations for unreadable/corrupt state, write failures and process interruption are unspecified. Malformed `rows` rejection is explicit; it does not establish that all filesystem failures must be converted to rejected. No fault injection or crash tests were performed.
- Current crew lookup is O(rows × crews); every call parses the whole file and apply rewrites it. No volume/latency budget or throughput measurements are available. Coordination must cover the read/validate/write operation, while avoiding unnecessary contention between unrelated state files.
- Tests beyond the public preview test are temporary observations, not a persisted regression suite. Production code, public tests and legacy evidence remain unchanged.
