# Route importer design and implementation plan

**Goal:** Reliable local spreadsheet imports through the unchanged screen API.
**Architecture:** Tenant-scoped indexed validation, per-canonical-file promise queue, single atomic state replacement including upload receipt.
**Tech Stack:** TypeScript, Bun tests, built-in filesystem APIs.
**Spec:** AGENTS.md, docs/operator-guide.md, legacy/screen.ts, src/importer.ts API comments, owner packet in task.

## Design / approaches
In-place writes risk truncation and unlocked read/modify/write loses updates. A database would add an unauthorized dependency and migration. Use a same-directory temporary file and rename, serialized across read/validate/commit in the supported single process. Independent files have independent queues. Preview uses the queue but never writes.

Owner decisions: batches are atomic; identity is tenant + uploadId; identical ordered rows replay; changed rows reject; conflicts with other crews reject.

Implementation calls (not owner preferences): preserve nonempty visit and crew strings verbatim; reject non-string/empty values without coercion. No additional visit grammar or trimming. Results contain only new assignments; no-op gives an empty list; replay returns the original receipt's assignments; rejection gives an empty list and nonempty errors. Only successful apply records identity (including all-no-op/empty uploads). Preview never records identity. Filesystem/state corruption errors propagate rather than masquerading as invalid rows. Failures before rename leave original bytes intact; power-loss durability and multiple processes are out of scope.

## Global constraints
Bun built-ins only; preserve public tests, legacy, guide and fixture data. No dependencies, services, commits or delegation. Apply the existing API and status vocabulary. Existing authorization supersedes method approval gates. Artifacts live at workspace root to preserve existing docs.

## Review focus
- Malformed JSON values and empty IDs reject without throwing or state effects.
- Tenant/key delimiter collisions and prototype-like IDs remain isolated.
- Repeated visits count once; same-crew no-ops work even with paused/full crews.
- Concurrent stale previews, replay races and capacity competition preserve invariants.
- Read/parse failure does not poison the per-file queue; failed persistence must not issue a success receipt.

## Task 1: Atomic validation
Files: src/importer.ts; new importer.reliability.test.ts.
Interface: unchanged importRoutes(file,tenant,uploadId,rows,apply): Promise<Result>.
- [x] Add tests for malformed rows, tenant isolation, exact IDs, status, deduplication, capacity, conflicts and atomic rejection.
- [x] Run bun test importer.reliability.test.ts and observe missing behavior failures.
- [x] Implement input snapshots and indexed, tenant-scoped batch validation.
- [x] Run bun test; require green.

## Task 2: Replay and concurrent persistence
Files: same importer and added tests; consumes Task 1 API.
- [x] Add tests for tenant/upload identity, ordered content changes, retries, no-op receipts, concurrent capacity/conflicts/lost updates, aliases and queue recovery.
- [x] Run tests and observe missing receipt/coordination failures.
- [x] Implement canonical-path queue and atomic state/receipt publication.
- [x] Run complete bun test; inspect source against rules and report limitations.

## Execution ledger
Pre-flight: both tasks use the same public API; no interface conflicts. Native single-agent execution authorized. Git worktree/commit scripts omitted because this fixture prohibits Git initialization/commits and supplies an isolated workspace. Independent builder/final review pending under the single-agent restriction. Self-review is not independent review.
Task 1: complete — RED 19 failures; GREEN bun test 20/20, 70 assertions. No source contract changes. Task 2 now active.

Task 2: complete — initial RED 8 failures / 22 passes (task2-red.log); GREEN 31/31. Additional tenant identity coverage: final suite 32/32, 126 assertions. Snapshot/preview/recovery characterization tests already passed at Task 2 entry; these were not claimed as new RED cycles. Final type annotation and concat are behavior-preserving refactoring (concat avoids argument-count limits for large batches).

Final review: author self-review only, using the frozen code-reviewer checklist; independent review remains pending because delegation is explicitly forbidden. Checked API compatibility, tenant lookups, row order preservation, receipt collision safety, lock release on errors, atomic publication boundary, temp cleanup and same-file alias handling. No known blocking issue within the stated single-process/file contract. No minor findings deferred.

Decisions and practical costs:
- Preserve IDs verbatim; reject empty/non-string IDs. If another visit grammar is desired, the contract and tests will need a product decision; no numeric/whitespace normalization is inferred.
- Return only new assignments for first application/preview, original receipt on replay, and empty assignments plus errors on rejection. Only successful applies claim upload identity. These are implementation choices for previously unspecified result details; a different screen interpretation would require adjustment.
- Propagate filesystem/corrupt-state failures. Callers must handle rejected promises for infrastructure failures; invalid JSON rows instead return rejected results.

Observed validation: public test retained and passing; added tests cover atomic rejection, tenant isolation, opaque IDs, paused/archived crews, no-op/deduplication/capacity, conflicts, ordered replay, retries, concurrent applies, canonical aliases, caller mutation, parse failure and injected rename failure. All fixture files were disposable and cleaned by tests. No dependencies, services, Git operations, commits or agents used.

Performance/resilience limits: validation is O(crews + assignments + rows); every operation still reads/parses the full state and every successful apply serializes/syncs/renames it, including stored receipts. Same-file calls queue; independent files do not share locks. No throughput/latency budget or sustained-load measurement. No multi-process writer coordination, hard-link alias support, directory fsync/power-loss guarantee or crash testing. Abrupt termination before rename may leave an unused temporary file. Authoring tests do not replace independent review. No TypeScript static checker is installed or run; Bun tests transpile TypeScript.

Finish: files left in the authorized workspace for inspection, with no integration/publication action. The method's Git integration menu and cleanup do not apply to this non-Git, preserve-in-place fixture.
Final verification correction: a repeat run exposed a test-only ordering assumption (31 pass, 1 fail in cross-tenant identity test). Canonical-path resolution can complete in either order; the API promises isolation, not invocation-order scheduling. Sorted the persisted assignment list in this assertion; no production change. This correction avoids requiring deterministic scheduling from concurrent independent requests.
