import { readFile, realpath, open, rename, unlink, stat } from "node:fs/promises";
import { randomUUID } from "node:crypto";

export type Row = { visitId: string; crewId: string };
export type State = {
  crews: { tenant: string; id: string; status: "active" | "paused" | "archived"; capacity: number }[];
  assignments: { tenant: string; visitId: string; crewId: string }[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: "applied" | "preview" | "replay" | "rejected";
  assignments: State["assignments"];
  errors: string[];
};

function rejected(errors: string[]): Result {
  return { status: "rejected", assignments: [], errors };
}

// Copy untrusted JSON before any await: callers cannot change queued intent.
function snapshot(rows: unknown): Row[] | undefined {
  if (!Array.isArray(rows)) return;
  const copy: Row[] = [];
  for (const value of rows) {
    if (!value || typeof value !== "object" || Array.isArray(value) ||
        typeof value.visitId !== "string" || value.visitId.length === 0 ||
        typeof value.crewId !== "string" || value.crewId.length === 0) return;
    copy.push({ visitId: value.visitId, crewId: value.crewId });
  }
  return copy;
}

function plan(state: State, tenant: string, rows: Row[]): Result {
  const crews = new Map(state.crews.filter(c => c.tenant === tenant).map(c => [c.id, c]));
  const visits = new Map<string, string>();
  const counts = new Map<string, number>();
  for (const item of state.assignments) {
    if (item.tenant !== tenant) continue;
    if (visits.has(item.visitId)) continue;
    visits.set(item.visitId, item.crewId);
    counts.set(item.crewId, (counts.get(item.crewId) ?? 0) + 1);
  }
  const assignments: State["assignments"] = [];
  const errors: string[] = [];
  rows.forEach((row, index) => {
    const fail = (message: string) => { errors.push(`Row ${index + 1}: ${message}`); };
    const crew = crews.get(row.crewId);
    if (!crew) return fail("unknown crew in tenant");
    const assigned = visits.get(row.visitId);
    if (assigned !== undefined) {
      if (assigned !== row.crewId) fail("visit assigned to another crew");
      return;
    }
    if (crew.status !== "active") return fail("crew is not active");
    const used = counts.get(crew.id) ?? 0;
    if (!Number.isSafeInteger(crew.capacity) || crew.capacity < 0 || used >= crew.capacity) {
      return fail("crew capacity exceeded or invalid");
    }
    visits.set(row.visitId, row.crewId);
    counts.set(crew.id, used + 1);
    assignments.push({ tenant, ...row });
  });
  return errors.length ? rejected(errors) : { status: "preview", assignments, errors: [] };
}

// Only one read/validate/commit transaction per canonical path, in this process.
// Tails always resolve, so a failed transaction cannot poison later callers.
const tails = new Map<string, Promise<void>>();
async function serialized<T>(file: string, operation: () => Promise<T>): Promise<T> {
  const previous = tails.get(file) ?? Promise.resolve();
  let release!: () => void;
  const tail = new Promise<void>(resolve => { release = resolve; });
  tails.set(file, tail);
  await previous;
  try {
    return await operation();
  } finally {
    release();
    if (tails.get(file) === tail) tails.delete(file);
  }
}

async function publish(file: string, state: State): Promise<void> {
  const temporary = `${file}.${randomUUID()}.tmp`;
  const mode = (await stat(file)).mode & 0o777;
  const handle = await open(temporary, "wx", mode);
  try {
    try {
      await handle.writeFile(JSON.stringify(state), "utf8");
      await handle.sync();
    } finally {
      await handle.close();
    }
    // Receipt and assignments become visible together. No fallible work follows rename.
    await rename(temporary, file);
  } catch (error) {
    await unlink(temporary).catch(() => {});
    throw error;
  }
}

type Receipt = { rows: string; assignments: State["assignments"] };

// Existing API: state file already exists. rows is untrusted JSON; malformed input
// must return rejected, not throw. Files are used in a single Bun process.
export async function importRoutes(file: string, tenant: string, uploadId: string, rows: unknown, apply: boolean): Promise<Result> {
  const input = snapshot(rows);
  if (!input) return rejected(["rows must be an array of nonempty string visitId/crewId pairs"]);
  const canonical = await realpath(file);
  return serialized(canonical, async (): Promise<Result> => {
    const state: State = JSON.parse(await readFile(canonical, "utf8"));
    const key = JSON.stringify([tenant, uploadId]);
    const content = JSON.stringify(input);
    if (Object.hasOwn(state.uploads, key)) {
      const receipt = state.uploads[key] as Receipt;
      if (!receipt || typeof receipt.rows !== "string" || !Array.isArray(receipt.assignments)) {
        throw new Error("Invalid upload receipt in state");
      }
      return receipt.rows === content
        ? { status: "replay", assignments: receipt.assignments, errors: [] }
        : rejected(["uploadId already applied with different ordered rows"]);
    }
    const result = plan(state, tenant, input);
    if (result.status === "rejected" || !apply) return result;
    state.assignments = state.assignments.concat(result.assignments);
    state.uploads[key] = { rows: content, assignments: result.assignments } satisfies Receipt;
    await publish(canonical, state);
    return { ...result, status: "applied" };
  });
}
