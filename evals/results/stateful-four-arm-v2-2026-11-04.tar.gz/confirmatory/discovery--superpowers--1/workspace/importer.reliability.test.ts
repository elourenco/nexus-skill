import { afterEach, expect, test } from "bun:test";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { importRoutes, type State } from "./src/importer";

const dirs: string[] = [];
afterEach(() => { for (const dir of dirs.splice(0)) rmSync(dir, { recursive: true, force: true }); });
function fixture(overrides: Partial<State> = {}) {
  const dir = mkdtempSync(join(import.meta.dir, ".routes-test-"));
  dirs.push(dir);
  const file = join(dir, "state.json");
  const state: State = { crews: [{ tenant: "a", id: "001", status: "active", capacity: 2 }], assignments: [], uploads: {}, ...overrides };
  writeFileSync(file, JSON.stringify(state));
  return { file, bytes: () => readFileSync(file, "utf8"), state: () => JSON.parse(readFileSync(file, "utf8")) as State };
}
const row = (visitId = "007", crewId = "001") => ({ visitId, crewId });

for (const rows of [null, {}, "rows", 12, [null], [[]], [{}], [{visitId: 7, crewId: "001"}], [row("", "001")], [row("7", "")], [row(), null]]) {
  test(`malformed rows reject without mutation: ${JSON.stringify(rows)}`, async () => {
    const f = fixture(); const before = f.bytes();
    const result = await importRoutes(f.file, "a", "u", rows, true);
    expect(result.status).toBe("rejected"); expect(result.errors.length).toBeGreaterThan(0);
    expect(result.assignments).toEqual([]); expect(f.bytes()).toBe(before);
  });
}

test("tenant scoped crews and exact string identifiers", async () => {
  const f = fixture({ crews: [
    {tenant:"b", id:"001", status:"paused", capacity:0},
    {tenant:"a", id:"001", status:"active", capacity:2},
  ] });
  const result = await importRoutes(f.file, "a", "u", [row("007"), row("visit-A")], true);
  expect(result.status).toBe("applied");
  expect(f.state().assignments).toEqual([{tenant:"a",visitId:"007",crewId:"001"},{tenant:"a",visitId:"visit-A",crewId:"001"}]);
});

for (const status of ["paused", "archived"] as const) {
  test(`${status} crew rejects whole batch`, async () => {
    const f = fixture({crews:[{tenant:"a",id:"001",status,capacity:10}]}); const before = f.bytes();
    expect((await importRoutes(f.file,"a","u",[row()],true)).status).toBe("rejected");
    expect(f.bytes()).toBe(before);
  });
}

test("unknown crew after valid row rejects whole batch", async () => {
  const f=fixture(); const before=f.bytes();
  const r=await importRoutes(f.file,"a","u",[row(),row("8","missing")],true);
  expect(r.status).toBe("rejected"); expect(r.errors.length).toBeGreaterThan(0); expect(r.assignments).toEqual([]); expect(f.bytes()).toBe(before);
});

test("capacity counts unique visits across existing state and batch", async () => {
  const f=fixture({assignments:[{tenant:"a",visitId:"old",crewId:"001"}]});
  const r=await importRoutes(f.file,"a","u",[row(),row()],true);
  expect(r.status).toBe("applied"); expect(r.assignments).toEqual([{tenant:"a",visitId:"007",crewId:"001"}]);
  const before=f.bytes();
  expect((await importRoutes(f.file,"a","v",[row("8")],true)).status).toBe("rejected"); expect(f.bytes()).toBe(before);
});

test("same-crew no-op allowed when paused/full and another tenant has same visit", async () => {
  const f=fixture({crews:[{tenant:"a",id:"001",status:"paused",capacity:0}],assignments:[{tenant:"a",visitId:"007",crewId:"001"},{tenant:"b",visitId:"007",crewId:"other"}]});
  const r=await importRoutes(f.file,"a","u",[row(),row()],true);
  expect(r.status).toBe("applied"); expect(r.assignments).toEqual([]); expect(f.state().assignments.length).toBe(2);
});

for (const existing of [false,true]) {
  test(`different-crew conflict is atomic, existing=${existing}`,async()=>{
    const f=fixture({crews:[{tenant:"a",id:"001",status:"active",capacity:3},{tenant:"a",id:"other",status:"active",capacity:3}],assignments:existing?[{tenant:"a",visitId:"007",crewId:"other"}]:[]});
    const before=f.bytes(); const rows=existing?[row()]:[row(),row("007","other")];
    const r=await importRoutes(f.file,"a","u",rows,true);
    expect(r.status).toBe("rejected"); expect(r.assignments).toEqual([]); expect(f.bytes()).toBe(before);
  });
}

test("identical ordered upload replays its receipt without writing; changed order rejects", async()=>{
  const f=fixture(); const rows=[row("007"),row("008")];
  const first=await importRoutes(f.file,"a","u",rows,true); const before=f.bytes();
  const replay=await importRoutes(f.file,"a","u",rows,true);
  expect(replay.status).toBe("replay"); expect(replay.assignments).toEqual(first.assignments); expect(f.bytes()).toBe(before);
  expect((await importRoutes(f.file,"a","u",[...rows].reverse(),true)).status).toBe("rejected"); expect(f.bytes()).toBe(before);
  expect((await importRoutes(f.file,"a","u",[row("new")],false)).status).toBe("rejected"); expect(f.bytes()).toBe(before);
});

test("preview reserves neither capacity nor identity; apply revalidates current state",async()=>{
  const f=fixture({crews:[{tenant:"a",id:"001",status:"active",capacity:1}]}); const before=f.bytes();
  expect((await importRoutes(f.file,"a","u",[row()],false)).status).toBe("preview");
  expect((await importRoutes(f.file,"a","u",[row()],false)).status).toBe("preview"); expect(f.bytes()).toBe(before);
  expect((await importRoutes(f.file,"a","other",[row("8")],true)).status).toBe("applied");
  const applied=f.bytes(); expect((await importRoutes(f.file,"a","u",[row()],true)).status).toBe("rejected"); expect(f.bytes()).toBe(applied);
});

test("rejected attempts do not consume upload identity; no-op and empty successful uploads do",async()=>{
  const f=fixture();
  expect((await importRoutes(f.file,"a","u",[row("7","missing")],true)).status).toBe("rejected");
  expect((await importRoutes(f.file,"a","u",[row()],true)).status).toBe("applied");
  const noop=await importRoutes(f.file,"a","noop",[row()],true); expect(noop.assignments).toEqual([]);
  expect((await importRoutes(f.file,"a","noop",[row()],true)).status).toBe("replay");
  expect((await importRoutes(f.file,"a","empty",[],true)).status).toBe("applied");
  expect((await importRoutes(f.file,"a","empty",[],true)).status).toBe("replay");
  const before=f.bytes(); expect((await importRoutes(f.file,"a","empty",[row()],true)).status).toBe("rejected"); expect(f.bytes()).toBe(before);
});

test("upload identity uses collision-free tenant/upload tuple including prototype-like names",async()=>{
  const f=fixture({crews:["a:b","a","__proto__"].map(tenant=>({tenant,id:"001",status:"active" as const,capacity:2}))});
  for (const [tenant,id] of [["a:b","c"],["a","b:c"],["__proto__","constructor"]]) {
    expect((await importRoutes(f.file,tenant!,id!,[row()],true)).status).toBe("applied");
    expect((await importRoutes(f.file,tenant!,id!,[row()],true)).status).toBe("replay");
  }
  expect(f.state().assignments.length).toBe(3);
});

test("concurrent applies preserve every accepted assignment and upload",async()=>{
  const f=fixture({crews:[{tenant:"a",id:"001",status:"active",capacity:30}]});
  const results=await Promise.all(Array.from({length:20},(_,i)=>importRoutes(f.file,"a",`u${i}`,[row(`v${i}`)],true)));
  expect(results.every(r=>r.status==="applied")).toBe(true);
  expect(f.state().assignments.length).toBe(20); expect(Object.keys(f.state().uploads).length).toBe(20);
  expect(new Set(f.state().assignments.map(a=>a.visitId)).size).toBe(20);
});

test("concurrent capacity competition admits only one and replay races produce one effect",async()=>{
  const f=fixture({crews:[{tenant:"a",id:"001",status:"active",capacity:1}]});
  const r=await Promise.all([importRoutes(f.file,"a","u",[row()],true),importRoutes(f.file,"a","v",[row("8")],true)]);
  expect(r.map(x=>x.status).sort()).toEqual(["applied","rejected"]); expect(f.state().assignments.length).toBe(1);
  const g=fixture();
  const replay=await Promise.all(Array.from({length:8},()=>importRoutes(g.file,"a","u",[row()],true)));
  expect(replay.filter(x=>x.status==="applied").length).toBe(1); expect(replay.filter(x=>x.status==="replay").length).toBe(7); expect(g.state().assignments.length).toBe(1);
});

test("concurrent same-identity changed rows reject; conflicting crews reject",async()=>{
  const f=fixture();
  const r=await Promise.all([importRoutes(f.file,"a","u",[row()],true),importRoutes(f.file,"a","u",[row("8")],true)]);
  expect(r.map(x=>x.status).sort()).toEqual(["applied","rejected"]); expect(f.state().assignments.length).toBe(1);
  const g=fixture({crews:[{tenant:"a",id:"001",status:"active",capacity:2},{tenant:"a",id:"other",status:"active",capacity:2}]});
  const conflicts=await Promise.all([importRoutes(g.file,"a","u",[row()],true),importRoutes(g.file,"a","v",[row("007","other")],true)]);
  expect(conflicts.map(x=>x.status).sort()).toEqual(["applied","rejected"]); expect(g.state().assignments.length).toBe(1);
});

test("input snapshot prevents caller mutation while waiting for IO",async()=>{
  const f=fixture(); const rows=[row()]; const pending=importRoutes(f.file,"a","u",rows,true);
  rows[0]!.visitId="changed";
  expect((await pending).assignments).toEqual([{tenant:"a",visitId:"007",crewId:"001"}]);
});

test("parse failure leaves bytes unchanged and subsequent valid call succeeds",async()=>{
  const f=fixture(); const valid=f.bytes(); writeFileSync(f.file,"{");
  await expect(importRoutes(f.file,"a","u",[row()],true)).rejects.toThrow(); expect(f.bytes()).toBe("{");
  writeFileSync(f.file,valid); expect((await importRoutes(f.file,"a","u",[row()],true)).status).toBe("applied");
});

test("canonical file aliases share serialization",async()=>{
  const {symlinkSync}=await import("node:fs");
  const f=fixture(); const alias=join(f.file,"..","alias.json"); symlinkSync(f.file,alias);
  const results=await Promise.all([importRoutes(f.file,"a","u",[row()],true),importRoutes(alias,"a","v",[row("8")],true)]);
  expect(results.map(r=>r.status)).toEqual(["applied","applied"]); expect(f.state().assignments.length).toBe(2);
  expect(readFileSync(alias,"utf8")).toBe(f.bytes());
});

test("failed atomic publication leaves state and receipt unchanged; retry succeeds",async()=>{
  const {spyOn}=await import("bun:test"); const fs=await import("node:fs/promises");
  const {readdirSync}=await import("node:fs");
  const f=fixture(); const before=f.bytes();
  // Only replace the publication syscall; parsing, validation and temp-file IO stay real.
  const rename=spyOn(fs,"rename").mockRejectedValueOnce(new Error("synthetic rename failure"));
  try {
    await expect(importRoutes(f.file,"a","u",[row()],true)).rejects.toThrow("synthetic rename failure");
    expect(f.bytes()).toBe(before); expect(readdirSync(join(f.file,"..")).sort()).toEqual(["state.json"]);
  } finally { rename.mockRestore(); }
  expect((await importRoutes(f.file,"a","u",[row()],true)).status).toBe("applied");
  expect((await importRoutes(f.file,"a","u",[row()],true)).status).toBe("replay");
});

test("the same upload and visit IDs are independent across tenants",async()=>{
  const f=fixture({crews:["a","b"].map(tenant=>({tenant,id:"001",status:"active" as const,capacity:1}))});
  const results=await Promise.all([importRoutes(f.file,"a","u",[row()],true),importRoutes(f.file,"b","u",[row()],true)]);
  expect(results.map(r=>r.status)).toEqual(["applied","applied"]);
  expect(f.state().assignments.sort((a,b)=>a.tenant.localeCompare(b.tenant))).toEqual([{tenant:"a",visitId:"007",crewId:"001"},{tenant:"b",visitId:"007",crewId:"001"}]);
  expect((await importRoutes(f.file,"b","u",[row()],true)).status).toBe("replay");
});
