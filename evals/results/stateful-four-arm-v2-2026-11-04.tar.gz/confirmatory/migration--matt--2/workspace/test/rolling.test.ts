import { expect, test } from 'bun:test';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore, putItem, readItem, migrate } from '../src/store';
import { openLegacy, legacyPut, legacyRead } from '../legacy/producer';

function withStore(run: (db: ReturnType<typeof openStore>, path: string) => void) {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-rolling-'));
  const path = join(dir, 'catalog.sqlite');
  const db = openStore(path);
  try { run(db, path); } finally { db.close(); rmSync(dir, { recursive: true, force: true }); }
}

test('old and new writers alternate without losing names or versions', () => withStore((db, path) => {
  const old = openLegacy(path);
  try {
    legacyPut(old, "id' 雪", '  Café  ');
    expect(readItem(db, "id' 雪")).toEqual({ id: "id' 雪", name: '  Café  ', version: 1 });
    expect(putItem(db, "id' 雪", 'new')).toEqual({ id: "id' 雪", name: 'new', version: 2 });
    expect(legacyRead(old, "id' 雪")).toEqual({ id: "id' 雪", name: 'new', version: 2 });
    legacyPut(old, "id' 雪", 'desktop');
    expect(readItem(db, "id' 雪")).toEqual({ id: "id' 雪", name: 'desktop', version: 3 });
    expect(putItem(db, "id' 雪", 'final').version).toBe(4);
  } finally { old.close(); }
}));

test('interruption preserves desktop data and retry catches edits behind the batch cursor', () => withStore((db, path) => {
  const old = openLegacy(path);
  try {
    for (const id of ['a', 'b', 'c']) legacyPut(old, id, `name ${id}`);
    const interruption = new Error('interrupted');
    expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => {
      expect(scanned).toBe(2);
      expect(legacyRead(old, 'a')?.name).toBe('name a');
      expect(typed(old, 'b')).toEqual({ id: 'b', name: 'name b', version: 1 });
      legacyPut(old, 'a', 'edited between batches');
      throw interruption;
    } })).toThrow(interruption);
    const reopened = openStore(path);
    try {
      const batches: number[] = [];
      expect(migrate(reopened, { batchSize: 2, afterBatch: ({ scanned }) => batches.push(scanned) }))
        .toEqual({ scanned: 3 });
      expect(batches).toEqual([2, 3]);
      expect(readItem(reopened, 'a')).toEqual({ id: 'a', name: 'edited between batches', version: 2 });
      expect(legacyRead(old, 'c')?.name).toBe('name c');
      legacyPut(old, 'b', 'after migration');
      expect(migrate(reopened).scanned).toBe(3);
      expect(readItem(reopened, 'b')?.name).toBe('after migration');
    } finally { reopened.close(); }
  } finally { old.close(); }
}));

// SQL is the documented persistence integration boundary, used here to seed
// damaged records, observe recovery units, and inject storage failures.
function typed(db: ReturnType<typeof openStore>, id: string) {
  return db.query('SELECT id,name,version FROM items WHERE id=?').get(id);
}
function rawLegacy(db: ReturnType<typeof openStore>, id: string, payload: string) {
  db.query('INSERT OR REPLACE INTO legacy_items(id,payload) VALUES(?,?)').run(id, payload);
}

test('invalid row rolls back its whole batch, keeps original bytes, and can be repaired', () => withStore(db => {
  for (const id of ['a', 'b', 'c', 'd']) legacyPut(db, id, `name ${id}`);
  const malformed = '{ "name": "broken"';
  rawLegacy(db, 'd', malformed);
  const batches: number[] = [];
  expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => batches.push(scanned) })).toThrow();
  expect(batches).toEqual([2]);
  expect(typed(db, 'a')).toEqual({ id: 'a', name: 'name a', version: 1 });
  expect(typed(db, 'c')).toBeNull();
  expect(db.query('SELECT payload FROM legacy_items WHERE id=?').get('d')).toEqual({ payload: malformed });
  rawLegacy(db, 'd', '{ "name": "repaired", "version": 1 }');
  expect(migrate(db, { batchSize: 2 })).toEqual({ scanned: 4 });
  expect(readItem(db, 'd')?.name).toBe('repaired');
}));

test('higher typed versions survive migration and equal divergent versions throw', () => withStore(db => {
  legacyPut(db, 'a', 'old');
  db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'newer', 4);
  expect(migrate(db).scanned).toBe(1);
  expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'newer', version: 4 });
  expect(putItem(db, 'a', 'published').version).toBe(5);
  expect(legacyRead(db, 'a')?.version).toBe(5);
  rawLegacy(db, 'a', '{"name":"conflicting","version":5}');
  expect(() => readItem(db, 'a')).toThrow();
  expect(() => putItem(db, 'a', 'overwrite')).toThrow();
  expect(() => migrate(db)).toThrow();
  expect(typed(db, 'a')).toEqual({ id: 'a', name: 'published', version: 5 });
}));

test('failure publishing legacy format rolls back typed writes, including new ids', () => withStore(db => {
  putItem(db, 'a', 'before');
  db.exec(`CREATE TRIGGER reject_legacy BEFORE INSERT ON legacy_items
    BEGIN SELECT RAISE(ABORT, 'storage unavailable'); END`);
  expect(() => putItem(db, 'a', 'after')).toThrow('storage unavailable');
  expect(() => putItem(db, 'b', 'new')).toThrow('storage unavailable');
  expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'before', version: 1 });
  expect(legacyRead(db, 'a')?.name).toBe('before');
  expect(readItem(db, 'b')).toBeNull();
}));

test('invalid inputs and version overflow fail without mutation', () => withStore(db => {
  for (const id of ['', null, 42]) {
    expect(() => readItem(db, id as string)).toThrow();
    expect(() => putItem(db, id as string, 'name')).toThrow();
  }
  for (const name of ['', null, 42]) expect(() => putItem(db, 'a', name as string)).toThrow();
  legacyPut(db, 'a', 'before');
  for (const batchSize of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, null, '2']) {
    expect(() => migrate(db, { batchSize: batchSize as number })).toThrow();
    expect(typed(db, 'a')).toBeNull();
  }
  rawLegacy(db, 'max', '{"name":"last","version":9007199254740991}');
  expect(() => putItem(db, 'max', 'overflow')).toThrow();
  expect(typed(db, 'max')).toBeNull();
  expect(legacyRead(db, 'max')?.name).toBe('last');
}));

test('invalid persisted items throw even when the other table has a higher valid version', () => withStore(db => {
  const bad = ['null', '[]', '{}', '{"name":"","version":1}', '{"name":42,"version":1}',
    '{"name":"n","version":0}', '{"name":"n","version":1.5}',
    '{"name":"n","version":"1"}', '{"name":"n","version":9007199254740992}'];
  db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'valid', 10);
  for (const payload of bad) {
    rawLegacy(db, 'a', payload);
    expect(() => readItem(db, 'a')).toThrow();
    expect(() => putItem(db, 'a', 'replacement')).toThrow();
    expect(() => migrate(db)).toThrow();
  }
  rawLegacy(db, 'a', '{"name":"valid","version":10}');
  db.query('UPDATE items SET version=0 WHERE id=?').run('a');
  expect(() => readItem(db, 'a')).toThrow();
  expect(() => migrate(db)).toThrow();
}));

test('default batches are bounded and callbacks include the final partial batch', () => withStore(db => {
  for (let i = 0; i < 103; i++) legacyPut(db, `id-${String(i).padStart(4, '0')}`, '雪'.repeat(1000));
  const batches: number[] = [];
  expect(migrate(db, { afterBatch: ({ scanned }) => batches.push(scanned) })).toEqual({ scanned: 103 });
  expect(batches).toEqual([50, 100, 103]);
  expect(readItem(db, 'id-0102')?.name).toBe('雪'.repeat(1000));
  expect(legacyRead(db, 'id-0000')?.name).toBe('雪'.repeat(1000));
}));

test('empty migration does not call callback', () => withStore(db => {
  expect(migrate(db, { afterBatch: () => { throw new Error('unexpected'); } })).toEqual({ scanned: 0 });
}));

test('shipped legacy-only database migrates without changing original payload bytes', () => {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-shipped-'));
  const path = join(dir, 'catalog.sqlite');
  copyFileSync(new URL('../data/legacy.sqlite', import.meta.url), path);
  const old = openLegacy(path);
  try {
    const before = old.query('SELECT id,payload FROM legacy_items ORDER BY id').all();
    const db = openStore(path);
    try {
      expect(readItem(db, 'alpha')).toEqual({ id: 'alpha', name: 'Desktop edit before upgrade', version: 2 });
      expect(migrate(db, { batchSize: 1 })).toEqual({ scanned: 4 });
      expect(old.query('SELECT id,payload FROM legacy_items ORDER BY id').all()).toEqual(before);
      expect(readItem(db, "id'with punctuation")?.name).toBe('  Keep these spaces  ');
      expect(readItem(db, 'beta')?.name).toBe('Café — São Paulo');
      expect(putItem(db, 'alpha', 'upgraded')).toEqual({ id: 'alpha', name: 'upgraded', version: 3 });
      expect(legacyRead(old, 'alpha')?.name).toBe('upgraded');
    } finally { db.close(); }
  } finally { old.close(); rmSync(dir, { recursive: true, force: true }); }
});
