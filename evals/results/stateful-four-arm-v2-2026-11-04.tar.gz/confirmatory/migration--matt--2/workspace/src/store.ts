import { Database } from 'bun:sqlite';

export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};

export function openStore(path: string): Database {
  const db = new Database(path, { create: true });
  db.exec('PRAGMA busy_timeout=1000');
  db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
  db.exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)');
  return db;
}

function nonempty(value: unknown, field: string): asserts value is string {
  if (typeof value !== 'string' || value.length === 0) throw new Error(`Invalid ${field}`);
}

function validateItem(id: unknown, name: unknown, version: unknown): Item {
  nonempty(id, 'id');
  nonempty(name, 'name');
  if (typeof version !== 'number' || !Number.isSafeInteger(version) || version <= 0) {
    throw new Error('Invalid version');
  }
  return { id, name, version };
}

function decodeLegacy(id: unknown, payload: unknown): Item {
  if (typeof payload !== 'string') throw new Error('Invalid legacy payload');
  const value: unknown = JSON.parse(payload);
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('Invalid legacy item');
  }
  const fields = value as Record<string, unknown>;
  return validateItem(id, fields.name, fields.version);
}

export function readItem(db: Database, id: string): Item | null {
  nonempty(id, 'id');
  // One statement observes both representations in the same SQLite snapshot.
  const rows = db.query(`
    SELECT id, name, version, NULL AS payload, 0 AS legacy FROM items WHERE id = ?
    UNION ALL
    SELECT id, NULL, NULL, payload, 1 FROM legacy_items WHERE id = ?
  `).all(id, id) as { id: unknown; name: unknown; version: unknown; payload: unknown; legacy: number }[];
  let latest: Item | null = null;
  for (const row of rows) {
    const item = row.legacy ? decodeLegacy(row.id, row.payload) : validateItem(row.id, row.name, row.version);
    if (latest && latest.version === item.version && latest.name !== item.name) {
      throw new Error(`Conflicting names at equal version for ${id}`);
    }
    if (!latest || item.version > latest.version) latest = item;
  }
  return latest;
}

function writeTyped(db: Database, item: Item): void {
  db.query('INSERT INTO items(id,name,version) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version')
    .run(item.id, item.name, item.version);
}

export function putItem(db: Database, id: string, name: string): Item {
  nonempty(id, 'id');
  nonempty(name, 'name');
  return db.transaction(() => {
    const item = validateItem(id, name, (readItem(db, id)?.version ?? 0) + 1);
    writeTyped(db, item);
    db.query('INSERT INTO legacy_items(id,payload) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload')
      .run(id, JSON.stringify({ name, version: item.version }));
    return item;
  }).immediate();
}

export function migrate(db: Database, options: MigrationOptions = {}): { scanned: number } {
  const batchSize = options.batchSize === undefined ? 50 : options.batchSize;
  if (!Number.isSafeInteger(batchSize) || batchSize <= 0) throw new Error('Invalid batchSize');
  let scanned = 0;
  let cursor: string | null = null;
  const copyBatch = db.transaction(() => {
    // Keyset pagination bounds memory and avoids rescanning earlier payloads.
    const rows = (cursor === null
      ? db.query('SELECT id,payload FROM legacy_items ORDER BY id LIMIT ?').all(batchSize)
      : db.query('SELECT id,payload FROM legacy_items WHERE id > ? ORDER BY id LIMIT ?').all(cursor, batchSize)
    ) as { id: string; payload: string }[];
    for (const row of rows) {
      const legacy = decodeLegacy(row.id, row.payload);
      const latest = readItem(db, legacy.id)!;
      // Migration only copies; it never increments versions or changes legacy bytes.
      writeTyped(db, latest);
    }
    return rows;
  });
  while (true) {
    const rows = copyBatch.immediate();
    if (rows.length === 0) break;
    cursor = rows[rows.length - 1]!.id;
    scanned += rows.length;
    options.afterBatch?.({ scanned });
  }
  return { scanned };
}
