# Catalog rolling-upgrade implementation

Authoritative specification: README.md and legacy/INTEGRATION.md.
Local work record; no external tracker, Git initialization, commits, or publication.

## Method

Read the selected frozen ask-matt router and its setup, grill-with-docs,
grilling, domain-modeling, implement, TDD, test/mocking, and code-review references.
The supplied owner decision resolves the product frontier and approves the public
API and persistence integration seams. No further approval was requested.
Used a single-session implementation with red/green slices for coexistence and
interruption recovery, followed by fault-injection and contract regression tests.
No unrelated repository setup or method installation changes were made.

The independent Standards and Spec reviews prescribed by code-review remain
PENDING: the experiment explicitly disallows subagents and independent reviewers
are unavailable. No independent approval is claimed. Local source/contract
inspection was performed by the implementer.

## Behavior

- A single read statement sees typed and legacy representations in one snapshot;
  both are validated, the highest version wins, and divergent equal versions fail.
- IMMEDIATE write transactions acquire the SQLite writer reservation before
  reading the version, then update both formats before success.
- Migration uses ascending keyset pagination with a configurable bounded batch;
  one IMMEDIATE transaction is the recovery unit. Legacy bytes are never changed.
- A callback runs after each nonempty batch commits, with cumulative visited rows.
  Its errors propagate. Prior batches remain committed.
- There is no permanent completion marker: retry scans again, including rows
  updated by old desktops behind an earlier cursor. Reads see such edits even
  before another migration. Migration does not increment logical versions.
- Existing busy_timeout=1000 is retained. SQLite lock/storage errors propagate;
  no application retry loop or background worker was added.

## Observed validation

Initial public suite: 1 pass / 1 fail, reproducing removal of desktop-visible data.
Added coexistence test initially failed because the typed reader ignored legacy.
Added interruption test initially failed because migration deleted legacy rows.
Final `bun test test`: 12 pass, 0 fail, 110 assertions on Bun 1.4.2.

Coverage includes alternating writers through separate handles, callback writes
and visibility of committed batches from another handle, interrupted migration
and reopening, repeat migration after desktop activity, preservation of higher
typed versions, equal-version corruption, invalid input and persisted values,
version overflow, batch rollback and repair, dual-format storage failure rollback,
empty/final/default batch callbacks, Unicode/spaces/punctuation, large names,
and migration of a temporary copy of the shipped legacy-only SQLite database.
Original fixture data, public tests, and legacy producer were preserved.

## Limits

No standalone TypeScript compiler or project typecheck configuration is present;
Bun executed the TypeScript tests, but this is not static typechecking.
No multiprocess contention/load benchmark, real process kill, power-loss, or disk
full experiment was run. Interruption used the specified afterBatch failpoint;
storage failure used an aborting SQLite trigger. Tests verify recovery boundaries,
not a latency/throughput SLA. Writer locking can delay concurrent writers for the
current batch; batchSize controls that trade-off and is caller-configurable.
