# Catalog migration: local verification

Scope: src/store.ts plus original tests in test/rolling.test.ts. Public README,
legacy sources, original tests and data/legacy.sqlite were preserved (SHA-1
manifest checked successfully). No Git repository was available; production
before/after comparison used .work/store.before.ts and diff -u.

Method: frozen NEXUS build, DEEP because persistent migration changes recovery
and compatibility invariants. Single-agent implementation and self-inspection;
independent review remains pending and is not claimed as performed.

Decisions and invariants:
- Reads validate both formats in one snapshot, return the higher version, and
  reject divergent equal versions or any invalid item encountered.
- putItem reserves SQLite's writer lock before reading either version and commits
  typed and desktop-compatible JSON together. Overflow throws before writes.
- Migration uses primary-key keyset pagination, at most batchSize legacy payloads
  per query (default 50), and an IMMEDIATE transaction per batch. It copies only
  newer versions, never deletes or rewrites legacy bytes, and never increments a
  logical version. No durable completion marker can hide later desktop activity.
- Callbacks run after nonempty commits, including a final partial batch. Errors
  propagate. Failed batches roll back; earlier commits survive. Writes behind the
  cursor are visible to readItem immediately and copied on the next migration.
- migrate rejects a caller-owned transaction to preserve per-batch commit and
  callback semantics. Existing 1000ms SQLite busy timeout bounds lock waiting;
  exhausted contention propagates as an error, without automatic retries.

Observed validation, Bun 1.4.2:
- Original suite before changes: 1 pass, 1 fail (legacy row deleted).
- Expanded regression before changes: 1 pass, 8 fail; see regression-before.log.
- Final command: /Users/elourenco/.bun/bin/bun test test
- Final result: 14 pass, 0 fail, 108 assertions, across two test files.
- Coverage: desktop/new alternating edits, seeded database copy, callback failure
  and reopen, retry after malformed JSON repair, whole-batch rollback, legacy byte
  preservation, newer-version precedence, divergent ties, stale invalid data,
  dual-write rollback via abort triggers on either table, invalid inputs and batch
  sizes, version overflow, sparse/Unicode/NUL/punctuation ids, large opaque names,
  final partial callbacks, default batch size, inter-batch edits and inserts,
  typed corruption, and two local OS writer processes (40 edits each; resulting
  version 80, then 81 after a further upgraded write).

Limits: independent architecture/quality/performance/reliability review required
by NEXUS DEEP is unavailable in this single-agent experiment and remains pending.
Local process tests are not a throughput benchmark or proof of all schedules;
no power-loss, disk-full or filesystem durability experiment was performed.
