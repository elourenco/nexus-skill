import { Database } from 'bun:sqlite';

export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};

export function openStore(path: string): Database {
  const db = new Database(path, { create: true });
  db.exec('PRAGMA busy_timeout=1000');
  db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
  db.exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)');
  return db;
}

export function readItem(db: Database, id: string): Item | null {
  return db.query('SELECT id,name,version FROM items WHERE id=?').get(id) as Item | null;
}

export function putItem(db: Database, id: string, name: string): Item {
  const item = { id, name, version: (readItem(db, id)?.version ?? 0) + 1 };
  db.query('INSERT INTO items(id,name,version) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version')
    .run(item.id, item.name, item.version);
  return item;
}

export function migrate(db: Database, options: MigrationOptions = {}): { scanned: number } {
  const rows = db.query('SELECT id,payload FROM legacy_items ORDER BY id').all() as { id: string; payload: string }[];
  let scanned = 0;
  for (const row of rows) {
    const value = JSON.parse(row.payload);
    db.query('INSERT OR REPLACE INTO items(id,name,version) VALUES(?,?,?)').run(row.id, value.name, value.version);
    db.query('DELETE FROM legacy_items WHERE id=?').run(row.id);
    scanned++;
    if (scanned % (options.batchSize ?? 50) === 0) options.afterBatch?.({ scanned });
  }
  return { scanned };
}
