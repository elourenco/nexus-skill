import { expect, test } from 'bun:test';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore, readItem, putItem, migrate } from '../src/store';
import { openLegacy, legacyRead, legacyPut } from '../legacy/producer';

function fixture(run: (db: ReturnType<typeof openStore>, path: string) => void, seeded = false) {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-rolling-'));
  const path = join(dir, 'db.sqlite');
  if (seeded) copyFileSync(new URL('../data/legacy.sqlite', import.meta.url), path);
  const db = openStore(path);
  try { run(db, path); } finally { db.close(); rmSync(dir, { recursive: true, force: true }); }
}
const raw = (db: ReturnType<typeof openStore>, id: string, payload: string) =>
  db.query('INSERT OR REPLACE INTO legacy_items VALUES (?,?)').run(id, payload);
const typed = (db: ReturnType<typeof openStore>, id: string, name: unknown, version: unknown) =>
  db.query('INSERT OR REPLACE INTO items VALUES (?,?,?)').run(id, name as string, version as number);

test('both writers see alternating edits before and after migration', () => fixture((db, path) => {
  const old = openLegacy(path);
  try {
    legacyPut(old, 'a', 'old');
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'old', version: 1 });
    expect(putItem(db, 'a', '  Café 🧪  ').version).toBe(2);
    expect(legacyRead(old, 'a')).toEqual(readItem(db, 'a'));
    legacyPut(old, 'a', 'later');
    migrate(db);
    legacyPut(old, 'a', 'after migration');
    expect(readItem(db, 'a')?.version).toBe(4);
    expect(putItem(db, 'a', 'new').version).toBe(5);
    expect(legacyRead(old, 'a')).toEqual(readItem(db, 'a'));
  } finally { old.close(); }
}));

test('interrupted batches survive reopen, preserve bytes and rescan old edits', () => fixture((db, path) => {
  const before = db.query('SELECT * FROM legacy_items ORDER BY id').all();
  const observed: number[] = [];
  const old = openLegacy(path);
  try {
    expect(() => migrate(db, { batchSize: 2, afterBatch({ scanned }) {
      observed.push(scanned);
      expect(db.inTransaction).toBe(false);
      legacyPut(old, 'alpha', 'edited behind cursor');
      throw new Error('interrupted');
    } })).toThrow('interrupted');
    expect(observed).toEqual([2]);
    expect(db.query('SELECT count(*) AS n FROM items').get()).toEqual({ n: 2 });
    const reopened = openStore(path);
    try {
      const callbacks: number[] = [];
      expect(migrate(reopened, { batchSize: 3, afterBatch: x => { callbacks.push(x.scanned); } })).toEqual({ scanned: 4 });
      expect(callbacks).toEqual([3, 4]);
      expect(readItem(reopened, 'alpha')?.name).toBe('edited behind cursor');
      expect(migrate(reopened)).toEqual({ scanned: 4 });
      for (const row of before as {id: string; payload: string}[]) {
        if (row.id !== 'alpha') expect(legacyRead(reopened, row.id)).toEqual({ id: row.id, ...JSON.parse(row.payload) });
        if (row.id !== 'alpha') expect(reopened.query('SELECT payload FROM legacy_items WHERE id=?').get(row.id)).toEqual({ payload: row.payload });
      }
    } finally { reopened.close(); }
  } finally { old.close(); }
}, true));

test('bad row rolls back its entire batch; repair allows retry', () => fixture(db => {
  raw(db, 'a', '{ "name": "A", "version": 1 }');
  raw(db, 'b', '{"name":"B","version":1}');
  raw(db, 'c', '{"name":"C","version":1}');
  raw(db, 'd', '{broken');
  const original = db.query('SELECT * FROM legacy_items ORDER BY id').all();
  expect(() => migrate(db, { batchSize: 2 })).toThrow();
  expect(db.query('SELECT id FROM items ORDER BY id').all()).toEqual([{ id: 'a' }, { id: 'b' }]);
  expect(db.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(original);
  raw(db, 'd', '{"name":"D","version":1}');
  expect(migrate(db, { batchSize: 2 })).toEqual({ scanned: 4 });
}));

test('higher version wins, divergent ties throw, even stale invalid records throw', () => fixture(db => {
  raw(db, 'a', '{"name":"old","version":2}');
  typed(db, 'a', 'new', 5);
  migrate(db);
  expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'new', version: 5 });
  expect(putItem(db, 'a', 'next').version).toBe(6);
  expect(legacyRead(db, 'a')?.version).toBe(6);
  raw(db, 'a', '{"name":"conflict","version":6}');
  expect(() => readItem(db, 'a')).toThrow();
  expect(() => putItem(db, 'a', 'overwrite')).toThrow();
  expect(() => migrate(db)).toThrow();
  raw(db, 'a', '{"name":"","version":1}');
  expect(() => readItem(db, 'a')).toThrow();
}));

test('both formats roll back on failure writing either side', () => fixture(db => {
  for (const table of ['legacy_items', 'items']) {
    putItem(db, 'a', 'before');
    const before = readItem(db, 'a');
    db.exec(`CREATE TRIGGER reject_write BEFORE UPDATE ON ${table} BEGIN SELECT RAISE(ABORT, 'storage failure'); END`);
    expect(() => putItem(db, 'a', 'after')).toThrow('storage failure');
    expect(readItem(db, 'a')).toEqual(before);
    expect(legacyRead(db, 'a')).toEqual(before);
    db.exec('DROP TRIGGER reject_write');
  }
}));

test('invalid inputs, persisted data and exhausted versions never mutate', () => fixture(db => {
  for (const batchSize of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, null, '2']) {
    expect(() => migrate(db, { batchSize: batchSize as number })).toThrow();
  }
  for (const id of ['', null, 1]) {
    expect(() => readItem(db, id as string)).toThrow();
    expect(() => putItem(db, id as string, 'name')).toThrow();
  }
  for (const name of ['', null, 1]) expect(() => putItem(db, 'a', name as string)).toThrow();
  for (const payload of ['null', '[]', '{}', '{"name":1,"version":1}', '{"name":"x","version":0}', '{"name":"x","version":1.5}', '{"name":"x","version":9007199254740992}']) {
    raw(db, 'a', payload);
    expect(() => readItem(db, 'a')).toThrow();
    expect(() => migrate(db)).toThrow();
  }
  raw(db, 'a', JSON.stringify({ name: 'max', version: Number.MAX_SAFE_INTEGER }));
  expect(() => putItem(db, 'a', 'overflow')).toThrow();
  expect(db.query('SELECT * FROM items').all()).toEqual([]);
  db.exec('DELETE FROM legacy_items');
  typed(db, 'a', 'bad', 0);
  expect(() => readItem(db, 'a')).toThrow();
  expect(() => putItem(db, 'a', 'overwrite')).toThrow();
}));

test('keyset batches cover sparse, Unicode, punctuation and large opaque names', () => fixture(db => {
  const ids = ['', "a' OR 1=1 --", 'a\u0000tail', 'é', '🧪', 'z'.repeat(1000)].slice(1);
  const name = '  名 🧪 '.repeat(20000);
  for (const id of ids) legacyPut(db, id, name);
  const order: string[] = [];
  migrate(db, { batchSize: 1, afterBatch() {
    const rows = db.query('SELECT id FROM items ORDER BY id').all() as {id: string}[];
    order.push(rows[rows.length - 1].id);
  } });
  expect(order).toEqual((db.query('SELECT id FROM legacy_items ORDER BY id').all() as {id: string}[]).map(x => x.id));
  for (const id of ids) expect(readItem(db, id)?.name).toBe(name);
}));

test('between-batch writes are reconciled and inserts ahead of cursor are visited', () => fixture((db, path) => {
  legacyPut(db, 'a', 'A');
  legacyPut(db, 'c', 'C');
  const old = openLegacy(path);
  const callbacks: number[] = [];
  try {
    expect(migrate(db, { batchSize: 1, afterBatch({ scanned }) {
      callbacks.push(scanned);
      if (scanned === 1) {
        legacyPut(old, 'a', 'changed behind cursor');
        legacyPut(old, 'b', 'insert ahead');
        legacyPut(old, 'c', 'changed ahead');
      }
    } })).toEqual({ scanned: 3 });
    expect(callbacks).toEqual([1, 2, 3]);
    expect(readItem(db, 'a')?.name).toBe('changed behind cursor');
    expect(readItem(db, 'b')?.name).toBe('insert ahead');
    expect(readItem(db, 'c')?.version).toBe(2);
    migrate(db);
    expect(db.query('SELECT name,version FROM items WHERE id=?').get('a')).toEqual({ name: 'changed behind cursor', version: 2 });
  } finally { old.close(); }
}));

test('default batch commits 50 rows and rejects bad data in the next batch', () => fixture(db => {
  for (let i = 0; i < 55; i++) legacyPut(db, String(i).padStart(3, '0'), 'value');
  raw(db, '051', 'not JSON');
  const callbacks: number[] = [];
  expect(() => migrate(db, { afterBatch: x => { callbacks.push(x.scanned); } })).toThrow();
  expect(callbacks).toEqual([50]);
  expect(db.query('SELECT count(*) AS n FROM items').get()).toEqual({ n: 50 });
  expect(db.query('SELECT count(*) AS n FROM legacy_items').get()).toEqual({ n: 55 });
}));

test('invalid batch size cannot mutate populated storage or invoke a callback', () => fixture(db => {
  legacyPut(db, 'a', 'before');
  let called = false;
  expect(() => migrate(db, { batchSize: 0, afterBatch() { called = true; } })).toThrow();
  expect(called).toBe(false);
  expect(db.query('SELECT * FROM items').all()).toEqual([]);
  expect(legacyRead(db, 'a')?.name).toBe('before');
}));

test('migration conflict and typed corruption roll back the batch', () => fixture(db => {
  legacyPut(db, 'a', 'A');
  legacyPut(db, 'b', 'B');
  typed(db, 'b', 'conflict', 1);
  expect(() => migrate(db, { batchSize: 2 })).toThrow();
  expect(db.query('SELECT id FROM items ORDER BY id').all()).toEqual([{ id: 'b' }]);
  typed(db, 'b', 'B', -1);
  expect(() => migrate(db, { batchSize: 2 })).toThrow();
  expect(db.query('SELECT id FROM items ORDER BY id').all()).toEqual([{ id: 'b' }]);
  typed(db, 'b', 'B', 1);
  expect(migrate(db, { batchSize: 2 })).toEqual({ scanned: 2 });
}));

test('simultaneous legacy and upgraded processes do not lose version increments', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-processes-'));
  const path = join(dir, 'db.sqlite');
  const db = openStore(path);
  try {
    const programs = [
      `import { openStore, putItem } from ${JSON.stringify(new URL('../src/store.ts', import.meta.url).href)};
       const db = openStore(${JSON.stringify(path)});
       try { for (let i=0; i<40; i++) putItem(db, 'shared', 'new-'+i); } finally { db.close(); }`,
      `import { openLegacy, legacyPut } from ${JSON.stringify(new URL('../legacy/producer.ts', import.meta.url).href)};
       const db = openLegacy(${JSON.stringify(path)});
       try { for (let i=0; i<40; i++) legacyPut(db, 'shared', 'old-'+i); } finally { db.close(); }`,
    ];
    const children = programs.map(program => Bun.spawn([process.execPath, '-e', program], { stdout: 'pipe', stderr: 'pipe' }));
    const results = await Promise.all(children.map(async child => ({
      code: await child.exited, stderr: await new Response(child.stderr).text(),
    })));
    expect(results).toEqual([{ code: 0, stderr: '' }, { code: 0, stderr: '' }]);
    expect(readItem(db, 'shared')?.version).toBe(80);
    expect(legacyRead(db, 'shared')?.version).toBe(80);
    migrate(db);
    expect(putItem(db, 'shared', 'final').version).toBe(81);
    expect(legacyRead(db, 'shared')).toEqual(readItem(db, 'shared'));
  } finally { db.close(); rmSync(dir, { recursive: true, force: true }); }
});
