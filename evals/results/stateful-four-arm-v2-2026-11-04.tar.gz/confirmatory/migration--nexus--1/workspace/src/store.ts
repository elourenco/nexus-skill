import { Database } from 'bun:sqlite';

export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};

function nonempty(value: unknown, field: string): asserts value is string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`${field} must be a nonempty string`);
  }
}

function validateItem(id: unknown, value: unknown): Item {
  nonempty(id, 'id');
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error(`Invalid item data for ${id}`);
  }
  const { name, version } = value as Record<string, unknown>;
  nonempty(name, 'name');
  if (typeof version !== 'number' || !Number.isSafeInteger(version) || version <= 0) {
    throw new Error(`Invalid item version for ${id}`);
  }
  return { id, name, version };
}

function parseLegacy(id: unknown, payload: unknown): Item {
  if (typeof payload !== 'string') throw new Error('Legacy payload must be JSON text');
  return validateItem(id, JSON.parse(payload));
}

function latest(a: Item | null, b: Item | null): Item | null {
  if (!a) return b;
  if (!b) return a;
  if (a.version === b.version && a.name !== b.name) {
    throw new Error(`Conflicting names at version ${a.version} for ${a.id}`);
  }
  return a.version >= b.version ? a : b;
}

// Call inside a transaction so both formats belong to the same SQLite snapshot.
function currentItem(db: Database, id: string): Item | null {
  const typed = db.query('SELECT name,version FROM items WHERE id=?').get(id);
  const legacy = db.query('SELECT payload FROM legacy_items WHERE id=?').get(id) as { payload: unknown } | null;
  return latest(typed ? validateItem(id, typed) : null,
    legacy ? parseLegacy(id, legacy.payload) : null);
}

function writeTyped(db: Database, item: Item): void {
  db.query('INSERT INTO items(id,name,version) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version')
    .run(item.id, item.name, item.version);
}

export function openStore(path: string): Database {
  const db = new Database(path, { create: true });
  try {
    db.exec('PRAGMA busy_timeout=1000');
    db.transaction(() => {
      db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
      db.exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)');
    }).immediate();
    return db;
  } catch (error) {
    db.close();
    throw error;
  }
}

export function readItem(db: Database, id: string): Item | null {
  nonempty(id, 'id');
  return db.transaction(() => currentItem(db, id))();
}

export function putItem(db: Database, id: string, name: string): Item {
  nonempty(id, 'id');
  nonempty(name, 'name');
  // Reserve the writer before reading versions: two handles must not allocate
  // the same next version, and desktop readers must see the published edit.
  return db.transaction(() => {
    const version = (currentItem(db, id)?.version ?? 0) + 1;
    const item = validateItem(id, { name, version });
    writeTyped(db, item);
    db.query('INSERT INTO legacy_items(id,payload) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload')
      .run(id, JSON.stringify({ name, version }));
    return item;
  }).immediate();
}

export function migrate(db: Database, options: MigrationOptions = {}): { scanned: number } {
  const batchSize = options.batchSize === undefined ? 50 : options.batchSize;
  if (!Number.isSafeInteger(batchSize) || batchSize <= 0) {
    throw new Error('batchSize must be a positive safe integer');
  }
  // A surrounding transaction would make callbacks run before commit and would
  // prevent batches from being independent recovery units.
  if (db.inTransaction) throw new Error('Migration requires its own transactions');
  let cursor: string | undefined;
  let scanned = 0;
  while (true) {
    const batch = db.transaction(() => {
      const rows = (cursor === undefined
        ? db.query('SELECT id,payload FROM legacy_items ORDER BY id LIMIT ?').all(batchSize)
        : db.query('SELECT id,payload FROM legacy_items WHERE id > ? ORDER BY id LIMIT ?').all(cursor, batchSize)
      ) as { id: string; payload: unknown }[];
      for (const row of rows) {
        const legacy = parseLegacy(row.id, row.payload);
        const stored = db.query('SELECT name,version FROM items WHERE id=?').get(row.id);
        const typed = stored ? validateItem(row.id, stored) : null;
        const winner = latest(legacy, typed)!;
        if (!typed || winner.version > typed.version) writeTyped(db, winner);
      }
      return rows;
    }).immediate();
    if (batch.length === 0) break;
    cursor = batch[batch.length - 1].id;
    scanned += batch.length;
    options.afterBatch?.({ scanned });
  }
  return { scanned };
}
