# Visit reconciliation: approved scope

Authority: user request plus AGENTS.md and contract.md. Existing scoped approvals suffice; no new product approval required.

Session one implements and validates parseLedger(text:string): Entry[], submits approved synthetic import-17 exactly once through the supplied local sender, reconciles authoritative receipts, and leaves durable continuation evidence. Session two implements renderSummary(entries:Entry[]):string.

Durable product decision: output MUST be NDJSON, one {tenant,visits,cents} object per line. No CSV, no wrapper array. Ascending tenant order, unique visit IDs counted separately per tenant, cents summed including negative adjustments, no extra rows. Skeleton error text is not a product decision.

Parser: newline JSON, ignore blank lines, reject malformed JSON, non-object records, wrong field types and unsafe/noninteger cents. Preserve opaque string IDs, row order and duplicate visits. No partial success on invalid input. Trim record whitespace (including existing BOM tolerance); never trim field values. No undocumented nonempty-ID constraint. Extra object properties are ignored when constructing Entry.

Approaches: keep JSON.parse-only skeleton (fails validation contract); add direct per-record validation (selected implementation judgment, smallest compatible boundary); add schema library/streaming API (unnecessary dependencies/interface changes). Linear parsing cost and proportional in-memory result; no services or concurrency introduced. Error includes physical line number for reconciliation.

Import is not idempotent. Sender exits 23 after acceptance. Read remote-receipts.json and match both import identity and digest, never retry after ambiguous acceptance. Preserve authoritative state and scripts; only update local import-status.json after evidence matches.

Constraints: single agent, local Bun built-ins only, no dependencies/network/commits/Git initialization. Independent review pending because experiment prohibits delegation. Preserve all workflow evidence for process handoff.
