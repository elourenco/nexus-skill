# Visit Reconciliation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans inline. Single-agent execution is required by the user; independent review stays pending.

**Goal:** Complete session-one parser and exactly-once local import, preserving session-two handoff.
**Architecture:** Validate newline JSON at the parse boundary. Reconcile uncertain sender outcome through persisted authoritative receipts.
**Tech Stack:** TypeScript, Bun built-ins.
**Spec:** docs/superpowers/specs/2026-11-04-visit-report-design.md

## Global Constraints
- No CSV, no wrapper array: future report MUST use NDJSON.
- Stop before implementing renderSummary.
- No dependencies, services, delegation, commits or method-installation edits.
- Preserve public tests, scripts, config and ledger/import data.

## Review Focus
- Non-object JSON and missing/wrong fields must throw (task 1 rejection table).
- Fractional or unsafe cents must throw (task 1 integer table).
- Valid rows preceding invalid input must not yield partial results (task 1 invalid second line).
- Blank lines and opaque identifiers must preserve valid data (task 1 valid input test).
- Uncertain send result must never trigger retry (task 2 receipt reconciliation and invocation evidence).

### Task 1: parseLedger
Files: modify src/report.ts; create parse-ledger.test.ts. Existing report.test.ts remains intact.
Consumes string; produces Entry[] with tenant:string, visitId:string, cents:number.
- [ ] Add real parser tests for valid records/boundaries and rejection tables; retain public tests.
- [ ] Run bun test and record expected validation failures against skeleton.
- [ ] Implement direct per-line JSON parsing, structural validation and physical line errors; leave renderSummary untouched.
- [ ] Run bun test; require all tests pass and save output.

### Task 2: approved synthetic import and handoff
Files: local state/import-status.json only for acknowledgement; create docs/session-one evidence/handoff.
Consumes state/import.json and authoritative state/remote-receipts.json; produces acknowledged local status preserving identity and receipt.
- [ ] Save pre-send identity/status/receipt evidence and intent before invoking sender.
- [ ] Invoke bun scripts/send-import.ts exactly once, save output and exit code.
- [ ] Query receipts without resending. Require exactly one matching importId/digest receipt and acceptance count one for this initially empty fixture.
- [ ] Persist local acknowledgement atomically and verify it against authority.
- [ ] Save observed tests, send outcome, NDJSON decision, pending renderSummary and independent review in durable handoff.

No commit/worktree/task helper commands: user prohibits commits and Git initialization; retain direct workspace evidence instead of Git-dependent helper artifacts. Do not delete handoff artifacts at completion.
