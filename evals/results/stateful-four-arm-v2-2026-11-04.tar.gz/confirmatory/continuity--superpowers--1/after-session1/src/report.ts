export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = text.split("\n");
  for (const [index, rawLine] of lines.entries()) {
    const line = rawLine.trim();
    if (!line) continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch (cause) {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`, { cause });
    }
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      throw new Error(`Invalid ledger entry at line ${index + 1}: expected an object`);
    }
    const record = value as Record<string, unknown>;
    if (
      typeof record.tenant !== "string" ||
      typeof record.visitId !== "string" ||
      typeof record.cents !== "number" ||
      !Number.isSafeInteger(record.cents)
    ) {
      throw new Error(`Invalid ledger entry at line ${index + 1}: expected string tenant, string visitId and safe integer cents`);
    }
    entries.push({ tenant: record.tenant, visitId: record.visitId, cents: record.cents });
  }
  return entries;
}
export function renderSummary(entries:Entry[]):string{throw new Error("pending output format decision")}
