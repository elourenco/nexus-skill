import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

// Catches coercion, dropped adjustments, deduplication and trimming opaque IDs.
test("preserves opaque IDs, duplicate visits and safe signed integer cents", () => {
  expect(parseLedger('\ufeff\n  \r\n{"tenant":" a ","visitId":"0042","cents":-50}\r\n{"tenant":" a ","visitId":"0042","cents":0}\n{"tenant":"b","visitId":"__proto__","cents":9007199254740991}\n{"tenant":"b","visitId":"","cents":-9007199254740991}\n')).toEqual([
    { tenant: " a ", visitId: "0042", cents: -50 },
    { tenant: " a ", visitId: "0042", cents: 0 },
    { tenant: "b", visitId: "__proto__", cents: 9007199254740991 },
    { tenant: "b", visitId: "", cents: -9007199254740991 },
  ]);
});

test("ignores whitespace-only ledger lines", () => {
  expect(parseLedger("\n \t\r\n\n")).toEqual([]);
});

// Each case catches a missing boundary validation; expectations are contract literals.
for (const invalid of [
  "null", "[]", "true", "42", '"record"', "{}",
  '{"tenant":1,"visitId":"v","cents":1}',
  '{"tenant":"a","visitId":42,"cents":1}',
  '{"tenant":"a","visitId":"v","cents":"1"}',
  '{"tenant":"a","visitId":"v"}',
  '{"tenant":"a","visitId":"v","cents":null}',
  '{"tenant":"a","visitId":"v","cents":1.5}',
  '{"tenant":"a","visitId":"v","cents":9007199254740992}',
  '{"tenant":"a","visitId":"v","cents":-9007199254740992}',
  '{"tenant":"a","visitId":"v","cents":1e400}',
  '{broken',
]) {
  test(`rejects invalid record without returning earlier valid rows: ${invalid}`, () => {
    expect(() => parseLedger('{"tenant":"a","visitId":"v","cents":1}\n\n' + invalid)).toThrow();
  });
}

test("identifies the physical line of malformed JSON after blanks", () => {
  expect(() => parseLedger('\n\n{broken')).toThrow(/line 3/i);
});

test("identifies the physical line of a structurally invalid record", () => {
  expect(() => parseLedger('\n\n{}')).toThrow(/line 3/i);
});
