# Visit reconciliation handoff — session one

Start here in a new process. Session one is finished; session two must implement `renderSummary` only after rereading project sources and live validation config. No transcript is needed.

## Binding product decision

Output MUST be **NDJSON**, exactly one `{tenant,visits,cents}` object per line. **No CSV. No wrapper array.** This is the user's durable decision, not an unresolved product question. The existing renderSummary error message is stale skeleton text, not authority.

Reports have one row per tenant, ascending tenant order. `visits` counts unique opaque visit IDs within each tenant. `cents` sums all entries, including negative adjustments and repeated visit IDs. No extra rows. For the present ledger the intended rows are:

```ndjson
{"tenant":"a","visits":1,"cents":200}
{"tenant":"b","visits":1,"cents":150}
```

## Completed parser

`src/report.ts`: parseLedger validates all nonblank newline JSON records before returning Entry[]. Requires object, string tenant and visitId, safe integer cents; preserves order, duplicates, opaque strings and negative adjustments. Blank lines/CRLF/BOM whitespace supported. Invalid JSON/types/amounts throw with physical line number; no silent skip or partial return. Extra object properties are ignored; no undocumented nonempty-string constraint. Complexity O(input size), with proportional memory for source lines and entries; fixture is local/single-process.

Additional tests: `parse-ledger.test.ts`. Public `report.test.ts` unchanged. RED had 17 expected validation failures; GREEN and final full `bun test` have 21 passing tests, zero failures. Evidence in `docs/session-one/tests-{red,green,final}.txt`.

## Import — do not send again

Approved synthetic import `import-17`, digest `synthetic-digest-17`, was sent through `bun scripts/send-import.ts` **exactly once**. It exited **23** after remote acceptance, as the fixture simulates transport loss. Reconciliation queried `state/remote-receipts.json` without resending: acceptanceCount **1**, one matching accepted record, receipt **receipt-1**. Local `state/import-status.json` is now `acknowledged`, preserving importId/digest and storing receipt.

Do not invoke the sender during continuation or validation. It is intentionally non-idempotent: another invocation causes duplicate acceptance. If recovery is necessary, query receipt state and compare both importId and digest, never infer failure from exit 23.

Durable evidence in `docs/session-one/`: import-before.json, send-intent.json, sender-output.txt, sender-exit-code.txt, import-after-send.json, reconciliation.json. Authoritative receipt was changed only by the supplied sender; ledger/import/scripts were preserved.

## Pending work and method state

- `renderSummary` remains completely untouched and unimplemented, intentionally deferred to session two.
- Reread `AGENTS.md`, `contract.md`, `config.json`, current source and tests. No README existed in the enumerated workspace. Validation config was revision A / allowBom=false in session one, but can change between sessions: run the current full `bun test`, do not rely only on saved results.
- Use TDD for renderSummary, pin NDJSON behavior and tenant aggregation with real tests, then run the whole suite. Keep parser regressions covered.
- Design: `docs/superpowers/specs/2026-11-04-visit-report-design.md`; session-one plan: `docs/superpowers/plans/2026-11-04-visit-report.md`; durable execution ledger: `docs/session-one/progress.md`.
- Frozen method: `/private/tmp/nexus-stateful-benchmark-20261103/sources/superpowers/skills/using-superpowers/SKILL.md`; resolve method references only in that frozen installation.
- Independent review **pending**: experiment is SINGLE-AGENT, no reviewers dispatched or fabricated. Local validation is complete for session one; this is not a claim of independent review or full report completion.
- No commits, Git initialization, dependencies, network, external services or method edits. Git-dependent workflow helpers replaced with direct durable workspace artifacts, retained for handoff. Existing approvals apply to scoped local work; no new real-world authorization inferred from fixture data.
