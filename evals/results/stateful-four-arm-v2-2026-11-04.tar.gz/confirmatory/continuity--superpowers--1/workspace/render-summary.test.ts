import { expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { parseLedger, renderSummary, type Entry } from "./src/report";

// Catches CSV/wrapper output, unsorted tenants and lost negative adjustments.
test("renders current ledger as sorted NDJSON tenant summaries", () => {
  expect(renderSummary(parseLedger(readFileSync("state/ledger.ndjson", "utf8")))).toBe(
    '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}',
  );
});

// Catches global visit deduplication and dropping amounts from duplicate visits.
test("counts unique visits per tenant while summing every adjustment", () => {
  const entries: Entry[] = [
    { tenant: "b", visitId: "0042", cents: 0 },
    { tenant: "a", visitId: "0042", cents: 250 },
    { tenant: "a", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: "42", cents: -300 },
  ];
  const snapshot = structuredClone(entries);
  expect(renderSummary(entries)).toBe(
    '{"tenant":"a","visits":2,"cents":-100}\n{"tenant":"b","visits":1,"cents":0}',
  );
  expect(entries).toEqual(snapshot);
});

test("emits no rows for empty input", () => {
  expect(renderSummary([])).toBe("");
});

// Catches prototype keys, numeric-key object ordering, normalization and broken escaping.
test("preserves opaque keys and escapes JSON using deterministic string ordering", () => {
  expect(renderSummary([
    { tenant: "2", visitId: "", cents: 2 },
    { tenant: "__proto__", visitId: "constructor", cents: 3 },
    { tenant: "10", visitId: "", cents: 1 },
    { tenant: "", visitId: "", cents: 0 },
    { tenant: ' a\n"', visitId: "", cents: -1 },
  ])).toBe(
    '{"tenant":"","visits":1,"cents":0}\n{"tenant":" a\\n\\\"","visits":1,"cents":-1}\n{"tenant":"10","visits":1,"cents":1}\n{"tenant":"2","visits":1,"cents":2}\n{"tenant":"__proto__","visits":1,"cents":3}',
  );
});

// Catches precision loss from an unsafe intermediate total even when final sum is safe.
test("sums integer cents exactly across large cancelling adjustments", () => {
  expect(renderSummary([
    { tenant: "a", visitId: "v", cents: Number.MAX_SAFE_INTEGER },
    { tenant: "a", visitId: "v", cents: 2 },
    { tenant: "a", visitId: "v", cents: -Number.MAX_SAFE_INTEGER },
  ])).toBe('{"tenant":"a","visits":1,"cents":2}');
});

for (const cents of [Number.MAX_SAFE_INTEGER, Number.MIN_SAFE_INTEGER]) {
  test(`rejects unrepresentable total starting at ${cents}`, () => {
    expect(() => renderSummary([
      { tenant: "a", visitId: "v", cents },
      { tenant: "a", visitId: "w", cents: Math.sign(cents) },
    ])).toThrow(RangeError);
  });
}
