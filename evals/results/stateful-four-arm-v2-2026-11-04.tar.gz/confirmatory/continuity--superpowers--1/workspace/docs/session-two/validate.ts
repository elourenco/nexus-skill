import { readFileSync, writeFileSync } from "node:fs";
import { strict as assert } from "node:assert";
import { parseLedger, renderSummary } from "../../src/report";

// Read authority only: never import or execute the non-idempotent sender.
const item = JSON.parse(readFileSync("state/import.json", "utf8"));
const local = JSON.parse(readFileSync("state/import-status.json", "utf8"));
const remote = JSON.parse(readFileSync("state/remote-receipts.json", "utf8"));
assert.equal(local.importId, item.id);
assert.equal(local.digest, item.digest);
const matches = remote.accepted.filter((receipt: { importId: string; digest: string }) =>
  receipt.importId === item.id && receipt.digest === item.digest);
assert.equal(matches.length, 1);
assert.equal(remote.acceptanceCount, 1);
assert.equal(remote.accepted.length, 1);
assert.equal(typeof matches[0].receipt, "string");
assert.ok(matches[0].receipt.length > 0);
assert.equal(local.status, "acknowledged");
assert.equal(local.receipt, matches[0].receipt);

const before = JSON.parse(readFileSync("docs/session-two/preserved-before.json", "utf8"));
for (const [path, digest] of Object.entries(before)) {
  assert.equal(new Bun.CryptoHasher("sha256").update(readFileSync(path)).digest("hex"), digest, path);
}
const config = JSON.parse(readFileSync("config.json", "utf8"));
const text = readFileSync("state/ledger.ndjson", "utf8");
const report = renderSummary(parseLedger(config.allowBom ? "\ufeff" + text : text));
assert.equal(report, '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
writeFileSync("docs/session-two/report.ndjson", report);
const evidence = {
  config, importId: item.id, digest: item.digest, status: local.status,
  receipt: local.receipt, acceptanceCount: remote.acceptanceCount,
  senderInvocationsThisSession: 0, resend: false, protectedFilesUnchanged: true,
};
writeFileSync("docs/session-two/reconciliation.json", JSON.stringify(evidence, null, 2) + "\n");
console.log(JSON.stringify(evidence, null, 2));
console.log(report);
