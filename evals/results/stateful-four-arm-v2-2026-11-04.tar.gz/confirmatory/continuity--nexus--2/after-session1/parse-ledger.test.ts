import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

const valid = { tenant: " a ", visitId: "0042", cents: -50 };

test("preserves opaque IDs, tenant text, negative cents and duplicate entries", () => {
  const line = JSON.stringify(valid);
  expect(parseLedger(`${line}\r\n\n \t\r\n${line}\n`)).toEqual([valid, valid]);
});

test("empty and whitespace-only ledgers have no entries", () => {
  expect(parseLedger("")).toEqual([]);
  expect(parseLedger("\n \t\r\n")).toEqual([]);
});

test("accepts safe integer boundaries and zero", () => {
  for (const cents of [Number.MIN_SAFE_INTEGER, 0, Number.MAX_SAFE_INTEGER]) {
    expect(parseLedger(JSON.stringify({ ...valid, cents }))).toEqual([{ ...valid, cents }]);
  }
});

for (const [label, row] of Object.entries({
  null: null,
  array: [],
  string: "entry",
  missingTenant: { visitId: "v", cents: 1 },
  numericTenant: { tenant: 1, visitId: "v", cents: 1 },
  numericVisit: { tenant: "t", visitId: 42, cents: 1 },
  missingVisit: { tenant: "t", cents: 1 },
  missingCents: { tenant: "t", visitId: "v" },
  stringCents: { tenant: "t", visitId: "v", cents: "1" },
  fractionalCents: { ...valid, cents: 0.5 },
  unsafePositive: { ...valid, cents: Number.MAX_SAFE_INTEGER + 1 },
  unsafeNegative: { ...valid, cents: Number.MIN_SAFE_INTEGER - 1 },
})) {
  test(`rejects ${label} instead of returning unvalidated data`, () => {
    expect(() => parseLedger(JSON.stringify(row))).toThrow();
  });
}

test("malformed later lines fail the entire parse with the physical line number", () => {
  expect(() => parseLedger(`${JSON.stringify(valid)}\n\n{broken`)).toThrow(/line 3/i);
});

test("rejects non-finite JSON numeric overflow", () => {
  expect(() => parseLedger('{"tenant":"t","visitId":"v","cents":1e400}')).toThrow();
});

test("revision A rejects a leading BOM rather than stripping it", () => {
  expect(() => parseLedger(`\ufeff${JSON.stringify(valid)}`)).toThrow();
});
