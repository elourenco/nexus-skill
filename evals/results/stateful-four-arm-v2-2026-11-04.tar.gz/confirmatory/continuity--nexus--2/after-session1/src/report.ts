export type Entry = { tenant: string; visitId: string; cents: number };

export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = text.split("\n");

  for (const [index, line] of lines.entries()) {
    if (/^[ \t\r]*$/.test(line)) continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch (cause) {
      throw new SyntaxError(`Invalid ledger JSON at line ${index + 1}`, { cause });
    }

    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" ||
      !Number.isSafeInteger(value.cents)
    ) {
      throw new TypeError(`Invalid ledger entry at line ${index + 1}: expected tenant and visitId strings and safe integer cents`);
    }

    entries.push({ tenant: value.tenant, visitId: value.visitId, cents: value.cents });
  }

  return entries;
}

export function renderSummary(entries:Entry[]):string{throw new Error("pending output format decision")}
