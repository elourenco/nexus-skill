import { expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { parseLedger, renderSummary } from "./src/report";

test("renders the persisted ledger as the agreed ordered NDJSON objects", () => {
  expect(renderSummary(parseLedger(readFileSync("state/ledger.ndjson", "utf8"))))
    .toBe('{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
});

test("empty reports contain no rows", () => {
  expect(renderSummary([])).toBe("");
});

test("counts opaque visits per tenant, includes every adjustment and preserves input", () => {
  const entries = Object.freeze([
    Object.freeze({ tenant: "z", visitId: "0042", cents: 100 }),
    Object.freeze({ tenant: "a", visitId: "0042", cents: -50 }),
    Object.freeze({ tenant: "z", visitId: "0042", cents: -125 }),
    Object.freeze({ tenant: "z", visitId: "42", cents: 25 }),
  ]);
  expect(renderSummary([...entries])).toBe(
    '{"tenant":"a","visits":1,"cents":-50}\n{"tenant":"z","visits":2,"cents":0}',
  );
});

test("handles object-property names, empty identifiers and escaped tenant text", () => {
  const tenants = ["constructor", "__proto__", 'a\n"', ""];
  const output = renderSummary(tenants.map(tenant => ({ tenant, visitId: "", cents: 1 })));
  expect(output.split("\n").map(line => JSON.parse(line))).toEqual([
    { tenant: "", visits: 1, cents: 1 },
    { tenant: "__proto__", visits: 1, cents: 1 },
    { tenant: 'a\n"', visits: 1, cents: 1 },
    { tenant: "constructor", visits: 1, cents: 1 },
  ]);
});

test("totals remain exact across large adjustments and reject unsafe final totals", () => {
  const entries = [Number.MAX_SAFE_INTEGER, 2, -2].map(cents => ({ tenant: "t", visitId: "v", cents }));
  expect(renderSummary(entries)).toBe('{"tenant":"t","visits":1,"cents":9007199254740991}');
  expect(() => renderSummary(entries.slice(0, 2))).toThrow(RangeError);
  expect(() => renderSummary([
    { tenant: "t", visitId: "v", cents: Number.MIN_SAFE_INTEGER },
    { tenant: "t", visitId: "v", cents: -1 },
  ])).toThrow(RangeError);
});
