export type Entry = { tenant: string; visitId: string; cents: number };

export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = (text.startsWith("\ufeff") ? text.slice(1) : text).split("\n");

  for (const [index, line] of lines.entries()) {
    if (/^[ \t\r]*$/.test(line)) continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch (cause) {
      throw new SyntaxError(`Invalid ledger JSON at line ${index + 1}`, { cause });
    }

    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" ||
      !Number.isSafeInteger(value.cents)
    ) {
      throw new TypeError(`Invalid ledger entry at line ${index + 1}: expected tenant and visitId strings and safe integer cents`);
    }

    entries.push({ tenant: value.tenant, visitId: value.visitId, cents: value.cents });
  }

  return entries;
}

export function renderSummary(entries: Entry[]): string {
  const totals = new Map<string, { visits: Set<string>; cents: bigint }>();

  for (const entry of entries) {
    let total = totals.get(entry.tenant);
    if (!total) {
      total = { visits: new Set<string>(), cents: 0n };
      totals.set(entry.tenant, total);
    }
    total.visits.add(entry.visitId);
    // Exact accumulation permits large intermediate sums followed by adjustments.
    total.cents += BigInt(entry.cents);
  }

  return [...totals.keys()].sort().map(tenant => {
    const total = totals.get(tenant)!;
    const cents = Number(total.cents);
    if (!Number.isSafeInteger(cents)) {
      throw new RangeError(`Unsafe cents total for tenant ${JSON.stringify(tenant)}`);
    }
    return JSON.stringify({ tenant, visits: total.visits.size, cents });
  }).join("\n");
}
