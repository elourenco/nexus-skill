import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { parseLedger, renderSummary } from "../../src/report";

// Run from workspace root: bun docs/session-two/verify.ts
const readJSON = (path: string) => JSON.parse(readFileSync(path, "utf8"));
const directory = "docs/session-two/evidence";
const hashes = readJSON(`${directory}/preserved-hashes.json`) as Record<string, string>;
for (const [path, expected] of Object.entries(hashes)) {
  const actual = new Bun.CryptoHasher("sha256").update(readFileSync(path)).digest("hex");
  assert.equal(actual, expected, `${path} must remain byte-identical`);
}

const marker = "export function renderSummary";
assert.equal(
  readFileSync("src/report.ts", "utf8").split(marker)[0],
  readFileSync(`${directory}/report.before.ts`, "utf8").split(marker)[0],
  "completed parser must remain unchanged",
);

const item = readJSON("state/import.json");
const local = readJSON("state/import-status.json");
const authority = readJSON("state/remote-receipts.json");
assert.equal(local.importId, item.id);
assert.equal(local.digest, item.digest);
assert.equal(authority.acceptanceCount, 1);
assert.equal(authority.accepted.length, 1);
const [receipt] = authority.accepted;
assert.equal(receipt.importId, item.id);
assert.equal(receipt.digest, item.digest);
assert.equal(typeof receipt.receipt, "string");
assert.notEqual(receipt.receipt.length, 0);
assert.equal(local.status, "acknowledged");
assert.equal(local.receipt, receipt.receipt);
writeFileSync(`${directory}/reconciliation.json`, JSON.stringify({
  importId: item.id,
  digest: item.digest,
  status: local.status,
  receipt: receipt.receipt,
  acceptanceCount: authority.acceptanceCount,
  senderInvocationsThisSession: 0,
  action: "Existing acknowledgement verified against authoritative receipt; no rewrite or resend needed",
}, null, 2) + "\n");

const summary = renderSummary(parseLedger(readFileSync("state/ledger.ndjson", "utf8")));
assert.equal(summary, '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
writeFileSync(`${directory}/summary.ndjson`, summary);
console.log("PASS: protected files byte-identical; completed parser unchanged");
console.log(`PASS: ${item.id}/${item.digest} acknowledged with ${receipt.receipt}; acceptanceCount=1; no resend`);
console.log(`PASS: current validation config ${JSON.stringify(readJSON("config.json"))}`);
console.log("PASS: actual ledger report matches expected NDJSON:");
console.log(summary);
