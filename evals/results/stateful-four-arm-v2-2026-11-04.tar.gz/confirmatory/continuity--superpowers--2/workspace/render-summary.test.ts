import { expect, test } from "bun:test";
import { parseLedger, renderSummary, type Entry } from "./src/report";

// Catches deduplicating adjustments, global visit counting, or emitting CSV/arrays.
test("aggregates every adjustment and counts unique visits within each tenant", () => {
  expect(renderSummary([
    { tenant: "b", visitId: "0042", cents: 150 },
    { tenant: "a", visitId: "0042", cents: 250 },
    { tenant: "a", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: "other", cents: 10 },
    { tenant: "b", visitId: "0042", cents: 150 },
  ])).toBe('{"tenant":"a","visits":2,"cents":210}\n{"tenant":"b","visits":1,"cents":300}');
});

// Catches emitting a header, array, or blank record for empty data.
test("empty input emits no rows", () => {
  expect(renderSummary([])).toBe("");
});

// Catches unsafe interpolation, trimming opaque tenants, or object-key grouping.
test("escapes tenant strings and preserves empty and prototype-like tenant keys", () => {
  const output = renderSummary([
    { tenant: "__proto__", visitId: "", cents: 0 },
    { tenant: "", visitId: "", cents: -1 },
    { tenant: ' a"\n\\雪 ', visitId: "x", cents: 2 },
  ]);
  expect(output.split("\n").map(line => JSON.parse(line))).toEqual([
    { tenant: "", visits: 1, cents: -1 },
    { tenant: ' a"\n\\雪 ', visits: 1, cents: 2 },
    { tenant: "__proto__", visits: 1, cents: 0 },
  ]);
});

// Catches numeric or locale-dependent sorting and loss of opaque visit IDs.
test("uses deterministic lexical tenant order and preserves distinct opaque visits", () => {
  expect(renderSummary([
    { tenant: "2", visitId: "x", cents: 0 },
    { tenant: "a", visitId: "0042", cents: -2 },
    { tenant: "A", visitId: "x", cents: 1 },
    { tenant: "10", visitId: "x", cents: 3 },
    { tenant: "a", visitId: "42", cents: 0 },
  ])).toBe('{"tenant":"10","visits":1,"cents":3}\n{"tenant":"2","visits":1,"cents":0}\n{"tenant":"A","visits":1,"cents":1}\n{"tenant":"a","visits":2,"cents":-2}');
});

// Catches in-place sorting, input mutation, and aggregate leakage across calls.
test("does not mutate inputs or retain totals across calls", () => {
  const entries: Entry[] = [
    { tenant: "b", visitId: "x", cents: 2 },
    { tenant: "a", visitId: "x", cents: 1 },
  ];
  for (const entry of entries) Object.freeze(entry);
  Object.freeze(entries);
  const before = structuredClone(entries);
  const first = renderSummary(entries);
  expect(entries).toEqual(before);
  expect(renderSummary([])).toBe("");
  expect(renderSummary(entries)).toBe(first);
});

// Catches floating point loss during otherwise representable cancellation.
test("sums exactly across intermediate safe integer overflow", () => {
  expect(renderSummary([
    { tenant: "a", visitId: "1", cents: Number.MAX_SAFE_INTEGER },
    { tenant: "a", visitId: "2", cents: 2 },
    { tenant: "a", visitId: "3", cents: -Number.MAX_SAFE_INTEGER },
  ])).toBe('{"tenant":"a","visits":3,"cents":2}');
});

// Catches silently serializing rounded totals at either numeric boundary.
for (const cents of [Number.MAX_SAFE_INTEGER, Number.MIN_SAFE_INTEGER]) {
  test(`rejects unrepresentable final cents total starting with ${cents}`, () => {
    expect(() => renderSummary([
      { tenant: "a", visitId: "1", cents },
      { tenant: "a", visitId: "2", cents: cents > 0 ? 1 : -1 },
    ])).toThrow(/safe integer/i);
  });
}

// Catches integration regressions in the public parser-to-renderer API.
test("renders parsed duplicate visit adjustments", () => {
  expect(renderSummary(parseLedger(
    '\ufeff{"tenant":"b","visitId":"001","cents":150}\r\n' +
    '{"tenant":"a","visitId":"0042","cents":250}\n' +
    '{"tenant":"a","visitId":"0042","cents":-50}\n'
  ))).toBe('{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
});
