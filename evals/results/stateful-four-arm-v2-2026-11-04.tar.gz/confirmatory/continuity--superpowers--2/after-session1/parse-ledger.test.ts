import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

// Each case catches missing runtime shape or field validation.
const invalidRows = [
  "null", "[]", '"entry"', "42", "true", "{}",
  '{"tenant":2,"visitId":"x","cents":1}',
  '{"tenant":"a","visitId":42,"cents":1}',
  '{"tenant":"a","visitId":"x","cents":"1"}',
  '{"tenant":"a","visitId":"x","cents":null}',
  '{"tenant":"a","visitId":"x","cents":true}',
  '{"tenant":"a","visitId":"x","cents":0.5}',
  '{"tenant":"a","visitId":"x","cents":9007199254740992}',
  '{"tenant":"a","visitId":"x","cents":-9007199254740992}',
  '{"tenant":"a","visitId":"x","cents":1e400}',
];
for (const row of invalidRows) {
  test(`rejects invalid ledger entry ${row}`, () => {
    expect(() => parseLedger(row)).toThrow();
  });
}

// Catches swallowing a corrupt later row or losing its physical line number.
test("rejects malformed later data with its line number", () => {
  expect(() => parseLedger('\n{"tenant":"a","visitId":"x","cents":1}\n\n{broken'))
    .toThrow(/line 4/i);
});

// Catches dropping valid rows, coercing IDs, deduplicating, or rejecting boundaries.
test("preserves opaque IDs, duplicate visits, order and safe integer boundaries", () => {
  expect(parseLedger(
    '{"tenant":" b ","visitId":"0042","cents":9007199254740991}\n' +
    '{"tenant":"a","visitId":"0042","cents":-9007199254740991}\n' +
    '{"tenant":"a","visitId":"0042","cents":0}'
  )).toEqual([
    { tenant: " b ", visitId: "0042", cents: 9007199254740991 },
    { tenant: "a", visitId: "0042", cents: -9007199254740991 },
    { tenant: "a", visitId: "0042", cents: 0 },
  ]);
});

test("ignores whitespace-only lines between CRLF records", () => {
  expect(parseLedger('\r\n{"tenant":"a","visitId":"001","cents":-50}\r\n \t\r\n'))
    .toEqual([{ tenant: "a", visitId: "001", cents: -50 }]);
});

test("accepts a leading BOM without changing the first ID", () => {
  expect(parseLedger('\ufeff{"tenant":"a","visitId":"0042","cents":250}\n'))
    .toEqual([{ tenant: "a", visitId: "0042", cents: 250 }]);
});

test("empty and blank ledgers produce no entries", () => {
  expect(parseLedger("")).toEqual([]);
  expect(parseLedger("\n \t\r\n")).toEqual([]);
});
