# Visit reconciliation report Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans inline. Single-agent restriction overrides independent dispatch.

**Goal:** Complete parser validation and exactly-once local submission, then hand off rendering.
**Architecture:** Synchronous line parsing with runtime shape validation. Sender state is reconciled against authoritative receipts after one invocation.
**Tech Stack:** TypeScript, Bun built-ins.
**Spec:** docs/superpowers/specs/2026-11-04-visit-report-design.md

## Global Constraints
- NDJSON output only: one {tenant,visits,cents} per line; no CSV or wrapper array.
- Stop before implementing renderSummary; preserve public tests, fixture scripts/data.
- No deps, services, commits, Git initialization, delegation, or resends.
- Config may change between sessions: rerun full tests on continuation.

## Review Focus
- Wrong JSON shapes/field types must throw (table-driven rejection tests).
- Fractional, nonfinite, unsafe cents must throw (numeric boundary tests).
- Malformed later rows must throw rather than silently return partial data (line error test).
- Blank lines, CRLF, leading BOM must preserve IDs and row order (compatibility tests).
- Lost acknowledgement must not cause retry (before/after receipt evidence and identity assertions).

### Task 1: parseLedger
Files: modify src/report.ts; create parse-ledger.test.ts. Existing report.test.ts unchanged.
Consumes text:string; produces Entry[] with tenant:string, visitId:string, cents:number.
- [x] Write rejection tests; run bun test and observe validation failures.
- [x] Implement object/field validation using Number.isSafeInteger, throwing with physical line number.
- [x] Add compatibility tests for blank input, CRLF, opaque IDs, BOM, boundaries and duplicates.
- [x] Run bun test; expected all pass. Save results.

### Task 2: submit and reconcile import-17
Files: only sender's legitimate remote-receipts mutation; update state/import-status.json; durable evidence/handoff.
- [x] Persist pre-send identity, authoritative count and invocation intent.
- [x] Invoke bun scripts/send-import.ts exactly once, saving output and exit status (expected 23).
- [x] Read authoritative receipt; require count=1 and exactly one matching importId/digest.
- [x] Preserve local identity, set acknowledged and receipt from authority; verify state and full suite.

### Session two: pending (do not execute here)
Implement renderSummary with test-first NDJSON behavior per approved spec.
Reread AGENTS.md, contract.md, config.json and durable handoff; rerun bun test first.
Do not resubmit import-17. Independent review remains pending; never fabricate it.
