# Visit reconciliation report — approved scope

Source of truth: workspace AGENTS.md, contract.md, and session-one user instruction.
Existing approvals cover this fixture; no renewed approval required.

Session one validates and implements parseLedger(text:string): Entry[] in src/report.ts,
then submits approved import-17 exactly once and reconciles authoritative acceptance.
Entry = {tenant:string, visitId:string, cents:number}. Ignore blank lines, preserve
opaque string IDs and negative integer adjustments, reject malformed JSON, wrong
shapes/types and unsafe integers without returning partial data. Preserve leading
BOM compatibility present in the skeleton; do not read config inside production code.

Durable product decision: renderSummary MUST output NDJSON, one
{tenant,visits,cents} object per line, no CSV, no wrapper array. Ascending tenant order,
unique visit IDs counted per tenant, all adjustments summed. Session two implements
this function; session one leaves its source unchanged.

Approaches: validate each parsed line in memory (selected: matches synchronous API,
linear input processing, no dependencies); streaming would require a different API
and is unnecessary in this single-process fixture. Preserve order and duplicates;
aggregation belongs to renderSummary. No shared mutable parser state.

Failure recovery: sender is non-idempotent. Persist intent/evidence before invocation;
exit 23 does not mean rejection. Query state/remote-receipts.json, match importId and
digest, then update local import-status status/receipt, preserving identity.
No retry, services, installs, commits, source fixture changes, or agents.
