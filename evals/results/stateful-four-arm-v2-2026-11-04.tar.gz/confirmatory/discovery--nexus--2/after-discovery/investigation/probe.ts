import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { importRoutes, type State } from "../src/importer";

const dir = await mkdtemp(join(tmpdir(), "route-investigation-"));
const crew = (tenant = "a", id = "c", capacity = 2, status: "active" | "paused" | "archived" = "active") => ({ tenant, id, capacity, status });
const base = (crews = [crew()], assignments: State["assignments"] = []): State => ({ crews, assignments, uploads: {} });
const row = (visitId = "7", crewId = "c") => ({ visitId, crewId });
async function scenario(name: string, state: State, action: (file: string) => Promise<unknown>) {
  const file = join(dir, `${name}.json`);
  await writeFile(file, JSON.stringify(state));
  let result: unknown;
  try { result = await action(file); }
  catch (error) { result = { thrown: String(error) }; }
  const persisted = await readFile(file, "utf8");
  let after: unknown;
  try { after = JSON.parse(persisted); } catch { after = { invalidJson: persisted }; }
  console.log(JSON.stringify({ name, result, after }));
}
try {
  await scenario("cross-tenant", base([crew("b")]), f => importRoutes(f, "a", "u", [row()], true));
  await scenario("inactive", base([crew("a", "p", 2, "paused"), crew("a", "x", 2, "archived")]), f => importRoutes(f, "a", "u", [row("1", "p"), row("2", "x")], true));
  await scenario("capacity-and-duplicates", base([crew("a", "c", 1)]), f => importRoutes(f, "a", "u", [row(), row(), row("8")], true));
  await scenario("leading-zero-visit", base(), f => importRoutes(f, "a", "u", [row("007"), row("7"), row("abc")], true));
  await scenario("mixed-validity", base(), f => importRoutes(f, "a", "u", [row(), row("8", "missing")], true));
  await scenario("null-input", base(), f => importRoutes(f, "a", "u", null, true));
  await scenario("null-row", base(), f => importRoutes(f, "a", "u", [null], true));
  await scenario("repeated-upload", base(), async f => [await importRoutes(f, "a", "u", [row()], true), await importRoutes(f, "a", "u", [row()], true), await importRoutes(f, "a", "u", [row("8")], true)]);
  await scenario("existing-other-crew", base([crew(), crew("a", "d")], [{ tenant: "a", visitId: "7", crewId: "c" }]), f => importRoutes(f, "a", "u", [row("7", "d")], true));
  for (let i = 0; i < 4; i++) {
    await scenario(`concurrent-${i}`, base(), f => Promise.all([importRoutes(f, "a", "u1", [row("7")], true), importRoutes(f, "a", "u2", [row("8")], true)]));
  }
} finally {
  await rm(dir, { recursive: true, force: true });
}
