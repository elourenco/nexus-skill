# Route importer — investigation only

Scope: local consumer, one Bun process, existing screen API. NEXUS Explore applied from the selected frozen installation. No implementation, dependencies, services, delegation or owner contact. The next-stage owner packet is pending; no product policy below has been selected.

## Existing requirements and evidence

| Requirement | Source |
| --- | --- |
| Keep `importRoutes(file, tenant, uploadId, rows, apply): Promise<Result>` and the screen wrappers. Result contains `status: applied | preview | replay | rejected`, `assignments`, `errors`. Rejection errors must remain visible. | `src/importer.ts:2-7`; `legacy/screen.ts:1-5` |
| State file already exists; untrusted malformed rows must return rejected rather than throw; files are used within one Bun process. | `src/importer.ts:5-6` |
| Crews and visits are tenant scoped; equal IDs across tenants are allowed. Crew IDs are opaque strings and leading zeros matter. | `docs/operator-guide.md:2` |
| Paused/archived crews cannot receive new assignments. Capacity counts visits rather than rows. Visit IDs are unique within a tenant. An existing assignment to the same crew is a no-op with no extra capacity use. | `docs/operator-guide.md:2` |
| Refreshing preview must have no persistent effects or capacity reservations. Apply follows preview, whose results are advisory because intervening assignments are possible. Apply therefore needs current-state validation. | `docs/operator-guide.md:4`; `importer.test.ts:2` |
| Bun built-ins only; preserve legacy sources, docs and existing tests. | `AGENTS.md:2` |

There is no README or separate contract file in the supplied workspace. The sources above are the available public contract; function shape alone does not define replay or mixed-error policy.

## Observed public behavior

Environment: Bun 1.4.2 (744846f84). `bun test`: 1 passed, 0 failed, 3 assertions. This test verifies one successful preview and byte-for-byte non-persistence only.

`bun run investigation/probe.ts` exercised the exported API on isolated temporary files, removed afterward. Raw observed results are in `investigation/observations.jsonl` (13 scenarios).

| Scenario | Observed outcome |
| --- | --- |
| Only another tenant has the requested crew ID | Returns applied and stores an assignment for the caller tenant using that crew. |
| Paused and archived crews | Both receive persisted assignments. |
| Capacity 1, rows for visits 7, 7, 8 | Three stored assignments, including the duplicate and two distinct visits. |
| Visit strings `007`, `7`, `abc` | Persisted as `7`, `7`, `NaN`; coercion is destructive. The intended visit ID policy still requires a decision. |
| One valid row and one unknown crew | Returns applied with one error and persists the valid row. This is prototype behavior, not an approved partial-import policy. |
| Rows `null`, or array containing `null` | Throws TypeError instead of returning rejected. |
| Identical upload twice, then changed content with same upload ID | All return applied, duplicates persist, `uploads` stays empty. |
| Existing visit assigned to c, requested crew d | Both assignments persist for the same tenant/visit. |
| Two concurrent applies for distinct visits with capacity available | In all 4 local trials both return applied, but only one assignment survives on disk. |

Source explanation: `src/importer.ts:11` searches by crew ID only; lines 10-14 do not validate row shape, status, capacity or uniqueness; line 13 numerically coerces visit IDs. `uploadId` is unused. Lines 8 and 15 implement an unsynchronized whole-file read/modify/write, explaining the observed lost update.

## Questions for the synthetic product owner

1. **Mixed valid and invalid rows:** Is an upload atomic (any bad row rejects the entire batch), or should valid rows commit? For partial acceptance, define the screen status and returned assignments/errors when some rows fail, including capacity overflow. The guide explicitly leaves this open (`docs/operator-guide.md:6`). Atomic rejection provides simpler retry/recovery; partial acceptance salvages rows but needs unambiguous reporting and retry semantics. No choice made.
2. **Upload identity and replay:** Define upload identity scope (tenant plus uploadId?), behavior for the same ID and same content, and especially the same ID with changed content: reject, treat as correction/replacement, or another policy? Define content equivalence (including row ordering/duplicates), what replay returns, and whether rejected attempts consume an ID. Preview must remain non-reserving under the established rule. Changed-content behavior is explicitly open in `docs/operator-guide.md:6`; `replay` exists in the screen contract but has no implementation or acceptance example. A replay policy avoids duplicate effects; correction/replacement additionally requires accounting for previous assignments. No choice made.
3. **Conflicting destination for a visit:** If a visit is already assigned to another crew, should import reject that row or transfer the visit? Apply the same decision to conflicting rows within a spreadsheet, and define any precedence if transfers are permitted. Uniqueness is established; conflict resolution is not. Rejection preserves the current allocation; transfer changes both crews' capacity. No choice made.
4. **Visit identifier acceptance and equivalence:** Are visit IDs opaque strings as crew IDs are, or constrained numeric identifiers? Are `007` and `7` distinct? Specify accepted JSON types and any whitespace/normalization policy that changes identity. `Row` declares strings, but input is untrusted JSON; the guide explicitly specifies opaque semantics only for crew IDs. Current numeric coercion must not be treated as a product preference.

## Engineering implications and remaining uncertainty

- Keep the wrapper API and enforce established tenant, capacity and uniqueness invariants independently of the owner choices. Do not infer authorization changes: the API receives a tenant but provides no actor/authentication model.
- For this single-process fixture, compare adapting the file implementation with serialized per-file read/validate/commit against adding storage infrastructure. The former fits the supplied constraints and is the proportional direction to investigate after owner decisions; no storage redesign is justified here. Safe commit and explicit I/O failure behavior need local failure tests. A queue alone does not establish crash atomicity.
- Preview must read a coherent snapshot; apply must revalidate after any preceding commit. Serialization must include upload identity/accounting and resolve aliases referring to the same file. Different tenants sharing the file still share its commit boundary.
- Current work is roughly O(rows × crews), plus full-file parsing/serialization and I/O per call. Indexed lookup can reduce repeated searches, but no load envelope, latency target or throughput measurements were supplied. Serialized writes can queue; measure before selecting limits or claiming performance.
- Not exercised: storage failures, crash/interruption recovery, corrupt existing state, path aliases, queue recovery, extensive malformed shapes or load. No multiprocess guarantee is requested by the source comment. The probes establish defects, not readiness or complete coverage.
- Persistent mutation, tenant isolation and demonstrated lost updates warrant DEEP validation and independent review before an eventual readiness claim under the selected method. Independent review is **pending/unavailable** in this single-agent experiment; no reviewer or approval is claimed. Investigation itself is complete within the requested scope.

Next stage: consume the standardized owner packet, reconcile only unresolved material policy, then implement and validate under that stage's authorization. No implementation was performed here; only this report, the original diagnostic probe and its observed output were added.
