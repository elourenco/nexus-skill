import { open, readFile, realpath, rename, stat, unlink } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";

export type Row = { visitId: string; crewId: string };
export type State = {
  crews: { tenant: string; id: string; status: "active" | "paused" | "archived"; capacity: number }[];
  assignments: { tenant: string; visitId: string; crewId: string }[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: "applied" | "preview" | "replay" | "rejected";
  assignments: State["assignments"];
  errors: string[];
};
type Upload = { version: 1; tenant: string; uploadId: string; rows: Row[]; assignments: State["assignments"] };
const queues = new Map<string, Promise<void>>();
const key = (first: string, second: string) => JSON.stringify([first, second]);
const rejected = (...errors: string[]): Result => ({ status: "rejected", assignments: [], errors });
const object = (value: unknown): value is Record<string, unknown> => value !== null && typeof value === "object" && !Array.isArray(value);
const isRow = (value: unknown): value is Row => object(value) && typeof value.visitId === "string" && typeof value.crewId === "string";
const isAssignment = (value: unknown): value is State["assignments"][number] => isRow(value) && "tenant" in value && typeof value.tenant === "string";
const isUpload = (value: unknown): value is Upload => object(value) && value.version === 1 &&
  typeof value.tenant === "string" && typeof value.uploadId === "string" &&
  Array.isArray(value.rows) && value.rows.every(isRow) &&
  Array.isArray(value.assignments) && value.assignments.every(a => isAssignment(a) && a.tenant === value.tenant);

function parseState(value: unknown): State {
  if (!object(value) || !Array.isArray(value.crews) || !Array.isArray(value.assignments) || !object(value.uploads)) {
    throw new Error("invalid state shape");
  }
  if (!value.crews.every(c => object(c) && typeof c.tenant === "string" && typeof c.id === "string" &&
    ["active", "paused", "archived"].includes(c.status as string) && Number.isSafeInteger(c.capacity) && (c.capacity as number) >= 0) ||
    !value.assignments.every(isAssignment) ||
    !Object.entries(value.uploads).every(([id, upload]) => isUpload(upload) && id === key(upload.tenant, upload.uploadId))) {
    throw new Error("invalid state records");
  }
  // All persisted fields used below have been checked at the file boundary.
  return value as State;
}

function indexes(state: State) {
  const crews = new Map<string, State["crews"][number]>();
  const visits = new Map<string, string>();
  const counts = new Map<string, number>();
  for (const crew of state.crews) {
    const id = key(crew.tenant, crew.id);
    if (crews.has(id)) throw new Error("duplicate crew in state");
    crews.set(id, crew);
  }
  for (const assignment of state.assignments) {
    const visit = key(assignment.tenant, assignment.visitId);
    const crew = key(assignment.tenant, assignment.crewId);
    if (visits.has(visit) || !crews.has(crew)) throw new Error("inconsistent assignments in state");
    visits.set(visit, assignment.crewId);
    counts.set(crew, (counts.get(crew) ?? 0) + 1);
  }
  return { crews, visits, counts };
}

// One process owns all writes. Real paths merge relative/absolute/symlink aliases.
// Queue entries never reject, and an idle queue releases its path and state.
async function serialized<T>(file: string, action: () => Promise<T>): Promise<T> {
  const previous = queues.get(file) ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>(resolve => { release = resolve; });
  queues.set(file, current);
  await previous;
  try { return await action(); }
  finally {
    release();
    if (queues.get(file) === current) queues.delete(file);
  }
}

async function commit(file: string, state: State): Promise<void> {
  const temporary = join(dirname(file), `.routes-${randomUUID()}.tmp`);
  const mode = (await stat(file)).mode & 0o777;
  const handle = await open(temporary, "wx", mode);
  try {
    await handle.writeFile(JSON.stringify(state), "utf8");
    await handle.sync();
    await handle.close();
    // The only commit point: assignments and upload identity become visible together.
    await rename(temporary, file);
  } finally {
    await handle.close().catch(() => {});
    await unlink(temporary).catch(() => {});
  }
}

function decide(state: State, tenant: string, uploadId: string, rows: Row[], apply: boolean): Result {
  const { crews, visits, counts } = indexes(state);
  const identity = key(tenant, uploadId);
  if (Object.hasOwn(state.uploads, identity)) {
    const upload = state.uploads[identity];
    if (!isUpload(upload)) throw new Error("invalid upload record");
    if (JSON.stringify(upload.rows.map(r => [r.visitId, r.crewId])) !== JSON.stringify(rows.map(r => [r.visitId, r.crewId]))) {
      return rejected("uploadId already used with different ordered rows");
    }
    return { status: "replay", assignments: upload.assignments.map(a => ({ ...a })), errors: [] };
  }

  const assignments: State["assignments"] = [];
  const errors: string[] = [];
  rows.forEach((row, index) => {
    const fail = (reason: string) => { errors.push(`row ${index + 1}: ${reason}`); };
    const crewKey = key(tenant, row.crewId);
    const crew = crews.get(crewKey);
    if (!crew) { fail("unknown crew in tenant"); return; }
    const visitKey = key(tenant, row.visitId);
    const assigned = visits.get(visitKey);
    if (assigned !== undefined) {
      if (assigned !== row.crewId) fail("visit assigned to another crew");
      return;
    }
    if (crew.status !== "active") { fail("crew is not active"); return; }
    const count = counts.get(crewKey) ?? 0;
    if (count >= crew.capacity) { fail("crew capacity exceeded"); return; }
    visits.set(visitKey, row.crewId);
    counts.set(crewKey, count + 1);
    assignments.push({ tenant, visitId: row.visitId, crewId: row.crewId });
  });
  if (errors.length) return rejected(...errors);
  if (apply) {
    state.assignments.push(...assignments);
    state.uploads[identity] = { version: 1, tenant, uploadId, rows, assignments } satisfies Upload;
  }
  return { status: apply ? "applied" : "preview", assignments, errors: [] };
}

// Existing screen API. IDs remain exact strings; untrusted JSON is never coerced.
// Preview holds no reservation. Apply reads and revalidates inside the file queue.
export async function importRoutes(file: string, tenant: string, uploadId: string, rows: unknown, apply: boolean): Promise<Result> {
  try {
    if (typeof file !== "string" || typeof tenant !== "string" || typeof uploadId !== "string" || typeof apply !== "boolean") {
      return rejected("invalid import arguments");
    }
    if (!Array.isArray(rows)) return rejected("rows must be an array");
    const input: Row[] = [];
    const errors: string[] = [];
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!isRow(row)) errors.push(`row ${i + 1}: visitId and crewId must be strings`);
      else input.push({ visitId: row.visitId, crewId: row.crewId });
    }
    if (errors.length) return rejected(...errors);
    const canonical = await realpath(file);
    return await serialized(canonical, async () => {
      let state: State;
      let result: Result;
      try {
        state = parseState(JSON.parse(await readFile(canonical, "utf8")));
        result = decide(state, tenant, uploadId, input, apply);
      } catch {
        return rejected("state unavailable or invalid; no changes committed");
      }
      if (result.status === "applied") {
        try { await commit(canonical, state); }
        catch { return rejected("state commit failed; no changes committed"); }
      }
      return result;
    });
  } catch {
    return rejected("input or state file unavailable; no changes committed");
  }
}
