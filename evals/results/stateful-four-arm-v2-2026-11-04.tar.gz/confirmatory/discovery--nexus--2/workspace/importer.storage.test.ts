import { test, expect, spyOn } from "bun:test";
import * as fs from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { importRoutes } from "./src/importer";

async function fixture(run: (file: string, dir: string) => Promise<void>) {
  const dir = await fs.mkdtemp(join(tmpdir(), "routes-storage-"));
  try {
    const file = join(dir, "state.json");
    await fs.writeFile(file, JSON.stringify({ crews: [{ tenant: "a", id: "c", status: "active", capacity: 2 }], assignments: [], uploads: {} }));
    await run(file, dir);
  } finally { await fs.rm(dir, { recursive: true, force: true }); }
}
const rows = [{ visitId: "7", crewId: "c" }];

test("rename failure leaves original bytes and identity intact; retry recovers", async () => {
  await fixture(async (file, dir) => {
    const before = await fs.readFile(file, "utf8");
    const rename = spyOn(fs, "rename").mockRejectedValue(new Error("injected rename failure"));
    try {
      const failed = await importRoutes(file, "a", "u", rows, true);
      expect(rename).toHaveBeenCalledTimes(1);
      expect(failed.status).toBe("rejected"); expect(failed.errors.length).toBeGreaterThan(0); expect(failed.assignments).toEqual([]);
      expect(await fs.readFile(file, "utf8")).toBe(before);
      expect(await fs.readdir(dir)).toEqual(["state.json"]);
    } finally { rename.mockRestore(); }
    expect((await importRoutes(file, "a", "u", rows, true)).status).toBe("applied");
    expect((await importRoutes(file, "a", "u", rows, true)).status).toBe("replay");
  });
});

test("partial temporary write failure never truncates live state and cleans temporary file", async () => {
  await fixture(async (file, dir) => {
    const before = await fs.readFile(file, "utf8");
    const originalOpen = fs.open;
    const open = spyOn(fs, "open").mockImplementation(async (...args: Parameters<typeof fs.open>) => {
      const handle = await originalOpen(...args);
      const originalWrite = handle.writeFile.bind(handle);
      handle.writeFile = async () => { await originalWrite("{partial"); throw new Error("injected disk write failure"); };
      return handle;
    });
    try {
      const failed = await importRoutes(file, "a", "u", rows, true);
      expect(open).toHaveBeenCalledTimes(1); expect(failed.status).toBe("rejected");
      expect(failed.assignments).toEqual([]); expect(failed.errors.length).toBeGreaterThan(0);
      expect(await fs.readFile(file, "utf8")).toBe(before);
      expect(await fs.readdir(dir)).toEqual(["state.json"]);
    } finally { open.mockRestore(); }
    expect((await importRoutes(file, "a", "u", rows, true)).status).toBe("applied");
  });
});

test("persisted upload replays in a fresh Bun runtime without memory of the first call", async () => {
  await fixture(async file => {
    const applied = await importRoutes(file, "a", "u", rows, true);
    expect(applied.status).toBe("applied");
    const before = await fs.readFile(file, "utf8");
    const code = `import { importRoutes } from ${JSON.stringify(join(import.meta.dir, "src/importer.ts"))}; console.log(JSON.stringify(await importRoutes(${JSON.stringify(file)}, "a", "u", ${JSON.stringify(rows)}, true)));`;
    const process = Bun.spawn([Bun.which("bun")!, "--eval", code], { stdout: "pipe", stderr: "pipe" });
    const output = await new Response(process.stdout).text();
    expect(await process.exited).toBe(0);
    expect(JSON.parse(output)).toEqual({ ...applied, status: "replay" });
    expect(await fs.readFile(file, "utf8")).toBe(before);
  });
});
