# Local importer implementation outcome

## Scope and decisions

Applied the selected frozen NEXUS build procedure with DEEP validation for persistent tenant isolation, replay and concurrency invariants. Existing investigation is preserved in `investigation/findings.md`. The owner packet supplied with this implementation request resolves atomic batches, tenant + uploadId identity, ordered-row replay, changed-content rejection and conflicting-assignment rejection. The user's instruction authorizes local implementation and tests; the synthetic packet is product data, not external authorization.

Public API types, signature and screen wrappers remain intact. All rejections contain errors and no accepted assignments. A rejected batch leaves the original file bytes untouched and does not consume its identity. Preview does not write or reserve anything. A committed upload replays its original added assignments, including when the caller previews that upload again; it never writes again. New uploads return only newly added unique assignments, excluding same-crew no-ops.

The packet does not specify a new visit-ID grammar or normalization policy. This implementation follows the declared string fields without coercion: `007`, `7` and `alpha` retain their exact strings. Non-string IDs reject. Any narrower grammar or equivalence rule remains a product decision; none has been invented. Row content identity uses the declared `(visitId, crewId)` fields in exact order, including duplicates; object property order and undeclared fields are not part of the Row contract.

## Implementation

- `src/importer.ts`: runtime input/state validation, indexed tenant/crew/visit checks, atomic batch decisions and persistent versioned upload records.
- Canonical-path queue serializes read/validate/commit for each file, including symlink aliases. Different files have independent queues. Input rows are copied before awaiting I/O.
- A same-directory exclusive temporary file is written, synced and closed before rename. Rename is the commit point for assignments and upload identity together. Failure before rename leaves the original file intact; temporary cleanup and queue release run on failure.
- Unsupported or inconsistent existing state is rejected without automatic repair. No legacy data migration or upload-ledger expiry is attempted.

## Observed verification

Environment: Bun 1.4.2 (744846f84), local fixture, no dependencies or services.

Before implementation: `bun test` produced 1 pass / 15 failures. The public preview test passed; all 15 added behavioral regressions failed against the preserved prototype. Output: `implementation/before-tests.txt`; source snapshot: `implementation/importer.before.ts`.

Final implementation: `bun test` produced **19 pass / 0 fail / 160 assertions**, across 3 test files, reported total 123 ms. Output: `implementation/after-tests.txt`.

Coverage:

| Invariant / failure | Observed test |
| --- | --- |
| Untrusted JSON, atomic rejection, identity reusable after rejection | Malformed inputs and mixed-validity batch tests; byte equality on rejection |
| Tenant and opaque identifier boundaries | Tenant-scoped crew/upload/visit checks, exact string preservation, tuple-key collision/prototype names |
| Capacity, inactive crews, no-ops and conflicting destinations | Existing/new distinct visits, duplicate rows, paused/archived no-ops, intra-batch and persisted conflicts |
| Preview advisory semantics | Repeated preview has no persistent effect; intervening apply makes original apply reject |
| Persistent replay and content conflicts | Identical replay returns original effects; reordered/extra rows reject; replay in fresh Bun runtime |
| Concurrent dispatchers | 20 concurrent unique applies at capacity 1 and 20; 10 identical concurrent uploads yield 1 applied + 9 replay; competing contents yield 1 applied + 1 rejected |
| Shared path aliases and caller-owned inputs | Symlink and canonical path preserve both writes; mutation of caller rows after invocation cannot change queued content |
| Storage failure and recovery | Injected partial temporary write and rename failure leave original bytes, clean temporary files, release queue and permit retry |
| Persisted corruption and file absence | Reject without overwrite; queue succeeds after explicit fixture repair |

The final source diff was inspected against the before copy. Public AGENTS.md, docs/operator-guide.md, legacy/screen.ts, importer.test.ts and investigation artifacts were preserved. There is no workspace Git metadata; no repository was initialized.

## Limits and pending gate

**Independent review remains pending/unavailable** under the required single-agent experiment. Self-inspection and passing tests do not satisfy the NEXUS independent DEEP review gate; no reviewer or approval is claimed.

Coordination covers calls through this module in one Bun process. Multiple writer processes, external writers and hard-link aliases are unsupported. A fresh-runtime replay test is sequential, not a multiprocess concurrency guarantee. No forced crash, filesystem power-loss or directory-fsync durability test was performed; a process interruption before rename may leave an unused temporary file. Directory entries are not fsynced, so power-loss durability is not claimed.

Indexed decisions avoid the prototype's repeated crew scan. Every operation still parses/validates the complete state and retained upload history; every accepted apply serializes and writes it. Per-file serialization and file sync bound throughput and add queue latency. Upload history has no supplied retention policy. The finite concurrency scenarios validate correctness, not production throughput, sustained-load latency or a resource limit. No latency SLO or load envelope was supplied. Bun executes TypeScript tests but no separate static typecheck was run.

No delegation, external services, network access, credentials, installs, commits, publication or method-installation edits were used.
