import { test, expect } from "bun:test";
import { mkdtemp, readFile, writeFile, rm, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { importRoutes, type State } from "./src/importer";

const crew = (tenant = "a", id = "c", capacity = 3, status: "active" | "paused" | "archived" = "active") => ({ tenant, id, capacity, status });
const row = (visitId = "7", crewId = "c") => ({ visitId, crewId });
const base = (crews = [crew()], assignments: State["assignments"] = []): State => ({ crews, assignments, uploads: {} });
async function fixture(state: State, run: (file: string) => Promise<void>) {
  const dir = await mkdtemp(join(tmpdir(), "routes-test-"));
  try { const file = join(dir, "state.json"); await writeFile(file, JSON.stringify(state)); await run(file); }
  finally { await rm(dir, { recursive: true, force: true }); }
}
async function unchanged(file: string, action: () => ReturnType<typeof importRoutes>) {
  const before = await readFile(file, "utf8");
  const result = await action();
  expect(result.status).toBe("rejected"); expect(result.assignments).toEqual([]); expect(result.errors.length).toBeGreaterThan(0);
  expect(await readFile(file, "utf8")).toBe(before);
}

test("malformed JSON values reject atomically and never throw", async () => {
  await fixture(base(), async file => {
    for (const rows of [null, {}, "rows", 1, [null], [false], [[]], [{}], [row(), { visitId: 8, crewId: "c" }], [{ visitId: "8", crewId: 1 }]]) {
      await unchanged(file, () => importRoutes(file, "a", "u", rows, true));
    }
  });
});
test("atomic batch failure does not consume upload identity", async () => {
  await fixture(base(), async file => {
    await unchanged(file, () => importRoutes(file, "a", "u", [row(), row("8", "missing")], true));
    expect((await importRoutes(file, "a", "u", [row()], true)).status).toBe("applied");
  });
});
test("tenant lookup, visit uniqueness and upload scope are isolated", async () => {
  await fixture(base([crew("a"), crew("b"), crew("b", "foreign")]), async file => {
    await unchanged(file, () => importRoutes(file, "a", "bad", [row("8", "foreign")], true));
    for (const tenant of ["a", "b"]) expect((await importRoutes(file, tenant, "u", [row()], true)).status).toBe("applied");
    expect(JSON.parse(await readFile(file, "utf8")).assignments).toHaveLength(2);
  });
});
test("opaque crew and string visit IDs retain exact bytes", async () => {
  await fixture(base([crew("a", "007"), crew("a", "7")]), async file => {
    const rows = [row("007", "007"), row("7", "7"), row("alpha", "007")];
    const result = await importRoutes(file, "a", "u", rows, true);
    expect(result.status).toBe("applied");
    expect(result.assignments).toEqual(rows.map(r => ({ tenant: "a", ...r })));
  });
});
test("inactive crews reject new visits but existing same-crew assignments are no-ops", async () => {
  for (const status of ["paused", "archived"] as const) {
    await fixture(base([crew("a", "c", 1, status)], [{ tenant: "a", ...row() }]), async file => {
      await unchanged(file, () => importRoutes(file, "a", "bad", [row("8")], true));
      const result = await importRoutes(file, "a", "u", [row(), row()], true);
      expect(result.status).toBe("applied"); expect(result.assignments).toEqual([]);
    });
  }
});
test("capacity counts unique visits including existing assignments", async () => {
  await fixture(base([crew("a", "c", 2)], [{ tenant: "a", ...row() }]), async file => {
    await unchanged(file, () => importRoutes(file, "a", "bad", [row("8"), row("9")], true));
    const result = await importRoutes(file, "a", "u", [row(), row("8"), row("8")], true);
    expect(result.status).toBe("applied"); expect(result.assignments).toEqual([{ tenant: "a", ...row("8") }]);
    expect(JSON.parse(await readFile(file, "utf8")).assignments).toHaveLength(2);
  });
});
test("conflicting destinations reject both within batch and against stored visits", async () => {
  await fixture(base([crew(), crew("a", "d")]), async file => {
    await unchanged(file, () => importRoutes(file, "a", "bad", [row(), row("7", "d")], true));
    await importRoutes(file, "a", "u", [row()], true);
    await unchanged(file, () => importRoutes(file, "a", "bad", [row("7", "d")], true));
  });
});
test("replay retains original effects and changed ordered rows reject without mutation", async () => {
  await fixture(base(), async file => {
    const rows = [row(), row("8")];
    const first = await importRoutes(file, "a", "u", rows, true);
    expect(first.status).toBe("applied");
    const before = await readFile(file, "utf8");
    first.assignments.length = 0;
    const replay = await importRoutes(file, "a", "u", rows, true);
    expect(replay.status).toBe("replay"); expect(replay.assignments).toHaveLength(2);
    expect(await readFile(file, "utf8")).toBe(before);
    await unchanged(file, () => importRoutes(file, "a", "u", [...rows].reverse(), true));
    await unchanged(file, () => importRoutes(file, "a", "u", [...rows, row("8")], true));
  });
});
test("preview never reserves identity or capacity; apply revalidates", async () => {
  await fixture(base([crew("a", "c", 1)]), async file => {
    const before = await readFile(file, "utf8");
    for (let i = 0; i < 2; i++) expect((await importRoutes(file, "a", "u", [row()], false)).status).toBe("preview");
    expect(await readFile(file, "utf8")).toBe(before);
    expect((await importRoutes(file, "a", "other", [row("8")], true)).status).toBe("applied");
    await unchanged(file, () => importRoutes(file, "a", "u", [row()], true));
  });
});
test("concurrent applies cannot lose writes or oversubscribe capacity", async () => {
  for (const capacity of [1, 20]) await fixture(base([crew("a", "c", capacity)]), async file => {
    const results = await Promise.all(Array.from({ length: 20 }, (_, i) => importRoutes(file, "a", `u${i}`, [row(String(i))], true)));
    expect(results.filter(r => r.status === "applied")).toHaveLength(capacity);
    expect(results.filter(r => r.status === "rejected")).toHaveLength(20 - capacity);
    const state = JSON.parse(await readFile(file, "utf8"));
    expect(state.assignments).toHaveLength(capacity); expect(Object.keys(state.uploads)).toHaveLength(capacity);
  });
});
test("concurrent identical upload has one commit and changed content cannot win twice", async () => {
  await fixture(base(), async file => {
    const results = await Promise.all(Array.from({ length: 10 }, () => importRoutes(file, "a", "u", [row()], true)));
    expect(results.filter(r => r.status === "applied")).toHaveLength(1);
    expect(results.filter(r => r.status === "replay")).toHaveLength(9);
    const competing = await Promise.all(["8", "9"].map(id => importRoutes(file, "a", "v", [row(id)], true)));
    expect(competing.map(r => r.status).sort()).toEqual(["applied", "rejected"]);
    expect(JSON.parse(await readFile(file, "utf8")).assignments).toHaveLength(2);
  });
});
test("symbolic file aliases share serialization", async () => {
  await fixture(base([crew("a", "c", 2)]), async file => {
    const alias = `${file}.link`; await symlink(file, alias);
    const results = await Promise.all([importRoutes(file, "a", "u", [row()], true), importRoutes(alias, "a", "v", [row("8")], true)]);
    expect(results.map(r => r.status)).toEqual(["applied", "applied"]);
    expect(JSON.parse(await readFile(file, "utf8")).assignments).toHaveLength(2);
    expect(await readFile(alias, "utf8")).toBe(await readFile(file, "utf8"));
  });
});
test("invalid persisted data rejects without overwrite; queue recovers after repair", async () => {
  await fixture(base(), async file => {
    for (const broken of ["{", JSON.stringify({}), JSON.stringify(base([crew(), crew()]))]) {
      await writeFile(file, broken);
      await unchanged(file, () => importRoutes(file, "a", "u", [row()], true));
    }
    await writeFile(file, JSON.stringify(base()));
    expect((await importRoutes(file, "a", "u", [row()], true)).status).toBe("applied");
    const missing = await importRoutes(`${file}.missing`, "a", "u", [], true);
    expect(missing.status).toBe("rejected"); expect(missing.errors.length).toBeGreaterThan(0);
  });
});
test("caller row mutation while queued cannot change accepted content", async () => {
  await fixture(base(), async file => {
    const rows = [row()]; const pending = importRoutes(file, "a", "u", rows, true); rows[0]!.visitId = "changed";
    expect((await pending).assignments).toEqual([{ tenant: "a", ...row() }]);
  });
});
test("tuple identities avoid delimiter collisions and prototype property names", async () => {
  await fixture(base([crew("a:b"), crew("a"), crew("__proto__")]), async file => {
    for (const [tenant, uploadId] of [["a:b", "c"], ["a", "b:c"], ["__proto__", "__proto__"]]) {
      expect((await importRoutes(file, tenant!, uploadId!, [row()], true)).status).toBe("applied");
      expect((await importRoutes(file, tenant!, uploadId!, [row()], true)).status).toBe("replay");
    }
  });
});
