# Local workflow

Specs and one-file-per-ticket issues live under .scratch/visit-report/.
Source of product requirements: contract.md plus .scratch/visit-report/spec.md.
State transitions and import evidence live in state/; entry point is HANDOFF.md.
This minimal local setup uses the user's existing scoped approvals. No external
tracker, steering-file modification or additional setup approval is needed.
