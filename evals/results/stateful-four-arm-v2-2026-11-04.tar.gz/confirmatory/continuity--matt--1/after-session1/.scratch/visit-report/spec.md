# Local visit reconciliation report

## Problem and solution
Validate persisted visit entries and produce deterministic tenant reconciliation reports.
The user's durable product decision is NDJSON: one {tenant,visits,cents} JSON
object per line. No CSV, wrapper array, headers or extra rows.

## User stories
1. Consumers receive only entries with string tenant and visit IDs and safe integer cents.
2. Negative adjustments and opaque IDs retain their original meaning.
3. Invalid lines cause parsing to fail rather than silently losing reconciliation data.
4. Consumers receive one total per tenant, ordered by ascending tenant.
5. Visits count unique visit IDs within each tenant; cents sum every entry,
   including repeated visit IDs and negative adjustments.
6. An accepted synthetic import is recovered from its authoritative receipt without resending.

## Implementation and testing decisions
Public seams are parseLedger(text:string):Entry[] and renderSummary(entries:Entry[]):string.
These are supplied by contract.md and explicitly scoped by the user; existing approval
is sufficient. Test public behavior with Bun built-ins, no mocks or dependencies.
Session one implements and validates parseLedger, then sends import-17 exactly once.
Session two implements renderSummary. Example from the unchanged fixture ledger:
{"tenant":"a","visits":1,"cents":200}
{"tenant":"b","visits":1,"cents":150}

## Scope and constraints
Single agent, workspace-only local effects, frozen Matt installation only.
No web, external services, installs, commits, Git initialization or publication.
Preserve public tests, scripts, fixture data and legacy sources. Independent
Standards and Spec review required by the method remains pending, not simulated.
Configuration is mutable between sessions: reread config.json and rerun tests.
Do not treat this session's green tests as proof about a later configuration.
