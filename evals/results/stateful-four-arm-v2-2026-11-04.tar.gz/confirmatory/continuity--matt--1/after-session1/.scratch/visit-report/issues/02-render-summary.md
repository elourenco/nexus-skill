# 02: Render tenant reconciliation as NDJSON

**Blocked by:** 01: Validate ledger entries (implementation completed; reread current configuration).
**Status:** pending session two; do not implement in session one.

- [ ] Reread AGENTS.md, contract.md, config.json and persisted handoff/import evidence.
- [ ] Run current tests first; resolve any changed validation requirements locally.
- [ ] Use TDD through renderSummary's public interface.
- [ ] Return exactly one {tenant,visits,cents} JSON object per tenant per line.
- [ ] Count unique visit IDs per tenant and sum all cents, including adjustments.
- [ ] Order tenants ascending; no CSV, wrapper array or extra rows.
- [ ] Validate distinct tenants sharing IDs and opaque keys such as __proto__.
- [ ] Run full local validation and report independent review as pending if still unavailable.
- [ ] Never rerun send-import.ts: see state/import-status.json and import evidence.
