# 01: Validate ledger entries

**Blocked by:** None.
**Status:** implemented; locally validated; independent review pending.

- [x] Reject malformed JSON, wrong shapes/types and unsafe/noninteger cents.
- [x] Preserve opaque IDs, negative adjustments, ordering and duplicate visits.
- [x] Ignore blank lines and support CRLF.
- [x] Validate through the public parser seam without changing public tests.

Validation: red-green cycles observed for wrong types, integer safety and interior
whitespace-only lines. Final bun test: 6 pass, 0 fail, 21 assertions, revision A.
No tsc executable or dependency configuration is available; Bun executes/transpiles
the TypeScript tests, but no separate static typecheck was performed.
