export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  return text.split("\n").filter((line) => line.trim().length > 0).map((line) => {
    const value: unknown = JSON.parse(line);
    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" || !Number.isSafeInteger(value.cents)
    ) {
      throw new Error("Invalid ledger entry");
    }
    return { tenant: value.tenant, visitId: value.visitId, cents: value.cents };
  });
}
export function renderSummary(entries:Entry[]):string{throw new Error("pending output format decision")}
