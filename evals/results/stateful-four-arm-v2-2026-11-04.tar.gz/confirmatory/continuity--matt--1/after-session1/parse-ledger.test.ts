import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

test("rejects wrong entry types rather than returning unvalidated ledger data", () => {
  expect(() => parseLedger('{"tenant":"a","visitId":"0042","cents":"250"}')).toThrow();
});

test("rejects malformed lines and every invalid entry shape without skipping data", () => {
  const valid = '{"tenant":"a","visitId":"0042","cents":250}';
  for (const invalid of [
    "{", "null", "[]", "42", '"entry"', "true", "{}",
    '{"tenant":1,"visitId":"v","cents":0}',
    '{"tenant":"a","visitId":42,"cents":0}',
    '{"tenant":"a","cents":0}',
    '{"tenant":"a","visitId":"v","cents":null}',
  ]) {
    expect(() => parseLedger(`${valid}\n${invalid}\n${valid}`)).toThrow();
  }
});

test("accepts safe integer boundaries and opaque empty or special IDs", () => {
  expect(parseLedger('{"tenant":"__proto__","visitId":"","cents":9007199254740991}\n{"tenant":"","visitId":"000","cents":-9007199254740991}')).toEqual([
    { tenant: "__proto__", visitId: "", cents: 9007199254740991 },
    { tenant: "", visitId: "000", cents: -9007199254740991 },
  ]);
});

test("preserves opaque IDs, repeated visits and negative adjustments across blank CRLF lines", () => {
  const input = '\r\n{"tenant":" b ","visitId":"001","cents":150}\r\n \t\r\n{"tenant":"a","visitId":"0042","cents":-50}\r\n{"tenant":"a","visitId":"0042","cents":0}\n';
  expect(parseLedger(input)).toEqual([
    { tenant: " b ", visitId: "001", cents: 150 },
    { tenant: "a", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: "0042", cents: 0 },
  ]);
  expect(parseLedger(" \t\r\n\n")).toEqual([]);
});

test("rejects fractional, unsafe and non-finite cents", () => {
  for (const cents of ["1.5", "9007199254740992", "-9007199254740992", "1e400"]) {
    expect(() => parseLedger(`{"tenant":"a","visitId":"v","cents":${cents}}`)).toThrow();
  }
});
