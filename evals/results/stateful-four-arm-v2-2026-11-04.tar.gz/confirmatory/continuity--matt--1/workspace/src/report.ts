export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const input = text.startsWith("\ufeff") ? text.slice(1) : text;
  return input.split("\n").filter((line) => line.trim().length > 0).map((line) => {
    const value: unknown = JSON.parse(line);
    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" || !Number.isSafeInteger(value.cents)
    ) {
      throw new Error("Invalid ledger entry");
    }
    return { tenant: value.tenant, visitId: value.visitId, cents: value.cents };
  });
}
export function renderSummary(entries: Entry[]): string {
  const tenants = new Map<string, { visits: Set<string>; cents: bigint }>();
  for (const entry of entries) {
    let total = tenants.get(entry.tenant);
    if (!total) {
      total = { visits: new Set<string>(), cents: 0n };
      tenants.set(entry.tenant, total);
    }
    total.visits.add(entry.visitId);
    total.cents += BigInt(entry.cents);
  }
  return [...tenants.keys()].sort().map((tenant) => {
    const total = tenants.get(tenant)!;
    const cents = Number(total.cents);
    if (!Number.isSafeInteger(cents)) {
      throw new RangeError(`Unsafe cents total for tenant ${JSON.stringify(tenant)}`);
    }
    return JSON.stringify({ tenant, visits: total.visits.size, cents });
  }).join("\n");
}
