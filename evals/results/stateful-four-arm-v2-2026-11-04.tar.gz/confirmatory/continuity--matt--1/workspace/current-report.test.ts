import { expect, test } from "bun:test";
import { parseLedger, renderSummary } from "./src/report";

test("accepts an initial UTF-8 BOM while preserving opaque string contents", () => {
  expect(parseLedger('\ufeff{"tenant":"a","visitId":"\ufeff0042","cents":-20}\r\n')).toEqual([
    { tenant: "a", visitId: "\ufeff0042", cents: -20 },
  ]);
});

test("renders the agreed fixture totals as ascending tenant NDJSON", () => {
  expect(renderSummary([
    { tenant: "b", visitId: "001", cents: 150 },
    { tenant: "a", visitId: "0042", cents: 250 },
    { tenant: "a", visitId: "0042", cents: -50 },
  ])).toBe('{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
});

test("keeps tenant visit sets independent, escapes opaque keys and leaves input unchanged", () => {
  const entries = [
    { tenant: "__proto__", visitId: "001", cents: 4 },
    { tenant: "constructor", visitId: "001", cents: 5 },
    { tenant: "__proto__", visitId: "1", cents: 7 },
    { tenant: "__proto__", visitId: "001", cents: -2 },
    { tenant: "", visitId: "", cents: 0 },
    { tenant: "a\n\"", visitId: "001", cents: 3 },
  ];
  const before = JSON.stringify(entries);
  expect(renderSummary(entries)).toBe(
    '{"tenant":"","visits":1,"cents":0}\n' +
    '{"tenant":"__proto__","visits":2,"cents":9}\n' +
    '{"tenant":"a\\n\\\"","visits":1,"cents":3}\n' +
    '{"tenant":"constructor","visits":1,"cents":5}',
  );
  expect(JSON.stringify(entries)).toBe(before);
  expect(renderSummary([...entries].reverse())).toBe(renderSummary(entries));
});

test("returns no rows for an empty report", () => {
  expect(renderSummary([])).toBe("");
});

test("sums integer cents exactly when large adjustments cancel", () => {
  const entries = [
    { tenant: "a", visitId: "v", cents: Number.MAX_SAFE_INTEGER },
    { tenant: "a", visitId: "v", cents: 2 },
    { tenant: "a", visitId: "v", cents: -Number.MAX_SAFE_INTEGER },
  ];
  expect(renderSummary(entries)).toBe('{"tenant":"a","visits":1,"cents":2}');
  expect(renderSummary([...entries].reverse())).toBe(renderSummary(entries));
});

test("fails rather than emitting rounded cents when a tenant total exceeds safe integers", () => {
  for (const sign of [1, -1]) {
    expect(() => renderSummary([
      { tenant: "a", visitId: "v", cents: sign * Number.MAX_SAFE_INTEGER },
      { tenant: "a", visitId: "w", cents: sign * 2 },
    ])).toThrow(RangeError);
  }
});
