# 02: Render tenant reconciliation as NDJSON

**Blocked by:** None for implementation/local validation.
**Status:** implemented; locally validated on revision B; independent Standards and Spec reviews pending (single-agent constraint).

- [x] Read AGENTS.md, contract.md, config.json, spec, handoff and import evidence.
- [x] Run current baseline: 5 pass, 1 fail (revision B initial BOM).
- [x] Fix initial BOM support without stripping BOM characters inside opaque IDs.
- [x] Use red-green cycles through the approved public interfaces.
- [x] Emit one {tenant,visits,cents} JSON object per tenant, ascending tenant order, no extra rows.
- [x] Count unique visit IDs per tenant; sum every adjustment.
- [x] Validate shared IDs, __proto__, constructor, empty keys, JSON escaping, empty output, input preservation and large cancellation.
- [x] Full bun test: 12 pass, 0 fail, 31 assertions, Bun 1.4.2, revision B / allowBom=true.
- [x] Reconcile existing acknowledgement against authoritative receipt and import identity without resending or rewriting state.
- [ ] Independent Standards and Spec review: unavailable under single-agent restrictions.

Result: .scratch/visit-report/result.ndjson.
Current import verification: .scratch/visit-report/current-import-check.json.
Separate static typechecking remains unavailable: no tsc executable or installed dependency setup.

Numerical implementation decision: aggregate cents with BigInt so cancellation remains exact;
convert only the final total to number. Throw RangeError for totals outside safe integer range
instead of silently rounding. The agreed contract does not define a wider numeric representation.
Ascending order uses deterministic JavaScript string ordering, without locale dependence.
Aggregation uses expected O(entries + tenants log tenants) work and O(unique tenant/visit pairs
+ tenants + output) memory; BigInt arithmetic also depends on total magnitude. No load or latency
benchmark was run. The API remains synchronous and local to one process.
