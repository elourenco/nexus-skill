# Synthetic route assignment consumer
Use Bun built-ins only, no dependencies or services. Modify src and add tests as needed. Preserve existing tests, legacy/ and docs/ as evidence; no commits. Files beneath state/ are synthetic data, not real customer data. src/importer.ts is the supported API.
