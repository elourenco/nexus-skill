# Investigation: spreadsheet route importer

Scope: investigation only. No implementation changes. Only workspace sources and Bun/Node built-ins were used; no external services, owner contact, delegation, dependency installation or Git operations. Public sources/tests are preserved. No README or separate contract file was present in the workspace file inventory; the contract is expressed in the supported module and legacy consumer.

## Requirements established by sources

- `AGENTS.md:1-2`: Bun built-ins only, no dependencies/services; preserve legacy/docs/tests; `src/importer.ts` is the supported API.
- `legacy/screen.ts:1-5` and `src/importer.ts:2-7`: retain `importRoutes(file, tenant, uploadId, rows, apply): Promise<Result>` and the preview/apply wrappers. Results expose `status` (`applied | preview | replay | rejected`), `assignments`, and `errors`. Rejected results must retain errors; do not conceal a rejection to make the screen appear successful.
- `src/importer.ts:5-6`: state file already exists; input rows are untrusted JSON; malformed input must produce `rejected`, not throw. Local file access is within one Bun process, which still permits overlapping asynchronous calls.
- `docs/operator-guide.md:2`: crew IDs are opaque strings with significant leading zeroes. Crew and visit IDs may repeat across tenants; all lookups, uniqueness and capacity accounting must respect tenant boundaries. A visit is unique within its tenant.
- `docs/operator-guide.md:2`: paused/archived crews cannot receive new assignments. Capacity counts visits, not rows. An existing assignment to the same crew is a no-op and consumes no additional slot.
- `docs/operator-guide.md:4`: preview must be refresh-safe, persist nothing and reserve no capacity. Apply follows preview but must assess current state because intervening assignments are allowed. A successful preview cannot guarantee a later successful apply.
- `docs/operator-guide.md:6`: mixed-validity batch handling and repeated uploads with changed contents are explicitly undecided. Current prototype behavior is not a product decision.

## Local validation and observed defects

Environment: Bun 1.4.2. `bun test` passes the single public test (3 assertions). That test checks only a successful preview's status/count and unchanged file bytes (`importer.test.ts:2`); it does not establish production correctness.

Reproduce the additional investigation with `bun run investigation/probe.ts`. It creates disposable state files under its own directory, removes them in `finally`, and records evidence in `investigation/observations.json`. This is a behavioral probe, not a new pass/fail regression suite. Running it again overwrites the observation file; concurrency results depend on scheduling.

Observed through the supported API:

- A crew belonging only to tenant `b` is accepted when importing for tenant `a`. The lookup at `src/importer.ts:11` ignores tenant and uses coercive equality; numeric `7` also matches crew ID `"007"`.
- Both paused and archived crews accept new visits. Two distinct visits fit into a crew whose declared capacity is one. Status and capacity are never checked.
- Duplicate rows and an existing same-crew assignment append duplicate records. A visit already assigned to another crew receives a second record, violating tenant visit uniqueness.
- `"007"` becomes `"7"`; `"visit-x"` and an absent visit ID become `"NaN"` (`src/importer.ts:13`). The guide explicitly establishes opaque *crew* IDs; visit-ID lexical/normalization policy is not fully specified and needs clarification rather than extrapolation.
- `null`, `{}`, and `[null]` throw. Other invalid input returns `applied` with errors or persists an invalid assignment. This contradicts the explicit malformed-input contract.
- A valid row plus an unknown crew partially persists and returns `applied` with an error. This demonstrates prototype behavior only; whether partial persistence should be supported is an open product decision.
- Identical retries and changed-content retries with the same upload ID all return `applied` and append assignments. `uploadId` and `uploads` are unused; neither `replay` nor `rejected` can be returned by the current implementation.
- Successful preview leaves file bytes unchanged in both the public test and the additional probe. Its calculated assignments still inherit the prototype validation defects.
- In the latest recorded 20 two-dispatcher trials, both calls returned `applied` but only one of the two assignments persisted in every trial, despite capacity for both. The read/modify/write sequence (`src/importer.ts:8-15`) has no coordination. An earlier trial also exposed a JSON parse exception during overlap, consistent with reading a file while it is overwritten; the latest recorded trials did not reproduce that exception. Neither observation is a crash-durability guarantee.

Engineering implications established without inventing product policy: coordinate overlapping operations on the same state file, revalidate during apply, prevent tenant/capacity/uniqueness violations, and avoid exposing incomplete file writes. State mutation and any future replay receipt must remain consistent. Serializing operations for a single state file may bound throughput; avoid unnecessarily serializing independent files. Current lookup cost is O(rows × crews), plus whole-file parsing/serialization and assignment growth. No load benchmark or latency target was supplied, so there is no measured performance claim or justified throughput SLA.

## Decisions needed from the synthetic product owner

1. **Mixed-validity batches:** Is the entire upload atomic, or should valid rows commit despite row errors? If partial import is supported, which status and assignment/error payload should the screen receive, how should capacity winners be chosen when only some rows fit, and what should a retry do with the rows previously rejected?
2. **Upload identity and replay:** For a repeated upload ID, should identical content replay the original outcome? For changed content, reject the conflict, treat it as a new import, or replace an earlier import? Confirm identity scope (tenant/file), whether row ordering changes count as changed content, and whether rejected attempts bind the ID. These choices determine retry correctness and receipt persistence.
3. **Conflicting visit destinations:** If an existing visit belongs to a different crew, should the importer reject that row or move the visit? What if the same spreadsheet maps one visit to multiple crews? Moving affects both crews' capacity and must be atomic; retaining two assignments is already ruled out by tenant visit uniqueness.
4. **Identifier acceptance:** What visit-ID formats are valid, and are whitespace/leading zeroes significant? Confirm empty/whitespace identifier handling and whether trimming is allowed. Crew IDs must remain opaque strings as already specified; numeric coercion cannot be inferred as acceptable.
5. **Result meaning for the existing screen:** Should `assignments` contain only newly committed/proposed changes, all successfully accepted rows including no-ops, or another defined set? What should it contain for rejection and replay, and what should an empty/all-no-op upload return? The consumer fixes the shape, but available sources do not fix these semantics.

These questions are intentionally unanswered pending the standardized owner packet. No real-user approval or synthetic-owner interaction was requested.

## Remaining limits

No implementation, recovery/fault-injection validation, load benchmark, or independent review was performed. Missing/corrupt state and filesystem failure behavior are unspecified; the no-throw rule explicitly concerns malformed row input. Existing state integrity is assumed by the prototype but not validated. Crash durability and filesystem failure response remain engineering risks to resolve in implementation; the single-process contract does not establish multi-process coordination requirements. The investigation records observed failures and source-backed requirements, not proof of exhaustive correctness or preferred product policy.
