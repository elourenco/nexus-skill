import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { importRoutes, type State } from "../src/importer";

// Investigation only: invoke the supported API against disposable synthetic files.
const dir = await mkdtemp(join(import.meta.dir, "scratch-"));
const active = { tenant: "a", id: "c", status: "active" as const, capacity: 1 };
const initial = (): State => ({ crews: [{ ...active }], assignments: [], uploads: {} });
let sequence = 0;
const observations: unknown[] = [];
async function probe(name: string, state: State, rows: unknown, apply = true) {
  const file = join(dir, `${sequence++}.json`);
  const before = JSON.stringify(state);
  await writeFile(file, before);
  try {
    const result = await importRoutes(file, "a", "upload", rows, apply);
    const after = await readFile(file, "utf8");
    observations.push({ name, result, changed: after !== before, state: JSON.parse(after) });
  } catch (error) {
    observations.push({ name, thrown: String(error), changed: await readFile(file, "utf8") !== before });
  }
}
try {
  await probe("tenant collision chooses first foreign crew", { ...initial(), crews: [{ ...active, tenant: "b" }, { ...active }] }, [{ visitId: "7", crewId: "c" }]);
  await probe("foreign crew accepted without local crew", { ...initial(), crews: [{ ...active, tenant: "b" }] }, [{ visitId: "7", crewId: "c" }]);
  for (const status of ["paused", "archived"] as const) {
    await probe(`${status} crew`, { ...initial(), crews: [{ ...active, status }] }, [{ visitId: "7", crewId: "c" }]);
  }
  await probe("two distinct visits exceed capacity one", initial(), [{ visitId: "7", crewId: "c" }, { visitId: "8", crewId: "c" }]);
  await probe("duplicate rows", initial(), [{ visitId: "7", crewId: "c" }, { visitId: "7", crewId: "c" }]);
  const assigned = { tenant: "a", visitId: "7", crewId: "c" };
  await probe("existing same crew assignment", { ...initial(), assignments: [assigned] }, [{ visitId: "7", crewId: "c" }]);
  await probe("existing different crew assignment", { ...initial(), assignments: [{ ...assigned, crewId: "other" }] }, [{ visitId: "7", crewId: "c" }]);
  await probe("coercion of visit strings", initial(), [{ visitId: "007", crewId: "c" }, { visitId: "visit-x", crewId: "c" }]);
  await probe("numeric crew coerces to string id", { ...initial(), crews: [{ ...active, id: "007" }] }, [{ visitId: "7", crewId: 7 }]);
  for (const rows of [null, {}, [null], [{ visitId: "7" }], [{ crewId: "c" }], "text"]) {
    await probe(`malformed ${JSON.stringify(rows)}`, initial(), rows);
  }
  await probe("mixed valid and unknown crew", initial(), [{ visitId: "7", crewId: "c" }, { visitId: "8", crewId: "missing" }]);
  await probe("preview does not persist", initial(), [{ visitId: "7", crewId: "c" }], false);
  const file = join(dir, "replay.json");
  await writeFile(file, JSON.stringify(initial()));
  const first = await importRoutes(file, "a", "same-upload", [{ visitId: "7", crewId: "c" }], true);
  const second = await importRoutes(file, "a", "same-upload", [{ visitId: "7", crewId: "c" }], true);
  const changed = await importRoutes(file, "a", "same-upload", [{ visitId: "8", crewId: "c" }], true);
  observations.push({ name: "same upload retry then changed contents", first, second, changed, state: JSON.parse(await readFile(file, "utf8")) });
  const raceResults: unknown[] = [];
  for (let run = 0; run < 20; run++) {
    const raceFile = join(dir, `race-${run}.json`);
    await writeFile(raceFile, JSON.stringify({ ...initial(), crews: [{ ...active, capacity: 2 }] }));
    const settled = await Promise.allSettled([
      importRoutes(raceFile, "a", "u1", [{ visitId: "7", crewId: "c" }], true),
      importRoutes(raceFile, "a", "u2", [{ visitId: "8", crewId: "c" }], true),
    ]);
    const returned = settled.map(result => result.status === "fulfilled"
      ? result
      : { status: result.status, reason: String(result.reason) });
    const raw = await readFile(raceFile, "utf8");
    try { raceResults.push({ returned, persistedCount: JSON.parse(raw).assignments.length }); }
    catch { raceResults.push({ returned, invalidJSON: raw }); }
  }
  observations.push({ name: "20 concurrent independent uploads with room for both", runs: raceResults });
  await writeFile(join(import.meta.dir, "observations.json"), JSON.stringify(observations, null, 2) + "\n");
  console.log(`Recorded ${observations.length} observations in investigation/observations.json`);
} finally {
  await rm(dir, { recursive: true, force: true });
}
