# Operator guide (legacy)
Staff export a crew list per tenant. Crew IDs are opaque strings; leading zeroes are significant. Paused and archived crews cannot receive new assignments. Crew assignment capacity is a count of visits (not row count); visit IDs are unique within a tenant. A visit already assigned to the same crew is a no-op and does not consume an extra slot. Different tenants may use identical visit and crew IDs.

A preview must be safe to refresh and must not reserve capacity. The screen calls apply after preview; preview results are advisory because crews may receive assignments in between.

Open product question from previous iteration: for a spreadsheet containing a bad row, should good rows still be imported? Product has not decided. Also undefined: what should a repeated upload with changed contents mean? Do not infer the product decision from current defects.
