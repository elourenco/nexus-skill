import {importRoutes} from "../src/importer";
export async function preview(file:string, tenant:string, uploadId:string, rows:unknown){return importRoutes(file,tenant,uploadId,rows,false)}
export async function apply(file:string, tenant:string, uploadId:string, rows:unknown){return importRoutes(file,tenant,uploadId,rows,true)}
// Consumers require status applied|preview|replay|rejected, assignments and errors.
// Never remove errors from a rejected result to make the screen look green.
