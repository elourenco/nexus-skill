import {readFile,writeFile} from "node:fs/promises";
export type Row={visitId:string;crewId:string};
export type State={crews:{tenant:string;id:string;status:"active"|"paused"|"archived";capacity:number}[];assignments:{tenant:string;visitId:string;crewId:string}[];uploads:Record<string,unknown>};
export type Result={status:"applied"|"preview"|"replay"|"rejected";assignments:State["assignments"];errors:string[]};
// Existing API: state file already exists. rows is untrusted JSON; malformed input
// must return rejected, not throw. Files are used in a single Bun process.
export async function importRoutes(file:string,tenant:string,uploadId:string,rows:unknown,apply:boolean):Promise<Result>{
 const state:State=JSON.parse(await readFile(file,"utf8"));
 const added=[];const errors=[];
 for(const row of rows as Row[]){
  const crew=state.crews.find(c=>c.id==row.crewId);
  if(!crew){errors.push("unknown crew");continue}
  const item={tenant,visitId:String(Number(row.visitId)),crewId:crew.id};state.assignments.push(item);added.push(item);
 }
 if(apply)await writeFile(file,JSON.stringify(state));
 return {status:apply?"applied":"preview",assignments:added,errors};
}
