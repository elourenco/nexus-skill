# Local implementation and validation

Scope: standard host tools and Bun built-ins only; single agent. No services, installations, delegated review, commits or changes to legacy sources, operator guide, public test or prior investigation evidence.

## Source and owner decisions

Read `AGENTS.md`, `docs/operator-guide.md`, `legacy/screen.ts`, `src/importer.ts`, the public test, and prior investigation findings before implementation. No README or additional contract was present in the workspace inventory. The supported function signature, result fields and status union remain unchanged.

The supplied synthetic owner packet resolves the previously open batch, upload and destination questions:

- Any invalid row rejects the complete batch without changing state or binding its upload ID.
- Successful uploads bind `(tenant, uploadId)` to ordered rows; identical repeats replay the original additions. Changed ordered rows reject. Tenant identities are independent.
- Existing and within-batch assignment to a different crew rejects; same-crew assignment is a no-op.

The packet does not supply a visit-ID grammar or fully specify result payload semantics. Implementation conventions, explicitly not additional owner decisions:

- Accept nonempty string IDs, compare exact values, preserve whitespace and leading zeros, and perform no numeric conversion or trimming. Numeric IDs and empty strings reject. No additional visit-ID pattern is invented.
- Rows are the supported `{visitId, crewId}` values; identity compares those ordered pairs, irrespective of object property order or unrelated row metadata. No sorting or deduplication occurs before identity comparison.
- `assignments` contains newly proposed/committed assignments only, excludes no-ops, and is empty on rejection. Replay returns the original successful additions. Repeated rows with the same visit and crew produce one addition.
- An empty batch previews successfully; applying it records an empty successful receipt. Identical preview of a previously committed upload reports replay. Previews never create receipts.

These conventions are visible in tests and can be revisited without claiming preferences absent from the owner packet. No further approval was required for this local implementation.

## Implementation

`src/importer.ts` snapshots and validates input before asynchronous work, validates persisted state, indexes crews and visits by tenant, and checks eligibility, uniqueness and capacity. Existing same-crew no-ops remain valid even when a crew is paused or full. Inconsistent persisted state rejects rather than silently repairing it.

A per-canonical-file promise queue covers reading, validation and commit, including previews. It prevents lost updates, capacity races, conflicting destinations and duplicate upload effects within the specified single Bun process. Symlink aliases resolve to the same queue. Queues release after success or failure and are removed when idle; independent files have independent queues.

Assignments and upload receipts are serialized in one snapshot. A uniquely created temporary file in the same directory is written, synced, closed and renamed over the canonical file. Failures before publication reject and preserve the original snapshot. Temporary files are cleaned after handled failures. State I/O or parse failures return a rejection with an error, preserving the screen's error contract.

Index construction and validation cost O(crews + assignments); row processing costs O(rows), in addition to parsing and writing the whole state and its accumulated receipts. File commits serialize and include fsync latency. Receipt storage grows with successful uploads. This design targets the given local consumer, not an unbounded datastore.

## Observed validation

Command: `bun test` (Bun 1.4.2).

Final result: **13 tests passed, 0 failed, 161 assertions**, across the unchanged public test and `importer.behavior.test.ts`.

Covered malformed JSON values, exact IDs and tenant isolation, atomic mixed-invalid/capacity/conflict rejection, crew eligibility, duplicate and existing no-ops, preview/apply revalidation, empty batches, ordered replay and changed-content conflict, tuple identity collisions, and inconsistent state rejection/recovery.

Concurrent tests launch 30 distinct uploads against capacity 10 through both the canonical path and a symlink: exactly 10 apply and 20 reject, with all 10 successful assignments and receipts persisted. Twelve simultaneous identical uploads yield one apply and eleven replays. Competing content under one upload identity and competing crew destinations each produce one successful commit and one rejection.

A fresh Bun subprocess replays a persisted receipt without additional effects. Separate subprocess filesystem mocks inject a partial temporary-file write failure, fsync failure and rename failure. Each rejects with errors, preserves exact original bytes, cleans temporary files and permits a successful retry under the same upload identity. Module mocks are isolated from other tests. Long legal state filenames are also covered.

The test runner reported 125 ms for the final complete run. This is an observed suite duration, not a latency or throughput benchmark.

## Limits

- Coordination covers calls through this module in one Bun process. Multiple processes, hard-link aliases, workers with separate module instances and unrelated writers require shared locking or transactional storage.
- File fsync plus same-directory rename avoids publishing a partially written JSON snapshot. No directory fsync or power-loss durability guarantee is claimed. Abrupt termination before rename can leave an orphan temporary file; there is no startup scavenger. Crash/power-loss behavior was not experimentally verified.
- No load SLA, sustained throughput benchmark or independent review was performed. Existing state must satisfy the validated schema; invalid legacy data is rejected without automatic migration.
- Disk and parse errors currently share a generic screen-safe message. The task supplied no logging/metrics interface; production diagnostics and persistence limits would need an operational contract before broader deployment.
