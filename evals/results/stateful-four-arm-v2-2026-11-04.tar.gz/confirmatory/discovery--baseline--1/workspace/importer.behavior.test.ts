import {test, expect} from "bun:test";
import {mkdtempSync, writeFileSync, readFileSync, rmSync, readdirSync, symlinkSync} from "node:fs";
import {join} from "node:path";
import {tmpdir} from "node:os";
import {importRoutes, type State, type Row} from "./src/importer";

function fixture(state: State, filename = "state.json") {
  const dir = mkdtempSync(join(tmpdir(), "routes-regression-"));
  const file = join(dir, filename);
  writeFileSync(file, JSON.stringify(state));
  return {
    file, dir,
    bytes: () => readFileSync(file, "utf8"),
    state: (): State => JSON.parse(readFileSync(file, "utf8")),
    cleanup: () => rmSync(dir, {recursive: true, force: true}),
  };
}
function initial(capacity = 4): State {
  return {
    crews: [
      {tenant: "a", id: "007", status: "active", capacity},
      {tenant: "a", id: "other", status: "active", capacity},
      {tenant: "a", id: "paused", status: "paused", capacity},
      {tenant: "a", id: "archived", status: "archived", capacity},
      {tenant: "b", id: "007", status: "active", capacity},
      {tenant: "b", id: "foreign", status: "active", capacity},
    ], assignments: [], uploads: {},
  };
}
const row = (visitId: string, crewId = "007"): Row => ({visitId, crewId});

test("malformed JSON values reject with errors and preserve exact bytes", async () => {
  const f = fixture(initial());
  try {
    const before = f.bytes();
    for (const input of [null, {}, "[]", 3, [null], [{}], [{visitId: 7, crewId: "007"}], [row("", "007")], [row("1", "")]]) {
      for (const apply of [false, true]) {
        const result = await importRoutes(f.file, "a", "bad", input, apply);
        expect(result.status).toBe("rejected");
        expect(result.errors.length).toBeGreaterThan(0);
        expect(result.assignments).toEqual([]);
        expect(f.bytes()).toBe(before);
      }
    }
  } finally { f.cleanup(); }
});

test("tenant isolation and exact opaque IDs", async () => {
  const f = fixture(initial());
  try {
    expect((await importRoutes(f.file, "a", "foreign", [row("v", "foreign")], true)).status).toBe("rejected");
    expect((await importRoutes(f.file, "a", "coerced", [row("v", "7")], true)).status).toBe("rejected");
    for (const tenant of ["a", "b"]) {
      const result = await importRoutes(f.file, tenant, "shared", [row("0007"), row("visit-x"), row(" spaced ")], true);
      expect(result.status).toBe("applied");
      expect(result.assignments.map(a => a.visitId)).toEqual(["0007", "visit-x", " spaced "]);
    }
    expect(f.state().assignments.length).toBe(6);
  } finally { f.cleanup(); }
});

test("invalid batches roll back new assignments and do not bind upload identity", async () => {
  const f = fixture(initial(1));
  try {
    const before = f.bytes();
    for (const rows of [[row("1"), row("2")], [row("1"), row("2", "missing")], [row("1"), row("2", "paused")], [row("1"), row("2", "archived")], [row("1"), row("1", "other")]]) {
      const result = await importRoutes(f.file, "a", "retry", rows, true);
      expect(result.status).toBe("rejected");
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.assignments).toEqual([]);
      expect(f.bytes()).toBe(before);
    }
    expect((await importRoutes(f.file, "a", "retry", [row("1")], true)).status).toBe("applied");
  } finally { f.cleanup(); }
});

test("capacity counts distinct visits; same crew is a no-op even when paused or full", async () => {
  const state = initial(1);
  state.assignments.push({tenant: "a", visitId: "existing", crewId: "paused"});
  const f = fixture(state);
  try {
    const first = await importRoutes(f.file, "a", "first", [row("existing", "paused"), row("1"), row("1")], true);
    expect(first.status).toBe("applied");
    expect(first.assignments).toEqual([{tenant: "a", visitId: "1", crewId: "007"}]);
    expect((await importRoutes(f.file, "a", "noop", [row("1"), row("existing", "paused")], true)).assignments).toEqual([]);
    const before = f.bytes();
    expect((await importRoutes(f.file, "a", "full", [row("2")], true)).status).toBe("rejected");
    expect((await importRoutes(f.file, "a", "move", [row("1", "other")], true)).status).toBe("rejected");
    expect(f.bytes()).toBe(before);
    expect(f.state().assignments.length).toBe(2);
  } finally { f.cleanup(); }
});

test("preview reserves nothing; apply revalidates latest state", async () => {
  const f = fixture(initial(1));
  try {
    const before = f.bytes();
    expect((await importRoutes(f.file, "a", "preview", [row("1")], false)).status).toBe("preview");
    expect(f.bytes()).toBe(before);
    expect((await importRoutes(f.file, "a", "winner", [row("2")], true)).status).toBe("applied");
    const committed = f.bytes();
    expect((await importRoutes(f.file, "a", "preview", [row("1")], true)).status).toBe("rejected");
    expect(f.bytes()).toBe(committed);
  } finally { f.cleanup(); }
});

test("ordered upload replay is durable and changed content rejects without mutation", async () => {
  const f = fixture(initial());
  try {
    const rows = [row("1"), row("2")];
    const first = await importRoutes(f.file, "a", "id", rows, true);
    expect(first.status).toBe("applied");
    const before = f.bytes();
    for (const apply of [false, true]) {
      const replay = await importRoutes(f.file, "a", "id", rows.map(r => ({crewId: r.crewId, visitId: r.visitId})), apply);
      expect(replay).toEqual({...first, status: "replay"});
      expect((await importRoutes(f.file, "a", "id", [...rows].reverse(), apply)).status).toBe("rejected");
      expect((await importRoutes(f.file, "a", "id", [row("3")], apply)).status).toBe("rejected");
      expect(f.bytes()).toBe(before);
    }
    const script = `import {importRoutes} from ${JSON.stringify(join(import.meta.dir, "src/importer.ts"))}; console.log(JSON.stringify(await importRoutes(${JSON.stringify(f.file)}, "a", "id", ${JSON.stringify(rows)}, true)));`;
    const child = Bun.spawnSync([process.execPath, "--eval", script]);
    expect(child.exitCode).toBe(0);
    expect(JSON.parse(child.stdout.toString())).toEqual({...first, status: "replay"});
    expect(f.bytes()).toBe(before);
  } finally { f.cleanup(); }
});

test("empty batches and tuple upload identities are deterministic", async () => {
  const f = fixture(initial());
  try {
    expect(await importRoutes(f.file, "a", "__proto__", [], false)).toEqual({status: "preview", assignments: [], errors: []});
    expect((await importRoutes(f.file, "a", "__proto__", [], true)).status).toBe("applied");
    expect((await importRoutes(f.file, "a", "__proto__", [], true)).status).toBe("replay");
    expect((await importRoutes(f.file, "a:x", "y", [], true)).status).toBe("applied");
    expect((await importRoutes(f.file, "a", "x:y", [], true)).status).toBe("applied");
    expect(Object.keys(f.state().uploads).length).toBe(3);
  } finally { f.cleanup(); }
});

test("concurrent dispatchers cannot oversubscribe or lose committed visits, including symlink aliases", async () => {
  const f = fixture(initial(10));
  try {
    const alias = join(f.dir, "alias.json");
    symlinkSync(f.file, alias);
    const results = await Promise.all(Array.from({length: 30}, (_, i) => importRoutes(i % 2 ? alias : f.file, "a", `u${i}`, [row(`v${i}`)], true)));
    expect(results.filter(r => r.status === "applied").length).toBe(10);
    expect(results.filter(r => r.status === "rejected").length).toBe(20);
    const state = f.state();
    expect(state.assignments.length).toBe(10);
    expect(Object.keys(state.uploads).length).toBe(10);
    expect(state.assignments.map(a => a.visitId).sort()).toEqual(results.flatMap(r => r.assignments.map(a => a.visitId)).sort());
    expect(readdirSync(f.dir).sort()).toEqual(["alias.json", "state.json"]);
  } finally { f.cleanup(); }
});

test("concurrent same identity applies once; conflicting uploads and crews have one winner", async () => {
  const f = fixture(initial(10));
  try {
    const results = await Promise.all(Array.from({length: 12}, () => importRoutes(f.file, "a", "same", [row("v")], true)));
    expect(results.filter(r => r.status === "applied").length).toBe(1);
    expect(results.filter(r => r.status === "replay").length).toBe(11);
    const changed = await Promise.all(["x", "y"].map(v => importRoutes(f.file, "a", "changed", [row(v)], true)));
    expect(changed.map(r => r.status).sort()).toEqual(["applied", "rejected"]);
    const conflicts = await Promise.all(["007", "other"].map(c => importRoutes(f.file, "a", `crew-${c}`, [row("conflict", c)], true)));
    expect(conflicts.map(r => r.status).sort()).toEqual(["applied", "rejected"]);
    expect(f.state().assignments.length).toBe(3);
  } finally { f.cleanup(); }
});

test("long state filenames remain supported", async () => {
  const f = fixture(initial(), "s".repeat(240));
  try {
    expect((await importRoutes(f.file, "a", "u", [row("v")], true)).status).toBe("applied");
    expect(readdirSync(f.dir)).toEqual(["s".repeat(240)]);
  } finally { f.cleanup(); }
});

test("injected write, sync and rename failures preserve bytes and allow retry", () => {
  const f = fixture(initial());
  try {
    // Isolate Bun module mocks in a child; public tests retain real filesystem APIs.
    const script = `
      import {mock} from "bun:test";
      import * as fs from "node:fs/promises";
      const original = {...fs};
      let stage = "";
      mock.module("node:fs/promises", () => ({
        ...original,
        open: async (...args) => {
          const handle = await original.open(...args);
          return {
            writeFile: async (...values) => {
              if (stage === "write") {
                await handle.writeFile("partial snapshot");
                throw new Error("injected write failure");
              }
              return handle.writeFile(...values);
            },
            sync: async () => {
              if (stage === "sync") throw new Error("injected sync failure");
              return handle.sync();
            },
            close: () => handle.close(),
          };
        },
        rename: async (...args) => {
          if (stage === "rename") throw new Error("injected rename failure");
          return original.rename(...args);
        },
      }));
      const {importRoutes} = await import(${JSON.stringify(join(import.meta.dir, "src/importer.ts"))});
      const file = ${JSON.stringify(f.file)};
      const dir = ${JSON.stringify(f.dir)};
      for (const failure of ["write", "sync", "rename"]) {
        const before = await original.readFile(file, "utf8");
        stage = failure;
        const result = await importRoutes(file, "a", failure, [{visitId: failure, crewId: "007"}], true);
        if (result.status !== "rejected" || !result.errors.length || result.assignments.length) throw new Error("bad rejection");
        if (await original.readFile(file, "utf8") !== before) throw new Error("changed state");
        if ((await original.readdir(dir)).length !== 1) throw new Error("temporary file leaked");
        stage = "";
        const retry = await importRoutes(file, "a", failure, [{visitId: failure, crewId: "007"}], true);
        if (retry.status !== "applied") throw new Error("retry failed");
      }
      console.log("fault recovery verified");
    `;
    const child = Bun.spawnSync([process.execPath, "--eval", script]);
    expect(child.stderr.toString()).toBe("");
    expect(child.exitCode).toBe(0);
    expect(child.stdout.toString().trim()).toBe("fault recovery verified");
    expect(f.state().assignments.length).toBe(3);
    expect(Object.keys(f.state().uploads).length).toBe(3);
  } finally { f.cleanup(); }
});

test("corrupt or inconsistent state rejects without mutation", async () => {
  const f = fixture(initial());
  try {
    const duplicate = initial();
    duplicate.assignments = [{tenant: "a", visitId: "v", crewId: "007"}, {tenant: "a", visitId: "v", crewId: "other"}];
    for (const bytes of ["{", "{}", JSON.stringify(duplicate)]) {
      writeFileSync(f.file, bytes);
      const result = await importRoutes(f.file, "a", "u", [row("v")], true);
      expect(result.status).toBe("rejected");
      expect(result.errors.length).toBeGreaterThan(0);
      expect(f.bytes()).toBe(bytes);
    }
    writeFileSync(f.file, JSON.stringify(initial()));
    expect((await importRoutes(f.file, "a", "u", [row("v")], true)).status).toBe("applied");
  } finally { f.cleanup(); }
});
