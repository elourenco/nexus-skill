import {open, readFile, realpath, rename, unlink} from "node:fs/promises";
import {randomUUID} from "node:crypto";
import {dirname, join} from "node:path";

export type Row = {visitId: string; crewId: string};
export type State = {
  crews: {tenant: string; id: string; status: "active" | "paused" | "archived"; capacity: number}[];
  assignments: {tenant: string; visitId: string; crewId: string}[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: "applied" | "preview" | "replay" | "rejected";
  assignments: State["assignments"];
  errors: string[];
};
type Receipt = {version: 1; tenant: string; uploadId: string; rows: string; assignments: State["assignments"]};

// All read/validate/commit operations for one canonical file share a queue.
// Independent state files do not block each other. The API is single-process.
const queues = new Map<string, Promise<void>>();
async function exclusive<T>(file: string, run: () => Promise<T>): Promise<T> {
  const previous = queues.get(file) ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>(resolve => { release = resolve; });
  queues.set(file, current);
  await previous;
  try { return await run(); }
  finally {
    release();
    if (queues.get(file) === current) queues.delete(file);
  }
}
const object = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === "object" && !Array.isArray(value);
const id = (value: unknown): value is string => typeof value === "string" && value.length > 0;
const rejected = (...errors: string[]): Result => ({status: "rejected", assignments: [], errors});
const key = (tenant: string, identifier: string) => JSON.stringify([tenant, identifier]);

function parseRows(value: unknown): {rows: Row[]; errors: string[]} {
  if (!Array.isArray(value)) return {rows: [], errors: ["rows must be an array"]};
  const rows: Row[] = [], errors: string[] = [];
  for (let index = 0; index < value.length; index++) {
    const row = value[index];
    if (!object(row) || !id(row.visitId) || !id(row.crewId)) {
      errors.push(`row ${index + 1}: visitId and crewId must be nonempty strings`);
    } else {
      // Snapshot untrusted input before any asynchronous work; never coerce IDs.
      rows.push({visitId: row.visitId, crewId: row.crewId});
    }
  }
  return {rows, errors};
}

function validState(value: unknown): value is State {
  if (!object(value) || !Array.isArray(value.crews) || !Array.isArray(value.assignments) || !object(value.uploads)) return false;
  const crews = new Map<string, number>();
  for (const crew of value.crews) {
    if (!object(crew) || !id(crew.tenant) || !id(crew.id) ||
        !["active", "paused", "archived"].includes(crew.status as string) ||
        !Number.isSafeInteger(crew.capacity) || (crew.capacity as number) < 0) return false;
    const identity = key(crew.tenant, crew.id);
    if (crews.has(identity)) return false;
    crews.set(identity, 0);
  }
  const visits = new Set<string>();
  for (const item of value.assignments) {
    if (!object(item) || !id(item.tenant) || !id(item.visitId) || !id(item.crewId)) return false;
    const visit = key(item.tenant, item.visitId), crew = key(item.tenant, item.crewId);
    if (visits.has(visit) || !crews.has(crew)) return false;
    visits.add(visit);
  }
  return true;
}

// A complete snapshot and its replay receipts become visible in one rename.
// Sync the temporary file before publishing. No fallible operation follows rename.
async function persist(file: string, state: State): Promise<void> {
  const temporary = join(dirname(file), `.route-import-${randomUUID()}.tmp`);
  try {
    const handle = await open(temporary, "wx", 0o600);
    try { await handle.writeFile(JSON.stringify(state)); await handle.sync(); }
    finally { await handle.close(); }
    await rename(temporary, file);
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

// Existing API: state file already exists. rows is untrusted JSON; malformed input
// returns rejected. IDs are compared exactly. Only successful applies bind IDs.
export async function importRoutes(file: string, tenant: string, uploadId: string, rows: unknown, apply: boolean): Promise<Result> {
  if (!id(tenant) || !id(uploadId)) return rejected("tenant and uploadId must be nonempty strings");
  const parsed = parseRows(rows);
  if (parsed.errors.length) return rejected(...parsed.errors);
  const fingerprint = JSON.stringify(parsed.rows);
  try {
    const canonical = await realpath(file);
    return await exclusive(canonical, async () => {
      const value: unknown = JSON.parse(await readFile(canonical, "utf8"));
      if (!validState(value)) return rejected("invalid state file");
      const state = value;
      const uploadKey = key(tenant, uploadId);
      if (Object.hasOwn(state.uploads, uploadKey)) {
        const receipt = state.uploads[uploadKey] as Receipt;
        if (!object(receipt) || receipt.version !== 1 || receipt.tenant !== tenant || receipt.uploadId !== uploadId ||
            typeof receipt.rows !== "string" || !Array.isArray(receipt.assignments) ||
            !receipt.assignments.every(item => object(item) && item.tenant === tenant && id(item.visitId) && id(item.crewId))) {
          return rejected("invalid upload receipt");
        }
        if (receipt.rows !== fingerprint) return rejected("uploadId already used with different ordered rows");
        return {status: "replay", assignments: receipt.assignments, errors: []};
      }
      const crews = new Map(state.crews.filter(c => c.tenant === tenant).map(c => [c.id, c]));
      const assigned = new Map<string, string>();
      const counts = new Map<string, number>();
      for (const item of state.assignments) {
        if (item.tenant !== tenant) continue;
        assigned.set(item.visitId, item.crewId);
        counts.set(item.crewId, (counts.get(item.crewId) ?? 0) + 1);
      }
      const added: State["assignments"] = [], errors: string[] = [];
      for (const [index, row] of parsed.rows.entries()) {
        const fail = (message: string) => errors.push(`row ${index + 1}: ${message}`);
        const crew = crews.get(row.crewId);
        if (!crew) { fail("unknown crew"); continue; }
        const existing = assigned.get(row.visitId);
        if (existing !== undefined) {
          if (existing !== row.crewId) fail("visit already assigned to another crew");
          continue;
        }
        if (crew.status !== "active") { fail("crew is not active"); continue; }
        const count = counts.get(crew.id) ?? 0;
        if (count >= crew.capacity) { fail("crew capacity exceeded"); continue; }
        assigned.set(row.visitId, crew.id);
        counts.set(crew.id, count + 1);
        added.push({tenant, visitId: row.visitId, crewId: crew.id});
      }
      if (errors.length) return rejected(...errors);
      if (!apply) return {status: "preview", assignments: added, errors: []};
      state.assignments.push(...added);
      state.uploads[uploadKey] = {version: 1, tenant, uploadId, rows: fingerprint, assignments: added} satisfies Receipt;
      await persist(canonical, state);
      return {status: "applied", assignments: added, errors: []};
    });
  } catch {
    return rejected("state could not be read or committed");
  }
}
