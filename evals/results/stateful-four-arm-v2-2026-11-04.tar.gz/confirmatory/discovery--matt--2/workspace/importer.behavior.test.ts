import { expect, test } from "bun:test";
import { mkdtemp, open, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { importRoutes, type State } from "./src/importer";

const crew = (id = "001", capacity = 2, tenant = "a", status: State["crews"][number]["status"] = "active") =>
  ({ tenant, id, status, capacity });

async function fixture(run: (file: string) => Promise<void>, changes: Partial<State> = {}) {
  const dir = await mkdtemp(join(tmpdir(), "route-behavior-"));
  const file = join(dir, "state.json");
  try {
    await writeFile(file, JSON.stringify({ crews: [crew()], assignments: [], uploads: {}, ...changes }));
    await run(file);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

// Authorized seam: public importer result plus its persisted state file.
test("malformed rows and mixed invalid batches reject without any state effects", async () => {
  await fixture(async file => {
    const before = await readFile(file, "utf8");
    for (const rows of [null, {}, "rows", [null], [7], [{}], [{visitId: 7, crewId: "001"}],
      [{visitId: "7", crewId: 1}], [{visitId: "7", crewId: "001"}, {visitId: "8", crewId: "missing"}]]) {
      for (const apply of [false, true]) {
        const result = await importRoutes(file, "a", "invalid", rows, apply);
        expect(result.status).toBe("rejected");
        expect(result.errors.length).toBeGreaterThan(0);
        expect(result.assignments).toEqual([]);
        expect(await readFile(file, "utf8")).toBe(before);
      }
    }
  });
});

test("tenant isolation, eligibility, capacity and visit conflicts follow atomic batch rules", async () => {
  await fixture(async file => {
    const before = await readFile(file, "utf8");
    const invalidBatches = [
      [{ visitId: "v1", crewId: "foreign" }],
      [{ visitId: "v1", crewId: "paused" }],
      [{ visitId: "v1", crewId: "archived" }],
      [{ visitId: "v1", crewId: "001" }, { visitId: "v2", crewId: "001" }, { visitId: "v3", crewId: "001" }],
      [{ visitId: "assigned", crewId: "001" }],
      [{ visitId: "v1", crewId: "001" }, { visitId: "v1", crewId: "other" }],
      [{ visitId: "v1", crewId: "1" }],
    ];
    for (const rows of invalidBatches) {
      for (const apply of [false, true]) {
        const result = await importRoutes(file, "a", "u", rows, apply);
        expect(result.status).toBe("rejected");
        expect(result.errors.length).toBeGreaterThan(0);
        expect(result.assignments).toEqual([]);
        expect(await readFile(file, "utf8")).toBe(before);
      }
    }
    const result = await importRoutes(file, "a", "valid", [
      { visitId: "0007", crewId: "001" }, { visitId: "0007", crewId: "001" },
      { visitId: "visit-A", crewId: "001" }, { visitId: "assigned", crewId: "other" },
      { visitId: "old", crewId: "paused" },
    ], true);
    expect(result).toEqual({ status: "applied", assignments: [
      { tenant: "a", visitId: "0007", crewId: "001" },
      { tenant: "a", visitId: "visit-A", crewId: "001" },
    ], errors: [] });
    const persisted = JSON.parse(await readFile(file, "utf8")) as State;
    expect(persisted.assignments).toHaveLength(5);
  }, {
    crews: [crew(), crew("other"), crew("foreign", 2, "b"), crew("paused", 0, "a", "paused"), crew("archived", 0, "a", "archived")],
    assignments: [
      { tenant: "a", visitId: "assigned", crewId: "other" },
      { tenant: "a", visitId: "old", crewId: "paused" },
      { tenant: "b", visitId: "0007", crewId: "001" },
    ],
  });
});

test("upload replay is persistent, tenant scoped and compares ordered public row values", async () => {
  await fixture(async file => {
    const rows = [{ visitId: "0007", crewId: "001" }, { visitId: "visit-A", crewId: "001" }];
    const first = await importRoutes(file, "a", "__proto__", rows, true);
    expect(first.status).toBe("applied");
    const committed = await readFile(file, "utf8");
    for (const apply of [false, true]) {
      const replay = await importRoutes(file, "a", "__proto__", rows.map(r => ({ crewId: r.crewId, visitId: r.visitId })), apply);
      expect(replay).toEqual({ ...first, status: "replay" });
      expect(await readFile(file, "utf8")).toBe(committed);
      for (const changed of [[...rows].reverse(), [rows[0]!], [...rows, rows[0]!], [{visitId:"changed",crewId:"001"}]]) {
        const result = await importRoutes(file, "a", "__proto__", changed, apply);
        expect(result.status).toBe("rejected");
        expect(result.errors.length).toBeGreaterThan(0);
        expect(await readFile(file, "utf8")).toBe(committed);
      }
    }
    const otherTenant = await importRoutes(file, "b", "__proto__", rows, true);
    expect(otherTenant.status).toBe("applied");
    expect(otherTenant.assignments).toEqual([
      { tenant: "b", visitId: "0007", crewId: "001" },
      { tenant: "b", visitId: "visit-A", crewId: "001" },
    ]);
    // Persisted receipt works even after crew eligibility changes; replay has no new effects.
    const state = JSON.parse(await readFile(file, "utf8")) as State;
    state.crews[0]!.status = "archived";
    await writeFile(file, JSON.stringify(state));
    expect((await importRoutes(file, "a", "__proto__", rows, true)).status).toBe("replay");
    expect((await importRoutes(file, "a", "fresh", rows, true)).assignments).toEqual([]);
    expect((await importRoutes(file, "a", "fresh", rows, true)).status).toBe("replay");
  }, { crews: [crew(), crew("001", 2, "b")] });
});

test("preview reserves neither capacity nor upload identity; apply revalidates current state", async () => {
  await fixture(async file => {
    const rows = [{visitId: "first", crewId: "001"}];
    const before = await readFile(file, "utf8");
    expect((await importRoutes(file, "a", "u", rows, false)).status).toBe("preview");
    expect((await importRoutes(file, "a", "u", rows, false)).status).toBe("preview");
    expect(await readFile(file, "utf8")).toBe(before);
    expect((await importRoutes(file, "a", "u", [{visitId:"other",crewId:"001"}], true)).status).toBe("applied");
    const committed = await readFile(file, "utf8");
    const result = await importRoutes(file, "a", "next", rows, true);
    expect(result.status).toBe("rejected");
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await readFile(file, "utf8")).toBe(committed);
    expect((await importRoutes(file, "a", "next", [{visitId:"other",crewId:"001"}], true)).status).toBe("applied");
  }, { crews: [crew("001", 1)] });
});

test("concurrent dispatchers cannot lose assignments or exceed capacity", async () => {
  await fixture(async file => {
    const results = await Promise.all(Array.from({length: 20}, (_, i) =>
      importRoutes(file, "a", `upload-${i}`, [{visitId:`v${i}`,crewId:"001"}], true)));
    expect(results.filter(r => r.status === "applied")).toHaveLength(7);
    expect(results.filter(r => r.status === "rejected")).toHaveLength(13);
    const state = JSON.parse(await readFile(file, "utf8")) as State;
    expect(state.assignments).toHaveLength(7);
    expect(new Set(state.assignments.map(a => a.visitId)).size).toBe(7);
    expect(Object.keys(state.uploads)).toHaveLength(7);
    for (const [i, result] of results.entries()) {
      const retry = await importRoutes(file, "a", `upload-${i}`, [{visitId:`v${i}`,crewId:"001"}], true);
      expect(retry.status).toBe(result.status === "applied" ? "replay" : "rejected");
    }
  }, { crews: [crew("001", 7)] });
});


test("readers holding a state snapshot see the complete previous commit", async () => {
  await fixture(async file => {
    const before = await readFile(file, "utf8");
    const snapshot = await open(file, "r");
    try {
      expect((await importRoutes(file, "a", "u", [{visitId:"v",crewId:"001"}], true)).status).toBe("applied");
      expect(await snapshot.readFile("utf8")).toBe(before);
      expect((JSON.parse(await readFile(file, "utf8")) as State).assignments).toEqual([
        {tenant:"a",visitId:"v",crewId:"001"},
      ]);
    } finally {
      await snapshot.close();
    }
  });
});


test("concurrent retries and changed-content uploads share the same canonical file lock", async () => {
  await fixture(async file => {
    const alias = join(file, "..", "alias.json");
    await symlink(file, alias);
    const rows = [{visitId:"v",crewId:"001"}];
    const results = await Promise.all(Array.from({length:12}, (_, i) =>
      importRoutes(i % 2 ? file : alias, "a", "same", rows, true)));
    expect(results.filter(r => r.status === "applied")).toHaveLength(1);
    expect(results.filter(r => r.status === "replay")).toHaveLength(11);
    expect((JSON.parse(await readFile(file,"utf8")) as State).assignments).toHaveLength(1);
    const contenders = await Promise.all([
      importRoutes(file,"a","race",[{visitId:"x",crewId:"001"}],true),
      importRoutes(alias,"a","race",[{visitId:"y",crewId:"001"}],true),
    ]);
    expect(contenders.map(r => r.status).sort()).toEqual(["applied","rejected"]);
    const state = JSON.parse(await readFile(file,"utf8")) as State;
    expect(state.assignments).toHaveLength(2);
    expect(Object.keys(state.uploads)).toHaveLength(2);
  }, {crews:[crew("001",10)]});
});

test("concurrent assignment of one visit to different crews has exactly one winner", async () => {
  await fixture(async file => {
    const results = await Promise.all([
      importRoutes(file,"a","u1",[{visitId:"v",crewId:"001"}],true),
      importRoutes(file,"a","u2",[{visitId:"v",crewId:"other"}],true),
    ]);
    expect(results.map(r => r.status).sort()).toEqual(["applied","rejected"]);
    const winner = results.find(r => r.status === "applied")!;
    expect((JSON.parse(await readFile(file,"utf8")) as State).assignments).toEqual(winner.assignments);
  }, {crews:[crew(),crew("other")]});
});

test("the public string contract preserves visit whitespace and caller mutation cannot alter queued rows", async () => {
  await fixture(async file => {
    const rows = [{visitId:" 0007 ",crewId:"001"}];
    const inFlight = importRoutes(file,"a","u",rows,true);
    rows[0]!.visitId = "changed";
    const first = await inFlight;
    expect(first.assignments).toEqual([{tenant:"a",visitId:" 0007 ",crewId:"001"}]);
    first.assignments[0]!.visitId = "changed result";
    const retry = await importRoutes(file,"a","u",[{visitId:" 0007 ",crewId:"001"}],true);
    expect(retry.assignments).toEqual([{tenant:"a",visitId:" 0007 ",crewId:"001"}]);
  });
});
