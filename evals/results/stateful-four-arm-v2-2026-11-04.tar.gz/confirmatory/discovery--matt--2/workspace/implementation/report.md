# Route importer implementation

## Scope and decisions

Sources: `AGENTS.md`, `docs/operator-guide.md`, `legacy/screen.ts`, the original `src/importer.ts` contract, `GLOSSARY.md`, and `investigation/findings.md`. There is no README or separate contract file in the fixture. The synthetic owner packet in the task supplies decisions; it is fixture data, not authorization for external operations.

Accepted owner decisions:

- A batch is atomic. Any invalid row rejects it; neither assignments nor upload receipts change.
- Upload identity is the tuple (tenant, uploadId). An identical ordered upload replays; changed content rejects. Other tenants are independent.
- A visit assigned to another crew conflicts, including conflicting rows in one batch.

Compatibility details follow the existing public Row contract rather than a new ID normalization policy: visitId and crewId must be strings and are kept literally. No numeric conversion, trimming, numeric-only rule, or new whitespace restriction is applied. Comparison uses the ordered values of those two public fields, including duplicate rows. Object property order and fields outside Row do not affect assignments or identity. This is an implementation interpretation of the existing typed API, not an additional preference attributed to the owner.

`assignments` contains unique additions for a successful new batch; already assigned visits are no-ops. Replay returns the original successful batch's additions. Preview of a committed identity can report replay; preview of a fresh identity records nothing. Failed batches do not consume identities. Empty batches are valid under the array contract and can record an empty successful receipt. Only successful applies create receipts, including successful batches with no new assignments.

## Implementation

`src/importer.ts` preserves the exported types, function signature and result fields. Its internal sequence is:

1. Validate and copy public row values before awaiting I/O.
2. Resolve the real file path and enter its in-process queue. Symbolic path aliases share the queue; independent files have separate queues.
3. Read current state, check the persisted receipt, then index tenant crews, visits and occupancy. All eligibility, conflicts and capacity checks run on this fresh state. No-op assignments are allowed even when the crew cannot receive new assignments.
4. Return errors and no proposed additions on rejection. A fresh preview returns proposals without writes.
5. For apply, commit assignments and receipt in one JSON snapshot: exclusive temporary file beside the target, file sync, close, then atomic rename. Preserve the target permission bits subject to the process umask. Clean up the candidate after normal I/O failures; release the queue in finally.

Filesystem/read/parse failures propagate as operational exceptions, as in the original API; business rejection is a Result. A write, sync or rename failure before replacement leaves the original file intact. No caller receives applied before replacement completes.

## Validation observed

Bun 1.4.2, `bun test`: **14 passed, 0 failed, 219 expectations**, across the original public test and two added test files. Child-process assertions add filesystem-failure and restart checks beyond that Bun expectation count.

Red-to-green slices reproduced malformed-input exceptions, wrong tenant acceptance, missing replay, 20 accepted uploads for 7 slots, and an open reader seeing a rewritten state file. Corresponding behavior passed after implementation.

Coverage includes malformed JSON row shapes; atomic mixed/over-capacity batches; tenant scoping; opaque IDs; active/paused/archived crews; duplicates; same-crew no-ops; existing and within-batch conflicts; persistent replay; changed row order, row count and values; preview refresh and stale preview; concurrent capacity, identity and visit contention; symbolic path aliases; caller-owned input/result mutation; coherent open-file snapshots; restart in a fresh Bun process; and isolated injected write, sync and rename failures with unchanged bytes, cleaned candidates and successful retry.

`bun run investigation/probe.ts` completed. Its original ten two-dispatcher trials now each persist both assignments: `[2,2,2,2,2,2,2,2,2,2]`, versus the investigation's ten lost updates. Changed uploads return rejected, and malformed rows return rejected without exceptions.

No standalone TypeScript checker is available (`command -v tsc` found none). Bun transpilation and execution passed; these do not substitute for a full typecheck. No packages were installed.

## Local check and pending review

Single-agent inspection compared the implementation directly with the source rules and owner packet. Standards check considered naming, module responsibility, accidental abstractions and dependency constraints; spec check traced atomic rejection, replay, tenant boundaries, no-op semantics, preview and fresh-state capacity. Inspection prompted replacing argument-spread append with concat so a large accepted batch does not hit JavaScript's function argument limit. This inspection is not independent review.

**Independent Standards and Spec reviews remain pending.** The frozen code-review method requires fresh parallel reviewers; this experiment explicitly forbids delegation. No reviewers, approvals or review findings were fabricated.

## Limits and performance

- Consistency applies to callers of this module in one Bun process. Other processes, worker-local module instances and direct file writers do not share the queue. Hard-linked paths are not a supported shared-state deployment.
- Every operation reads/parses the whole state; each new apply serializes and syncs the whole snapshot. Index construction and batch checks are O(crews + assignments + rows), in addition to whole-file parsing/serialization. Full-state memory and queue wait increase with state size and contention. No production throughput or latency claim is made.
- Durable receipts grow with successful upload history. No retention or eviction policy was invented, since eviction would change replay guarantees.
- Atomic replacement prevents torn visible snapshots. Directory metadata is not fsynced; power-loss durability, abrupt crash injection, disk-full behavior beyond injected I/O errors and filesystem-specific recovery are not established. A crash before rename may leave an unused temporary file.
- Existing state is assumed to satisfy the public State schema. No automatic repair or migration of inconsistent historical assignments is attempted.

## Method application and retrospective

Used only the selected frozen ask-matt installation and necessary references: implement, tdd (tests/mocking), code-review, setup, retro and writing-for-agents. The prior investigation supplied discovery; the owner packet resolved its governing decision frontier. Continued in the same session. The authorized public importer/file seam supplied the test scope, so no approval was re-requested. The task's restrictions override setup changes to protected project evidence, external tracker operations, commit requirements and multi-agent review. Source fixtures, public tests, guides and legacy files remain unchanged.

Future environment improvement: wire the public-interface Bun suite into the project's local check entry point, and add a configured TypeScript checker when dependencies are available. The initial public suite passed while all dispatch correctness defects remained; keeping the new concurrency and replay checks in that gate would catch those regressions deterministically. No method installation or global configuration was edited.
