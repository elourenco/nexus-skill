import { expect, test } from "bun:test";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { importRoutes } from "./src/importer";

const importer = JSON.stringify(import.meta.resolve("./src/importer.ts"));
const initial = JSON.stringify({crews:[{tenant:"a",id:"c",status:"active",capacity:2}],assignments:[],uploads:{}});

async function child(code: string) {
  const process = Bun.spawn([Bun.argv[0]!, "--eval", code], {stdout:"pipe",stderr:"pipe"});
  const [exitCode, stdout, stderr] = await Promise.all([
    process.exited, new Response(process.stdout).text(), new Response(process.stderr).text(),
  ]);
  expect({exitCode, stderr}).toEqual({exitCode:0, stderr:""});
  return stdout;
}

test("upload receipts survive a new Bun process", async () => {
  const dir = await mkdtemp(join(tmpdir(), "route-restart-"));
  const file = join(dir, "state.json");
  try {
    await writeFile(file, initial);
    const rows = [{visitId:"0007",crewId:"c"}];
    const first = await importRoutes(file, "a", "u", rows, true);
    const before = await readFile(file, "utf8");
    const output = await child(`
      const {importRoutes} = await import(${importer});
      console.log(JSON.stringify(await importRoutes(${JSON.stringify(file)}, "a", "u", [{visitId:"0007",crewId:"c"}], true)));
    `);
    expect(JSON.parse(output)).toEqual({...first,status:"replay"});
    expect(await readFile(file, "utf8")).toBe(before);
  } finally {
    await rm(dir, {recursive:true,force:true});
  }
});

// Filesystem fault injection is isolated in child processes; public tests use real I/O.
for (const phase of ["write", "sync", "rename"]) {
  test(`${phase} failure preserves state and does not poison later uploads`, async () => {
    const dir = await mkdtemp(join(tmpdir(), "route-fault-"));
    const file = join(dir, "state.json");
    try {
      await writeFile(file, initial);
      await child(`
        import {mock} from "bun:test";
        import * as fs from "node:fs/promises";
        import assert from "node:assert/strict";
        const actual = {...fs};
        const file = ${JSON.stringify(file)};
        const phase = ${JSON.stringify(phase)};
        const before = await actual.readFile(file, "utf8");
        let failed = false;
        function fault(point) {
          if (!failed && phase === point) {
            failed = true;
            throw new Error("injected " + point + " failure");
          }
        }
        mock.module("node:fs/promises", () => ({
          ...actual,
          open: async (...args) => {
            const handle = await actual.open(...args);
            return {
              writeFile: async (...args) => {fault("write"); return handle.writeFile(...args);},
              sync: async () => {fault("sync"); return handle.sync();},
              close: () => handle.close(),
            };
          },
          rename: async (...args) => {fault("rename"); return actual.rename(...args);},
        }));
        const {importRoutes} = await import(${importer});
        const rows = [{visitId:"v",crewId:"c"}];
        await assert.rejects(importRoutes(file,"a","u",rows,true), /injected/);
        assert.equal(await actual.readFile(file,"utf8"), before);
        assert.deepEqual(await actual.readdir(${JSON.stringify(dir)}), ["state.json"]);
        const results = await Promise.all([
          importRoutes(file,"a","u",rows,true), importRoutes(file,"a","u",rows,true),
        ]);
        assert.deepEqual(results.map(r => r.status).sort(), ["applied","replay"]);
        assert.equal(JSON.parse(await actual.readFile(file,"utf8")).assignments.length, 1);
      `);
    } finally {
      await rm(dir, {recursive:true,force:true});
    }
  });
}
