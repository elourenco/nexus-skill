import { open, readFile, realpath, rename, stat, unlink } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { basename, dirname, join } from "node:path";

export type Row = { visitId: string; crewId: string };
export type State = {
  crews: { tenant: string; id: string; status: "active" | "paused" | "archived"; capacity: number }[];
  assignments: { tenant: string; visitId: string; crewId: string }[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: "applied" | "preview" | "replay" | "rejected";
  assignments: State["assignments"];
  errors: string[];
};

type Upload = { version: 1; rows: string; assignments: State["assignments"] };

function rejected(errors: string[]): Result {
  return { status: "rejected", assignments: [], errors };
}

// Copy the two public row fields before any await; callers can reuse their input.
function parseRows(input: unknown): Row[] | undefined {
  if (!Array.isArray(input)) return;
  const rows: Row[] = [];
  for (const row of input) {
    if (!row || typeof row !== "object" || typeof row.visitId !== "string" || typeof row.crewId !== "string") return;
    rows.push({ visitId: row.visitId, crewId: row.crewId });
  }
  return rows;
}

// Each canonical file has a FIFO tail. Rejections release the next operation too.
// Preview joins the queue so it observes a coherent state, without reserving it.
const pending = new Map<string, Promise<void>>();
async function serialized<T>(file: string, run: () => Promise<T>): Promise<T> {
  const previous = pending.get(file) ?? Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>(resolve => { release = resolve; });
  pending.set(file, current);
  await previous;
  try {
    return await run();
  } finally {
    release();
    if (pending.get(file) === current) pending.delete(file);
  }
}

// Keep the candidate beside the state file so rename is an atomic replacement.
// The receipt and assignments are committed together, never in separate writes.
async function persist(file: string, state: State): Promise<void> {
  const temporary = join(dirname(file), `.${basename(file)}.${randomUUID()}.tmp`);
  const mode = (await stat(file)).mode & 0o777;
  const handle = await open(temporary, "wx", mode);
  try {
    try {
      await handle.writeFile(JSON.stringify(state));
      await handle.sync();
    } finally {
      await handle.close();
    }
    await rename(temporary, file);
  } finally {
    // Do not mask the original I/O failure. Crash leftovers are never read as state.
    await unlink(temporary).catch(() => {});
  }
}

// Existing API: state file already exists. rows is untrusted JSON; malformed input
// must return rejected, not throw. Files are used in a single Bun process.
export async function importRoutes(file: string, tenant: string, uploadId: string, input: unknown, apply: boolean): Promise<Result> {
  const rows = parseRows(input);
  if (!rows) return rejected(["rows must be an array of objects with string visitId and crewId"]);
  const canonicalFile = await realpath(file);
  return serialized(canonicalFile, () => importBatch(canonicalFile, tenant, uploadId, rows, apply));
}

async function importBatch(file: string, tenant: string, uploadId: string, rows: Row[], apply: boolean): Promise<Result> {
  const state: State = JSON.parse(await readFile(file, "utf8"));
  // JSON tuples avoid delimiter collisions and special object-property identities.
  const uploadKey = JSON.stringify([tenant, uploadId]);
  const fingerprint = JSON.stringify(rows);
  if (Object.hasOwn(state.uploads, uploadKey)) {
    const upload = state.uploads[uploadKey] as Upload;
    if (!upload || upload.version !== 1 || upload.rows !== fingerprint || !Array.isArray(upload.assignments)) {
      return rejected(["upload identity already used with different rows or an unsupported receipt"]);
    }
    return { status: "replay", assignments: upload.assignments, errors: [] };
  }
  const added: State["assignments"] = [];
  const errors: string[] = [];
  const crews = new Map(state.crews.filter(c => c.tenant === tenant).map(c => [c.id, c]));
  const visits = new Map<string, string>();
  const counts = new Map<string, number>();
  for (const assignment of state.assignments) {
    if (assignment.tenant !== tenant || visits.has(assignment.visitId)) continue;
    visits.set(assignment.visitId, assignment.crewId);
    counts.set(assignment.crewId, (counts.get(assignment.crewId) ?? 0) + 1);
  }
  for (const [index, row] of rows.entries()) {
    const error = (message: string) => errors.push(`row ${index + 1}: ${message}`);
    const crew = crews.get(row.crewId);
    if (!crew) {
      error("unknown crew in tenant");
      continue;
    }
    const assignedCrew = visits.get(row.visitId);
    if (assignedCrew !== undefined) {
      if (assignedCrew !== row.crewId) error("visit already assigned to another crew");
      continue;
    }
    if (crew.status !== "active") {
      error("crew is not active");
      continue;
    }
    const count = counts.get(crew.id) ?? 0;
    if (count >= crew.capacity) {
      error("crew capacity exceeded");
      continue;
    }
    visits.set(row.visitId, crew.id);
    counts.set(crew.id, count + 1);
    added.push({ tenant, visitId: row.visitId, crewId: crew.id });
  }
  if (errors.length) return rejected(errors);
  state.assignments = state.assignments.concat(added);
  if (apply) {
    state.uploads[uploadKey] = { version: 1, rows: fingerprint, assignments: added } satisfies Upload;
    await persist(file, state);
  }
  return { status: apply ? "applied" : "preview", assignments: added, errors: [] };
}
