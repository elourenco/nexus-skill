# Route assignment

## Language

**Tenant**:
The scope within which crew IDs and visit IDs identify their respective crews and visits. Different tenants may reuse the same IDs.

**Crew**:
A dispatch team identified by an opaque string, with an active, paused, or archived status and an assignment capacity.

**Assignment**:
The association of a visit with a crew within one tenant. A visit already assigned to the same crew is a no-op when submitted again.

**Capacity**:
The number of visits a crew can receive, rather than the number of spreadsheet rows.

**Preview**:
An advisory assessment of an import that reserves no capacity and is safe to refresh.
