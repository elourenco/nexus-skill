# Investigation only — route importer

No implementation changes. Product decisions remain pending the standardized synthetic owner packet. No owner was contacted. Sources inspected: all five initial project files; no README or separate contract exists in this fixture. The API types/comments and legacy screen supply the public contract.

## Method and scope

Applied the selected frozen `ask-matt` router and its `grill-with-docs`, `grilling`, and `domain-modeling` references. Facts were investigated locally by the single agent, overriding the primitive's delegation instruction as explicitly required by the task. Questions below are the current decision frontier, not accepted preferences. Setup's tracker/confirmation workflow was read but not performed: this phase authorizes investigation, prohibits external services and real-user contact, and provides no need for a tracker. No independent review was performed; it remains pending if required by a later implementation flow. No ADR records an unmade decision.

## Established requirements

| Requirement | Source |
| --- | --- |
| Preserve the supported `importRoutes(file, tenant, uploadId, rows, apply)` API and screen wrappers. | `AGENTS.md:2`; `src/importer.ts:7`; `legacy/screen.ts:1-3` |
| Results retain `status` (`applied`, `preview`, `replay`, `rejected`), `assignments`, and `errors`. Rejections must retain errors. | `src/importer.ts:4`; `legacy/screen.ts:4-5` |
| `rows` is untrusted JSON; malformed input returns `rejected` rather than throwing. The state file already exists; execution uses a single Bun process. | `src/importer.ts:5-6` |
| Crew IDs are opaque strings, including significant leading zeroes. Crew/visit identity is tenant scoped; identical IDs across tenants are allowed. | `docs/operator-guide.md:2` |
| Paused/archived crews cannot receive new assignments. Capacity counts visits, not spreadsheet rows. Visit IDs are unique per tenant. | `docs/operator-guide.md:2` |
| Reassigning a visit to the same crew is a no-op, consuming no extra slot. | `docs/operator-guide.md:2` |
| Preview is refresh safe, reserves no capacity, and is advisory. Apply must assess current state because assignments may change after preview. | `docs/operator-guide.md:4` |
| Bun built-ins only; preserve public tests, legacy sources, guide, and API; no services/dependencies/commits. | `AGENTS.md:2`; task instructions |

## Observed public behavior

`bun test`: 1 pass, 0 fail, 3 expectations. The sole public test covers a valid preview, one returned assignment, and byte-identical file contents after preview. Passing it does not establish importer correctness.

`bun run investigation/probe.ts` uses fresh local temporary state, calls the public API, prints results, and removes its state afterward. Observations from the investigation run:

- A crew existing only in tenant `b` was accepted for tenant `a`. Lookup ignores tenant (`src/importer.ts:11`).
- Paused and archived crews with zero capacity received assignments. Two distinct visits were added to an active crew with capacity one. Status/capacity are never checked (`src/importer.ts:11-13`).
- Duplicate rows append duplicate assignments; a visit already assigned to another crew acquires a second assignment. No uniqueness/no-op handling exists (`src/importer.ts:13`). The correct cross-crew outcome needs a product decision.
- Visit `0007` becomes `7`; `visit-A` becomes `NaN` (`src/importer.ts:13`). Crew identity uses loose equality (`src/importer.ts:11`), despite the opaque string rule. Visit lexical rules need confirmation rather than extrapolation from the crew rule.
- `null`, `{}`, and `[null]` inputs throw. `[{}]` returns `applied` with an error, not `rejected` (`src/importer.ts:10-16`).
- A mixed good/unknown-crew batch persists its good row and returns `applied` with an error. This is an observation, not an approved partial-import policy (`docs/operator-guide.md:6`).
- Repeating an upload with the same ID and then changed contents returns `applied` every time; identical contents append duplicates. `uploadId` and `uploads` are unused (`src/importer.ts:7-16`). Neither replay semantics nor changed-content semantics can be inferred from this.
- Ten trials of two concurrent applies each returned success twice but persisted only one assignment, despite capacity ten. The unprotected read/modify/write cycle loses updates (`src/importer.ts:8-15`). This is a reproduced failure, not a guarantee about every scheduling interleaving.

## Product decision frontier — await synthetic owner packet

1. **Bad rows / atomicity:** Should any invalid or ineligible row reject the entire batch with zero changes? Recommendation: yes, for predictable dispatch and retries. If partial success is preferred, specify the returned status and accepted/rejected row reporting within the screen API. Capacity overflow and conflicting duplicates need to follow this policy too.
2. **Upload identity / retries:** Should an upload ID be tenant scoped and an identical retry replay the recorded outcome without writing again, while reuse with changed contents is rejected? Recommendation: yes. Define what counts as identical (including row ordering and duplicate rows), which outcomes are recorded, whether IDs survive restarts, and whether preview participates. These are open semantics, not authorization to build a particular ledger.
3. **Visit already assigned elsewhere:** Should assigning an existing visit to another crew, including conflicting rows within one sheet, reject the conflict rather than move the visit? Recommendation: yes until explicit move behavior is requested. If moves are supported, clarify source/destination capacity effects and conflict ordering; do not silently choose first/last row wins.
4. **Visit ID interpretation:** Should visit IDs remain exact, nonempty strings without numeric conversion or implicit trimming, preserving `0007` and `visit-A`? Recommendation: yes, consistent with the string API. Only crew opacity is explicit in the guide; clarify permitted whitespace and numeric JSON values before freezing validation rules.

The first two questions are explicitly called open in `docs/operator-guide.md:6`. The latter two are material gaps exposed by the uniqueness requirement and the existing coercion. Do not ask the owner to rediscover documented tenant, capacity, lifecycle, preview, or API requirements.

## Engineering implications and limits

- Several dispatchers require consistent applies: serialized state updates in this single-process fixture, capacity revalidation on apply, durable-before-success results, and safe file replacement are engineering concerns. No implementation strategy was selected or coded.
- Current work is a full-file read/parse/write per call plus a crew scan per row: approximately O(state size + rows × crews), with full-state memory and I/O. Serializing apply will affect queue latency; indexed lookups can avoid repeated scans. No workload sizes, latency targets, or throughput measurements are available, so no performance claim is made.
- No crash injection, disk-failure testing, load test, or multi-process guarantee was attempted. The source explicitly scopes execution to a single Bun process. Persistence failure behavior beyond the malformed-row contract is unspecified.
- Replay result contents, no-op result contents, error wording, and canonical upload comparison remain details to settle from the next owner packet after the governing decisions. Existing result fields/status names are fixed.
- No implementation, public-source edits, external access, dependency installation, Git operations, or delegation occurred. Added artifacts are this report, a glossary of established terms, and a reproducible probe.
