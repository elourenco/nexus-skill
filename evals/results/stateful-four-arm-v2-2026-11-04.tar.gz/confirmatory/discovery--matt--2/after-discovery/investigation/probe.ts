import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { importRoutes, type State } from "../src/importer";

const dir = await mkdtemp(join(import.meta.dir, ".probe-"));
const base = (): State => ({
  crews: [
    { tenant: "b", id: "007", status: "active", capacity: 10 },
    { tenant: "a", id: "007", status: "active", capacity: 1 },
    { tenant: "a", id: "paused", status: "paused", capacity: 0 },
    { tenant: "a", id: "archived", status: "archived", capacity: 0 },
  ], assignments: [], uploads: {},
});
async function probe(name: string, rows: unknown, state = base()) {
  const file = join(dir, `${name}.json`);
  await writeFile(file, JSON.stringify(state));
  try {
    const result = await importRoutes(file, "a", "upload", rows, true);
    console.log(JSON.stringify({ name, result, persisted: JSON.parse(await readFile(file, "utf8")) }));
  } catch (error) {
    console.log(JSON.stringify({ name, thrown: String(error) }));
  }
}
try {
  await probe("opaque-and-tenant", [{ visitId: "0007", crewId: "007" }, { visitId: "visit-A", crewId: "007" }]);
  await probe("foreign-only", [{ visitId: "1", crewId: "foreign" }], {
    crews: [{ tenant: "b", id: "foreign", status: "active", capacity: 1 }], assignments: [], uploads: {},
  });
  await probe("inactive", [{ visitId: "1", crewId: "paused" }, { visitId: "2", crewId: "archived" }]);
  await probe("capacity", [{ visitId: "1", crewId: "007" }, { visitId: "2", crewId: "007" }], {
    ...base(), crews: [{ tenant: "a", id: "007", status: "active", capacity: 1 }],
  });
  await probe("duplicate", [{ visitId: "1", crewId: "007" }, { visitId: "1", crewId: "007" }]);
  await probe("conflicting-crew", [{ visitId: "1", crewId: "007" }], {
    ...base(), assignments: [{ tenant: "a", visitId: "1", crewId: "other" }],
  });
  await probe("mixed", [{ visitId: "1", crewId: "007" }, { visitId: "2", crewId: "missing" }]);
  await probe("null", null);
  await probe("object", {});
  await probe("null-row", [null]);
  await probe("missing-fields", [{}]);
  await probe("missing-visit", [{ crewId: "007" }]);
  await probe("numeric-crew", [{ visitId: "1", crewId: 7 }]);
  const file = join(dir, "repeat.json");
  await writeFile(file, JSON.stringify(base()));
  const rows = [{ visitId: "1", crewId: "007" }];
  const repeat = [await importRoutes(file, "a", "same", rows, true), await importRoutes(file, "a", "same", rows, true),
    await importRoutes(file, "a", "same", [{ visitId: "2", crewId: "007" }], true)];
  console.log(JSON.stringify({ name: "repeat-and-changed", repeat, persisted: JSON.parse(await readFile(file, "utf8")) }));
  const counts: number[] = [];
  for (let i = 0; i < 10; i++) {
    const concurrentFile = join(dir, `concurrent-${i}.json`);
    const state = base();
    state.crews = [{ tenant: "a", id: "c", status: "active", capacity: 10 }];
    await writeFile(concurrentFile, JSON.stringify(state));
    const results = await Promise.all(["1", "2"].map(visitId => importRoutes(concurrentFile, "a", visitId, [{ visitId, crewId: "c" }], true)));
    const persisted = JSON.parse(await readFile(concurrentFile, "utf8"));
    counts.push(persisted.assignments.length);
    if (results.some(result => result.status !== "applied")) throw new Error("Unexpected concurrent result");
  }
  console.log(JSON.stringify({ name: "concurrent-two-successes", persistedAssignmentCounts: counts }));
} finally {
  await rm(dir, { recursive: true, force: true });
}
