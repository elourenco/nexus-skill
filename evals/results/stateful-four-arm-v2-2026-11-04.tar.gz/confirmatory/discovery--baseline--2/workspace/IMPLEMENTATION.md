# Implementação e validação local

## Fontes e decisões

Foram relidos explicitamente AGENTS.md, docs/operator-guide.md, legacy/screen.ts, src/importer.ts, importer.test.ts e INVESTIGATION.md antes da alteração. Não há README ou contrato adicional na fixture. O pacote do proprietário resolve as decisões de atomicidade, identidade de upload, replay e conflito entre equipes. Nenhum serviço, instalação de dependências ou agente adicional foi utilizado.

- Qualquer erro rejeita o lote inteiro, com assignments vazio e errors preenchido. Rejeições não alteram o arquivo nem consomem uploadId; uma tentativa corrigida pode usar a mesma identidade.
- Identidade: par (tenant, uploadId), codificado como array JSON para evitar colisões por delimitadores e chaves especiais. O receipt persiste junto às atribuições.
- Replay compara os campos públicos visitId e crewId em ordem, incluindo duplicatas, sem efeitos novos. Campos extras fora de Row são ignorados; ordem das propriedades JSON não altera identidade. Replay retorna as adições originais e pode ser consultado também pelo wrapper preview.
- Conflitos contra o estado atual ou dentro do lote rejeitam o lote. Duplicatas para a mesma equipe são no-op; capacidade conta visitas distintas.
- Equipes são buscadas no tenant; pausadas/arquivadas bloqueiam adições, mas permitem no-op existente.
- Preview é consultivo e não escreve receipts. Apply relê e valida o estado dentro da exclusão mútua.

O pacote não respondeu à pergunta sobre normalização de visitId, identificadores vazios ou espaços. Foi preservado o conteúdo das strings da API, sem coerção numérica, trim ou nova restrição de conteúdo. Assim, zeros iniciais permanecem significativos. Uma política adicional de conteúdo continua indefinida; nenhuma aprovação adicional foi solicitada para o escopo autorizado.

## Concorrência, falhas e custo

Fila por caminho real do arquivo protege o ciclo read/validate/write no único processo Bun suportado. Caminhos relativos/absolutos e symlinks que resolvem para o mesmo arquivo compartilham a fila; arquivos distintos não compartilham um lock global. A entrada é copiada antes do primeiro await para evitar alteração pelo chamador durante a espera.

A escrita usa arquivo temporário exclusivo ao lado do estado, sync do arquivo e rename. Falha antes do rename retorna rejected; o estado anterior permanece disponível e o temporário é removido quando possível. Estado e receipt são publicados na mesma substituição. JSON/estrutura de estado inválidos e falhas de I/O retornam rejeição; fila é liberada em finally.

Índices Map evitam a busca linear por equipe a cada linha. Custo por chamada: O(tamanho do estado + linhas), incluindo leitura, validação e serialização; armazenamento de receipts cresce com uploads e suas linhas. Escritas no mesmo arquivo são serializadas, inclusive entre tenants. Não há metas de latência/throughput, limites de tamanho, benchmark de carga ou política de retenção definidos. O caso concorrente com 20 uploads valida integridade, não desempenho de produção.

Limites: não há coordenação entre processos, hardlinks ou escritores que ignorem esta API; não há garantia de durabilidade do rename em perda de energia (diretório não recebe fsync), nem teste de interrupção do processo. Temporários órfãos de crash não têm rotina de recuperação. Estados previamente corrompidos com visitas/equipes duplicadas no tenant são rejeitados, sem migração automática. Receipts existentes com formato desconhecido na identidade solicitada são rejeitados para evitar sobrescrita silenciosa.

## Evidências observadas

`bun test`, Bun 1.4.2: **17 testes passaram, 0 falharam, 124 asserções**. O teste público foi preservado. A suíte adicional usa arquivos sintéticos temporários e cobre:

- entradas malformadas, identificadores opacos, lookup por tenant e rejeição atômica;
- capacidade, duplicatas, no-op, estados de equipe e conflitos de visita;
- preview repetido e revalidação no apply;
- replay persistido, conteúdo/ordem alterados, identidade independente por tenant e uploads vazios;
- 20 uploads simultâneos, disputas por capacidade, visita e identidade de upload;
- caminhos via symlink, JSON inválido e liberação da fila após erro;
- falha real de escrita com diretório sem permissão de escrita: rejeição, arquivo inalterado e retry bem-sucedido após restaurar a permissão;
- mutação da entrada pelo chamador durante execução assíncrona.

Não foi executado typecheck estático: não há compilador TypeScript/dependência/configuração disponível na fixture. Bun executou o TypeScript nos testes. Não houve revisão independente neste experimento single-agent.

Alterações restritas a src/importer.ts, nova suíte importer.behavior.test.ts e este relatório; fontes legadas, documentação, investigação e teste público foram preservados.
