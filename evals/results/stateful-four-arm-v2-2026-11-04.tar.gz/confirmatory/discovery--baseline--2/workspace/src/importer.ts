import {readFile, realpath, open, rename, unlink} from "node:fs/promises";
import {randomUUID} from "node:crypto";

export type Row = {visitId:string; crewId:string};
export type State = {crews:{tenant:string; id:string; status:"active"|"paused"|"archived"; capacity:number}[]; assignments:{tenant:string; visitId:string; crewId:string}[]; uploads:Record<string,unknown>};
export type Result = {status:"applied"|"preview"|"replay"|"rejected"; assignments:State["assignments"]; errors:string[]};
type Receipt = {version:1; rows:Row[]; assignments:State["assignments"]};

const queues = new Map<string, Promise<void>>();
const rejected = (message:string):Result => ({status:"rejected", assignments:[], errors:[message]});
const object = (value:unknown):value is Record<string,unknown> => value !== null && typeof value === "object" && !Array.isArray(value);
const isRow = (value:unknown):value is Row => object(value) && typeof value.visitId === "string" && typeof value.crewId === "string";
function isState(value:unknown):value is State {
  return object(value) && Array.isArray(value.crews) && value.crews.every(c => object(c) &&
    typeof c.tenant === "string" && typeof c.id === "string" &&
    ["active","paused","archived"].includes(c.status as string) && Number.isSafeInteger(c.capacity) && (c.capacity as number) >= 0) &&
    Array.isArray(value.assignments) && value.assignments.every(a => isRow(a) && typeof (a as Record<string,unknown>).tenant === "string") && object(value.uploads);
}
function isReceipt(value:unknown):value is Receipt {
  return object(value) && value.version === 1 && Array.isArray(value.rows) && value.rows.every(isRow) &&
    Array.isArray(value.assignments) && value.assignments.every(a => isRow(a) && typeof (a as Record<string,unknown>).tenant === "string");
}

// Replacement is atomic for readers. Temporary files live beside the state file.
async function persist(file:string, state:State):Promise<void> {
  const temporary = `${file}.${randomUUID()}.tmp`;
  try {
    const handle = await open(temporary, "wx", 0o600);
    try { await handle.writeFile(JSON.stringify(state)); await handle.sync(); }
    finally { await handle.close(); }
    await rename(temporary, file);
  } finally { await unlink(temporary).catch(() => {}); }
}

// Existing screen API. The state file must exist; coordination covers one Bun process.
export async function importRoutes(file:string, tenant:string, uploadId:string, rows:unknown, apply:boolean):Promise<Result> {
  if (typeof tenant !== "string" || typeof uploadId !== "string" || typeof apply !== "boolean" ||
      !Array.isArray(rows) || !rows.every(isRow)) return rejected("Expected tenant, uploadId and row identifiers as strings, and rows as an array");
  // Snapshot caller-owned input before the first await. Identity is ordered public Row fields.
  const input:Row[] = rows.map(({visitId,crewId}) => ({visitId,crewId}));
  let path:string;
  try { path = await realpath(file); } catch { return rejected("Unable to read state file"); }
  const previous = queues.get(path) ?? Promise.resolve();
  let release!:() => void;
  const current = new Promise<void>(resolve => { release = resolve; });
  queues.set(path, current);
  await previous;
  try {
    const parsed:unknown = JSON.parse(await readFile(path,"utf8"));
    if (!isState(parsed)) return rejected("Invalid state file");
    const state = parsed;
    const key = JSON.stringify([tenant,uploadId]);
    if (Object.hasOwn(state.uploads,key)) {
      const receipt = state.uploads[key];
      if (!isReceipt(receipt)) return rejected("Invalid upload receipt");
      if (JSON.stringify(receipt.rows) !== JSON.stringify(input)) return rejected("Upload identity already used with different rows");
      return {status:"replay", assignments:receipt.assignments, errors:[]};
    }
    const crews = new Map<string,State["crews"][number]>();
    const visits = new Map<string,string>();
    const counts = new Map<string,number>();
    for (const crew of state.crews) {
      if (crew.tenant !== tenant) continue;
      if (crews.has(crew.id)) return rejected("Duplicate crew in state");
      crews.set(crew.id,crew);
    }
    for (const assignment of state.assignments) {
      if (assignment.tenant !== tenant) continue;
      if (visits.has(assignment.visitId)) return rejected("Duplicate visit in state");
      visits.set(assignment.visitId,assignment.crewId);
      counts.set(assignment.crewId,(counts.get(assignment.crewId) ?? 0) + 1);
    }
    const added:State["assignments"] = [];
    const errors:string[] = [];
    for (const [index,row] of input.entries()) {
      const fail = (message:string) => errors.push(`Row ${index + 1}: ${message}`);
      const crew = crews.get(row.crewId);
      if (!crew) { fail("unknown crew"); continue; }
      if (visits.has(row.visitId)) {
        if (visits.get(row.visitId) !== row.crewId) fail("visit assigned to another crew");
        continue;
      }
      if (crew.status !== "active") { fail("crew is not active"); continue; }
      const count = counts.get(crew.id) ?? 0;
      if (count >= crew.capacity) { fail("crew capacity exceeded"); continue; }
      added.push({tenant,visitId:row.visitId,crewId:row.crewId});
      visits.set(row.visitId,row.crewId);
      counts.set(crew.id,count + 1);
    }
    if (errors.length) return {status:"rejected", assignments:[], errors};
    if (!apply) return {status:"preview", assignments:added, errors:[]};
    state.assignments.push(...added);
    state.uploads[key] = {version:1, rows:input, assignments:added} satisfies Receipt;
    await persist(path,state);
    return {status:"applied", assignments:added, errors:[]};
  } catch { return rejected("Unable to read or persist state file"); }
  finally {
    release();
    if (queues.get(path) === current) queues.delete(path);
  }
}
