import {test, expect} from "bun:test";
import {mkdtemp, readFile, writeFile, rm, symlink, readdir, chmod} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {importRoutes, type State, type Row} from "./src/importer";
import {preview, apply} from "./legacy/screen";

const crew = (id="01", tenant="a", capacity=2, status:"active"|"paused"|"archived"="active") => ({tenant,id,capacity,status});
async function fixture(run:(file:string, initial:string) => Promise<void>, overrides:Partial<State> = {}) {
  const dir = await mkdtemp(join(tmpdir(),"routes-behavior-"));
  const file = join(dir,"state.json");
  const initial = JSON.stringify({crews:[crew()],assignments:[],uploads:{},...overrides});
  try { await writeFile(file,initial); await run(file,initial); }
  finally { await rm(dir,{recursive:true,force:true}); }
}
const state = async (file:string):Promise<State> => JSON.parse(await readFile(file,"utf8"));
const row = (visitId="007", crewId="01"):Row => ({visitId,crewId});

test("malformed JSON values reject without mutation or exceptions", async () => {
  await fixture(async (file,initial) => {
    for (const rows of [null,{},"rows",1,[null],["x"],[{}],[{visitId:7,crewId:"01"}],[{visitId:"7",crewId:1}]]) {
      const result = await apply(file,"a","u",rows);
      expect(result.status).toBe("rejected");
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.assignments).toEqual([]);
      expect(await readFile(file,"utf8")).toBe(initial);
    }
  });
});

test("opaque identifiers and tenant-scoped crew lookup", async () => {
  await fixture(async file => {
    expect((await apply(file,"a","u",[row()])).status).toBe("applied");
    expect((await state(file)).assignments).toEqual([{tenant:"a",...row()}]);
    expect((await apply(file,"a","v",[row("8","1")])).status).toBe("rejected");
    expect((await apply(file,"a","w",[row("9","foreign")])).status).toBe("rejected");
  },{crews:[crew("01"),crew("1","b"),crew("foreign","b")]});
});

test("any invalid row rejects the entire batch and leaves upload identity available", async () => {
  await fixture(async (file,initial) => {
    const result = await apply(file,"a","u",[row(),row("8","missing")]);
    expect(result.status).toBe("rejected");
    expect(result.assignments).toEqual([]);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await readFile(file,"utf8")).toBe(initial);
    expect((await apply(file,"a","u",[row()])).status).toBe("applied");
  });
});

test("capacity counts distinct visits, duplicate rows and existing same-crew visits are no-ops", async () => {
  await fixture(async file => {
    const result = await apply(file,"a","u",[row("old"),row(),row()]);
    expect(result.assignments).toEqual([{tenant:"a",...row()}]);
    expect(result.status).toBe("applied");
    const before = await readFile(file,"utf8");
    expect((await apply(file,"a","overflow",[row("extra")])).status).toBe("rejected");
    expect(await readFile(file,"utf8")).toBe(before);
    expect((await apply(file,"a","noop",[row("old")])).assignments).toEqual([]);
  },{assignments:[{tenant:"a",...row("old")}]});
});

test("paused and archived crews permit existing no-ops but reject new assignments", async () => {
  for (const status of ["paused","archived"] as const) {
    await fixture(async (file,initial) => {
      expect((await preview(file,"a","existing",[row("old")])).status).toBe("preview");
      expect((await apply(file,"a","new",[row()])).status).toBe("rejected");
      expect(await readFile(file,"utf8")).toBe(initial);
    },{crews:[crew("01","a",1,status)],assignments:[{tenant:"a",...row("old")}]});
  }
  await fixture(async (file,initial) => {
    expect((await apply(file,"a","u",[row()])).status).toBe("rejected");
    expect(await readFile(file,"utf8")).toBe(initial);
  },{crews:[crew("01","a",0)]});
});

test("existing and within-batch conflicting crews reject atomically", async () => {
  await fixture(async (file,initial) => {
    expect((await apply(file,"a","u",[row("new"),row("old","other")])).status).toBe("rejected");
    expect(await readFile(file,"utf8")).toBe(initial);
    expect((await apply(file,"a","v",[row(),row("007","other")])).status).toBe("rejected");
    expect(await readFile(file,"utf8")).toBe(initial);
  },{crews:[crew(),crew("other")],assignments:[{tenant:"a",...row("old")}]});
});

test("preview is repeatable and apply revalidates capacity against latest state", async () => {
  await fixture(async (file,initial) => {
    for (let i=0;i<2;i++) expect((await preview(file,"a","u",[row()])).status).toBe("preview");
    expect(await readFile(file,"utf8")).toBe(initial);
    expect((await apply(file,"a","other",[row("other")])).status).toBe("applied");
    const before = await readFile(file,"utf8");
    expect((await apply(file,"a","u",[row()])).status).toBe("rejected");
    expect(await readFile(file,"utf8")).toBe(before);
  },{crews:[crew("01","a",1)]});
});

test("replay is durable, side-effect free and returns original additions", async () => {
  await fixture(async file => {
    const rows = [row(),row("8")];
    const original = await apply(file,"a","u",rows);
    const before = await readFile(file,"utf8");
    for (const fn of [apply,preview]) {
      const result = await fn(file,"a","u",rows);
      expect(result).toEqual({...original,status:"replay"});
      expect(await readFile(file,"utf8")).toBe(before);
    }
    for (const changed of [[...rows].reverse(),[row()],[...rows,row()],[row("9"),row("8")],[row("007","other"),row("8")]]) {
      expect((await apply(file,"a","u",changed)).status).toBe("rejected");
      expect(await readFile(file,"utf8")).toBe(before);
    }
    // Replay does not depend on crews still being active.
    const updated = await state(file); updated.crews[0]!.status = "archived";
    await writeFile(file,JSON.stringify(updated));
    expect((await apply(file,"a","u",rows)).status).toBe("replay");
  });
});

test("same upload and visit IDs are independent across tenants, including delimiter-like IDs", async () => {
  await fixture(async file => {
    for (const tenant of ["a","b","a\",\"b"]) {
      expect((await apply(file,tenant,"__proto__",[row()])).status).toBe("applied");
    }
    expect((await state(file)).assignments.length).toBe(3);
    expect(Object.keys((await state(file)).uploads).length).toBe(3);
  },{crews:[crew(),crew("01","b"),crew("01","a\",\"b")]});
});

test("simultaneous dispatchers preserve all accepted updates", async () => {
  await fixture(async file => {
    const results = await Promise.all(Array.from({length:20},(_,i) => apply(file,"a",`u${i}`,[row(`v${i}`)])));
    expect(results.every(r => r.status === "applied")).toBe(true);
    const saved = await state(file);
    expect(saved.assignments.length).toBe(20);
    expect(new Set(saved.assignments.map(a=>a.visitId)).size).toBe(20);
    expect(Object.keys(saved.uploads).length).toBe(20);
    expect(await readdir(join(file,".."))).toEqual(["state.json"]);
  },{crews:[crew("01","a",20)]});
});

test("concurrent capacity, same-visit and upload-identity races are serialized", async () => {
  await fixture(async file => {
    const results = await Promise.all([apply(file,"a","u",[row()]),apply(file,"a","v",[row("8")])]);
    expect(results.map(r=>r.status).sort()).toEqual(["applied","rejected"]);
    expect((await state(file)).assignments.length).toBe(1);
  },{crews:[crew("01","a",1)]});
  await fixture(async file => {
    const results = await Promise.all([apply(file,"a","u",[row()]),apply(file,"a","v",[row("007","other")])]);
    expect(results.map(r=>r.status).sort()).toEqual(["applied","rejected"]);
  },{crews:[crew(),crew("other")]});
  await fixture(async file => {
    const results = await Promise.all([apply(file,"a","u",[row()]),apply(file,"a","u",[row()])]);
    expect(results.map(r=>r.status).sort()).toEqual(["applied","replay"]);
    expect((await state(file)).assignments.length).toBe(1);
  });
  await fixture(async file => {
    const results = await Promise.all([apply(file,"a","u",[row()]),apply(file,"a","u",[row("8")])]);
    expect(results.map(r=>r.status).sort()).toEqual(["applied","rejected"]);
    expect((await state(file)).assignments.length).toBe(1);
  });
});

test("symlink and direct path share the same concurrency boundary", async () => {
  await fixture(async file => {
    const alias = `${file}.alias`; await symlink(file,alias);
    const results = await Promise.all([apply(file,"a","u",[row()]),apply(alias,"a","v",[row("8")])]);
    expect(results.every(r=>r.status === "applied")).toBe(true);
    expect((await state(file)).assignments.length).toBe(2);
  });
});

test("invalid storage rejects safely and does not poison the file queue", async () => {
  await fixture(async (file,initial) => {
    for (const content of ["invalid JSON","null",JSON.stringify({crews:[],assignments:null,uploads:{}})]) {
      await writeFile(file,content);
      expect((await apply(file,"a","u",[row()])).status).toBe("rejected");
      expect(await readFile(file,"utf8")).toBe(content);
    }
    await writeFile(file,initial);
    expect((await apply(file,"a","u",[row()])).status).toBe("applied");
    expect((await apply(`${file}.missing`,"a","u",[row()])).status).toBe("rejected");
  });
});

test("empty uploads are recorded and replayed", async () => {
  await fixture(async file => {
    expect((await apply(file,"a","empty",[])).status).toBe("applied");
    expect((await apply(file,"a","empty",[])).status).toBe("replay");
    expect((await apply(file,"a","empty",[row()])).status).toBe("rejected");
    expect((await state(file)).assignments).toEqual([]);
  });
});


test("write failure leaves state and receipt unchanged; retry succeeds", async () => {
  await fixture(async (file,initial) => {
    const directory = join(file,"..");
    await chmod(directory,0o500);
    try {
      const result = await apply(file,"a","u",[row()]);
      expect(result.status).toBe("rejected");
      expect(result.errors.length).toBeGreaterThan(0);
      expect(await readFile(file,"utf8")).toBe(initial);
    } finally { await chmod(directory,0o700); }
    expect((await apply(file,"a","u",[row()])).status).toBe("applied");
    expect(await readdir(directory)).toEqual(["state.json"]);
  });
});

test("queued import snapshots caller rows before awaiting storage", async () => {
  await fixture(async file => {
    const rows = [row()];
    const pending = importRoutes(file,"a","u",rows,true);
    rows[0]!.visitId = "mutated";
    rows.push(row("extra"));
    expect((await pending).assignments).toEqual([{tenant:"a",...row()}]);
    expect((await apply(file,"a","u",[row()])).status).toBe("replay");
  });
});
