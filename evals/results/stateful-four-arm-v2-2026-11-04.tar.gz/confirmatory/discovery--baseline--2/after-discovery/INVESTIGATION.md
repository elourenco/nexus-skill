# Investigação do importador de rotas

Escopo: somente investigação local; nenhuma implementação alterada. Fontes consultadas: `AGENTS.md`, `docs/operator-guide.md`, `legacy/screen.ts`, `src/importer.ts` e `importer.test.ts`. Não há README, contrato adicional ou scripts entre os arquivos da fixture. Nenhum serviço externo, instalação, delegação ou contato com o proprietário foi utilizado.

## Requisitos existentes e fontes

- `AGENTS.md:2`: API suportada em `src/importer.ts`; usar somente recursos nativos de Bun; preservar testes existentes, legacy e documentação.
- `src/importer.ts:2-7`: assinatura `importRoutes(file, tenant, uploadId, rows: unknown, apply): Promise<Result>`; linhas tipadas com `visitId` e `crewId` strings. O arquivo de estado já existe e o escopo de execução é um único processo Bun. JSON de entrada malformado deve retornar `rejected`, sem lançar exceção.
- `src/importer.ts:4` e `legacy/screen.ts:2-5`: preservar wrappers preview/apply e resultado com `status` (`applied|preview|replay|rejected`), `assignments` e `errors`. Rejeições devem manter seus erros; o contrato não define o conteúdo exato de assignments em replay, no-op ou rejeição.
- `docs/operator-guide.md:2`: procurar equipes no tenant correspondente; IDs de equipes são strings opacas, inclusive zeros iniciais. Tenants distintos podem repetir IDs de equipe e visita. Equipes pausadas e arquivadas não recebem novas atribuições. Capacidade conta visitas, não linhas. Visitas são únicas por tenant; atribuição existente à mesma equipe é no-op, sem consumir outra vaga.
- `docs/operator-guide.md:4`: preview pode ser atualizado sem reservar capacidade. Apply ocorre depois e deve considerar alterações intervenientes; preview é consultivo.
- `docs/operator-guide.md:6`: importação parcial diante de linha inválida e reenvio com conteúdo alterado são decisões explicitamente pendentes. O comportamento defeituoso atual não determina a política.
- `importer.test.ts:2`: exige preview com uma atribuição proposta e arquivo byte a byte inalterado.

## Evidência pública observada

`bun test` (Bun 1.4.2): 1 teste passou, 0 falharam, 3 asserções. Sondagens adicionais chamaram os wrappers públicos de `legacy/screen.ts` em arquivos temporários novos, removidos ao término.

| Cenário | Resultado observado |
| --- | --- |
| Tenant a solicita equipe existente somente em b | `applied`, persistindo atribuição em a para essa equipe |
| Equipe paused, archived ou com capacidade zero | Todas recebem novas visitas |
| Equipe com capacidade 1 recebe duas visitas | Duas atribuições persistidas |
| Visita já na mesma equipe e depois em outra | Acrescenta duplicata e atribuição conflitante, mantendo a anterior |
| Mesmo uploadId e mesmas linhas, depois conteúdo diferente | Todas as chamadas retornam `applied`; duplica visita; `uploads` permanece vazio |
| Linha válida e equipe desconhecida na mesma planilha | Persiste a válida, retorna `applied` com `errors: ["unknown crew"]` |
| crewId numérico 1 e equipe string "01" | Aceita por igualdade coerciva |
| visitId "007", "text" ou ausente | Persiste respectivamente "7", "NaN" e "NaN" |
| rows null, objeto ou array contendo null | Lança exceção, contrariando contrato |
| rows contendo string em vez de objeto | Retorna `applied`, sem atribuições e com erro de equipe desconhecida |
| visitId numérico | Aceita e converte para string |
| Lista vazia | Retorna `applied`, sem atribuições nem erros |
| Dois previews iguais | Retornam mesma proposta e preservam o estado |
| Duas aplicações concorrentes, uploads distintos, visitas distintas | Ambas retornam sucesso, mas o arquivo final contém apenas a visita da segunda chamada nesta execução |

Concorrência: a reprodução mostra perda de atualização dentro do processo suportado. Não estabelece qual chamada vencerá em outras execuções. O ciclo read/modify/write em `src/importer.ts:8-15` não tem exclusão mútua. A escrita direta também não oferece protocolo explícito de recuperação de interrupções. Falhas de escrita e interrupções não foram injetadas.

Performance: por inspeção, há busca linear em crews para cada linha (`src/importer.ts:10-11`) e leitura/serialização integral do estado por chamada. Custo aproximado O(linhas × equipes + tamanho do estado), com cópias em memória por chamada concorrente. Não existem metas de latência, tamanho ou throughput nas fontes, nem medições de carga nesta fase.

## Perguntas para o pacote do proprietário sintético

1. **Linhas inválidas e atomicidade:** uma linha inválida rejeita todo o upload ou permite aplicar as válidas? A política cobre falhas estruturais e de domínio (equipe desconhecida/inativa, lotação, conflito de visita)? Em aplicação parcial, quais status e atribuições a tela deve receber?
2. **Identidade do upload e reenvio:** qual o escopo de uploadId (tenant, arquivo ou outro)? Um reenvio idêntico retorna o resultado original como replay? O que acontece com o mesmo identificador e conteúdo alterado? Ordem das linhas e duplicatas contam como alteração? Tentativas rejeitadas consomem esse identificador? A assinatura e o campo uploads sugerem suporte a replay, mas não especificam essas regras.
3. **Conflito de equipe por visita:** uma visita já atribuída a outra equipe deve ser rejeitada ou transferida? Como tratar a mesma visita direcionada a equipes diferentes dentro da planilha? A unicidade por tenant é estabelecida; a política de resolução não é.
4. **Identificadores de entrada:** visitId também deve ser uma string opaca, preservando zeros iniciais? Strings vazias ou com espaços são inválidas, preservadas ou normalizadas? Os tipos publicados exigem strings, mas não definem essas regras de conteúdo. Para crewId, opacidade e preservação dos zeros já estão decididas.

## Limitações e próximos critérios técnicos

O pacote padronizado do proprietário ainda não chegou; nenhuma preferência foi presumida. Não é necessário consultar o usuário real. Sem implementação nesta fase.

Após as decisões, a implementação deve preservar a API, aplicar regras no estado corrente durante apply e impedir perda de atualizações entre dispatchers no único processo Bun. Revalidação de capacidade e persistência precisam compartilhar a mesma fronteira de concorrência. Tratamento de falhas de armazenamento, formato durável de uploads e recuperação precisam ser definidos tecnicamente; as fontes não estabelecem garantias de crash durability nem política de erros de I/O. Não há exigência publicada de múltiplos processos. O único teste público não valida esses aspectos.
