import { test, expect, spyOn } from "bun:test";
import * as fs from "node:fs/promises";
import { mkdtemp, readFile, writeFile, rm, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { importRoutes, type State, type Row } from "./src/importer";

const row = (visitId: string, crewId = "001"): Row => ({ visitId, crewId });
const base = (): State => ({ crews: [
  { tenant: "a", id: "001", status: "active", capacity: 2 },
  { tenant: "a", id: "other", status: "active", capacity: 2 },
  { tenant: "a", id: "paused", status: "paused", capacity: 2 },
  { tenant: "a", id: "archived", status: "archived", capacity: 2 },
  { tenant: "b", id: "001", status: "active", capacity: 2 },
  { tenant: "b", id: "foreign", status: "active", capacity: 2 },
], assignments: [], uploads: {} });
async function fixture(run: (file: string) => Promise<void>, state = base()) {
  const dir = await mkdtemp(join(tmpdir(), "route-regression-"));
  try {
    const file = join(dir, "state.json");
    await writeFile(file, JSON.stringify(state));
    await run(file);
  } finally { await rm(dir, { recursive: true, force: true }); }
}
const bytes = (file: string) => readFile(file, "utf8");
const saved = async (file: string): Promise<State> => JSON.parse(await bytes(file));

for (const bad of [null, {}, "text", [null], [{}], [1], [["x"]],
  [{ visitId: 7, crewId: "001" }], [{ visitId: "7", crewId: 1 }]]) {
  test(`malformed input rejects without effects: ${JSON.stringify(bad)}`, () => fixture(async file => {
    const before = await bytes(file);
    for (const apply of [false, true]) {
      const result = await importRoutes(file, "a", "u", bad, apply);
      expect(result.status).toBe("rejected");
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.assignments).toEqual([]);
      expect(await bytes(file)).toBe(before);
    }
  }));
}
for (const crew of ["foreign", "missing", "paused", "archived", "1"]) {
  test(`atomic mixed batch rejects ineligible crew ${crew}`, () => fixture(async file => {
    const before = await bytes(file);
    for (const apply of [false, true]) {
      const result = await importRoutes(file, "a", "u", [row("ok"), row("bad", crew)], apply);
      expect(result.status).toBe("rejected");
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.assignments).toEqual([]);
      expect(await bytes(file)).toBe(before);
    }
    expect((await importRoutes(file, "a", "u", [row("ok")], true)).status).toBe("applied");
  }));
}
test("preserves string identities, unique capacity and same-crew no-op", () => fixture(async file => {
  const rows = [row("0007"), row("0007"), row("9007199254740993")];
  const result = await importRoutes(file, "a", "u", rows, true);
  expect(result.status).toBe("applied");
  expect(result.assignments.map(a => a.visitId)).toEqual(["0007", "9007199254740993"]);
  expect((await importRoutes(file, "a", "noop", [row("0007")], true)).assignments).toEqual([]);
  const before = await bytes(file);
  expect((await importRoutes(file, "a", "full", [row("0007"), row("3")], true)).status).toBe("rejected");
  expect(await bytes(file)).toBe(before);
  expect((await saved(file)).assignments.length).toBe(2);
}));
test("preview refreshes without binding upload; apply revalidates current capacity", () => fixture(async file => {
  const before = await bytes(file);
  for (let i = 0; i < 2; i++) expect((await importRoutes(file, "a", "u", [row("1"), row("2")], false)).status).toBe("preview");
  expect(await bytes(file)).toBe(before);
  expect((await importRoutes(file, "a", "competing", [row("3")], true)).status).toBe("applied");
  const changed = await bytes(file);
  expect((await importRoutes(file, "a", "u", [row("1"), row("2")], true)).status).toBe("rejected");
  expect(await bytes(file)).toBe(changed);
  expect((await importRoutes(file, "a", "u", [row("1")], true)).status).toBe("applied");
}));
test("replay is ordered, persistent, tenant scoped and side effect free", () => fixture(async file => {
  const rows = [row("1"), row("2")];
  const first = await importRoutes(file, "a", "__proto__", rows, true);
  expect(first.status).toBe("applied");
  const before = await bytes(file);
  for (const apply of [false, true]) {
    const replay = await importRoutes(file, "a", "__proto__", rows.map(r => ({ ...r })), apply);
    expect(replay.status).toBe("replay");
    expect(replay.assignments).toEqual(first.assignments);
    expect(replay.errors).toEqual([]);
    for (const changed of [[row("2"), row("1")], [row("1")], [row("1"), row("3")]]) {
      expect((await importRoutes(file, "a", "__proto__", changed, apply)).status).toBe("rejected");
    }
    expect(await bytes(file)).toBe(before);
  }
  expect((await importRoutes(file, "b", "__proto__", rows, true)).status).toBe("applied");
  expect((await saved(file)).assignments.length).toBe(4);
}));
test("upload tuple keys cannot collide", () => fixture(async file => {
  const state = await saved(file);
  state.crews.push({ tenant: "a:b", id: "001", status: "active", capacity: 2 });
  await writeFile(file, JSON.stringify(state));
  expect((await importRoutes(file, "a:b", "c", [row("1")], true)).status).toBe("applied");
  expect((await importRoutes(file, "a", "b:c", [row("2")], true)).status).toBe("applied");
}));
test("existing and intra-batch conflicting assignments reject atomically", () => fixture(async file => {
  expect((await importRoutes(file, "a", "first", [row("1")], true)).status).toBe("applied");
  const before = await bytes(file);
  for (const rows of [[row("new"), row("1", "other")], [row("2"), row("2", "other")]]) {
    const r = await importRoutes(file, "a", "conflict", rows, true);
    expect(r.status).toBe("rejected");
    expect(r.errors.length).toBeGreaterThan(0);
    expect(await bytes(file)).toBe(before);
  }
}));
test("concurrent uploads preserve every committed effect", () => {
  const state = base(); state.crews[0]!.capacity = 30;
  return fixture(async file => {
    const results = await Promise.all(Array.from({ length: 30 }, (_, i) => importRoutes(file, "a", `u${i}`, [row(String(i))], true)));
    expect(results.every(r => r.status === "applied")).toBe(true);
    const result = await saved(file);
    expect(new Set(result.assignments.map(a => a.visitId)).size).toBe(30);
    expect(Object.keys(result.uploads).length).toBe(30);
  }, state);
});
test("concurrent capacity competition, aliases, duplicate replay and changed payload", () => fixture(async file => {
  const alias = join(file, "..", "alias.json"); await symlink(file, alias);
  const same = await Promise.all(Array.from({ length: 12 }, (_, i) => importRoutes(i % 2 ? alias : file, "a", "same", [row("1")], true)));
  expect(same.filter(r => r.status === "applied").length).toBe(1);
  expect(same.filter(r => r.status === "replay").length).toBe(11);
  const competition = await Promise.all(["2", "3", "4"].map(id => importRoutes(file, "a", id, [row(id)], true)));
  expect(competition.filter(r => r.status === "applied").length).toBe(1);
  expect(competition.filter(r => r.status === "rejected").length).toBe(2);
  expect((await saved(file)).assignments.length).toBe(2);
}));
test("concurrent changed rows under one identity have one winner", () => fixture(async file => {
  const results = await Promise.all(["1", "2"].map(id => importRoutes(file, "a", "u", [row(id)], true)));
  expect(results.map(r => r.status).sort()).toEqual(["applied", "rejected"]);
  expect((await saved(file)).assignments.length).toBe(1);
}));

test("same-crew no-op remains valid when crew is paused and full", () => {
  const state = base();
  state.crews[0]!.status = "paused"; state.crews[0]!.capacity = 0;
  state.assignments.push({ tenant: "a", visitId: "1", crewId: "001" });
  return fixture(async file => {
    const result = await importRoutes(file, "a", "noop", [row("1"), row("1")], true);
    expect(result.status).toBe("applied");
    expect(result.assignments).toEqual([]);
    expect((await saved(file)).assignments).toEqual(state.assignments);
  }, state);
});
test("opaque whitespace and distinct zero-prefixed visit strings are retained", () => {
  const state = base(); state.crews[0]!.capacity = 4;
  return fixture(async file => {
    const ids = ["007", "7", " visit-x ", "visit-x"];
    const result = await importRoutes(file, "a", "u", ids.map(id => row(id)), true);
    expect(result.status).toBe("applied");
    expect((await saved(file)).assignments.map(a => a.visitId)).toEqual(ids);
  }, state);
});
test("queued input is a snapshot, not mutable caller-owned rows", () => fixture(async file => {
  const rows = [row("original")];
  const applying = importRoutes(file, "a", "u", rows, true);
  rows[0]!.visitId = "changed"; rows.push(row("extra"));
  expect((await applying).assignments.map(a => a.visitId)).toEqual(["original"]);
  expect((await importRoutes(file, "a", "u", [row("original")], true)).status).toBe("replay");
}));
test("empty batches bind an upload only on apply", () => fixture(async file => {
  const before = await bytes(file);
  expect((await importRoutes(file, "a", "empty", [], false)).status).toBe("preview");
  expect(await bytes(file)).toBe(before);
  expect((await importRoutes(file, "a", "empty", [], true)).status).toBe("applied");
  expect((await importRoutes(file, "a", "empty", [], true)).status).toBe("replay");
  expect((await importRoutes(file, "a", "empty", [row("1")], true)).status).toBe("rejected");
}));
test("replay receipt survives a new Bun process", () => fixture(async file => {
  const rows = [row("1")];
  const first = await importRoutes(file, "a", "u", rows, true);
  const before = await bytes(file);
  const source = `import { importRoutes } from ${JSON.stringify(join(import.meta.dir, "src/importer.ts"))};
    console.log(JSON.stringify(await importRoutes(${JSON.stringify(file)}, "a", "u", ${JSON.stringify(rows)}, true)));`;
  const child = Bun.spawn([process.execPath, "--eval", source], { stdout: "pipe", stderr: "pipe" });
  const output = await new Response(child.stdout).text();
  const diagnostic = await new Response(child.stderr).text();
  expect(await child.exited).toBe(0);
  expect(diagnostic).toBe("");
  expect(JSON.parse(output)).toEqual({ ...first, status: "replay" });
  expect(await bytes(file)).toBe(before);
}));
test("rename failure preserves bytes, removes temporary file and releases queue for retry", () => fixture(async file => {
  const before = await bytes(file);
  const contents = await fs.readdir(join(file, ".."));
  const rename = spyOn(fs, "rename").mockRejectedValueOnce(new Error("injected rename failure"));
  try {
    const result = await importRoutes(file, "a", "u", [row("1")], true);
    expect(result.status).toBe("rejected");
    expect(result.errors.join(" ")).toContain("injected rename failure");
    expect(result.assignments).toEqual([]);
    expect(await bytes(file)).toBe(before);
    expect(await fs.readdir(join(file, ".."))).toEqual(contents);
  } finally { rename.mockRestore(); }
  expect((await importRoutes(file, "a", "u", [row("1")], true)).status).toBe("applied");
  expect((await importRoutes(file, "a", "u", [row("1")], true)).status).toBe("replay");
}));
test("corrupt state fails closed; repair permits a subsequent transaction", () => fixture(async file => {
  const original = await bytes(file);
  for (const corrupt of ["{", "null", JSON.stringify({ ...base(), assignments: null }),
    JSON.stringify({ ...base(), uploads: [] })]) {
    await writeFile(file, corrupt);
    const result = await importRoutes(file, "a", "u", [row("1")], true);
    expect(result.status).toBe("rejected");
    expect(result.errors.length).toBeGreaterThan(0);
    expect(await bytes(file)).toBe(corrupt);
  }
  await writeFile(file, original);
  expect((await importRoutes(file, "a", "u", [row("1")], true)).status).toBe("applied");
}));
test("conflicting legacy state is rejected without silently migrating it", () => {
  const state = base();
  state.assignments.push({ tenant: "a", visitId: "1", crewId: "001" }, { tenant: "a", visitId: "1", crewId: "other" });
  return fixture(async file => {
    const before = await bytes(file);
    expect((await importRoutes(file, "a", "u", [row("2")], true)).status).toBe("rejected");
    expect(await bytes(file)).toBe(before);
  }, state);
});
