# Local importer implementation and validation

## Scope and decisions

Single agent, frozen NEXUS build procedure, Bun 1.4.2. The workspace has no
`.git`; the original importer is retained in `before/importer.ts` and compared
in `importer.diff`. No README or separate contract exists in the file inventory.
Sources read: AGENTS.md, src/importer.ts, legacy/screen.ts,
docs/operator-guide.md, importer.test.ts and the existing investigation.
No legacy, public test, guide, investigation, or method source was modified.
`preserved.sha256` verifies the seven original project/evidence files.

The supplied synthetic owner packet resolves the investigation's batch,
identity/retry and assignment-conflict questions:

- Reject any invalid batch atomically, with visible errors and no returned additions.
- Identity is the tuple (tenant, uploadId). Ordered Row field pairs are persisted
  exactly, including duplicates. Identical retries return replay and the original
  additions; changed ordered rows reject without writes. Extra JSON properties do
  not change Row identity. Receipt and assignments commit in the same JSON image.
- Assignment to another crew, including within a batch, rejects the batch.
- Preview and rejection do not bind an upload ID. Successful apply, including an
  empty/no-op batch, binds it. Preview consults an existing receipt without writing.

The owner packet does not introduce a visit-ID grammar. The implementation uses
existing exported `Row` string types: no numeric coercion, trimming, digit-only
restriction or normalization. Numeric JSON cells reject as malformed. This is a
boundary implementation of the existing API, not a claim of a new owner preference
about spreadsheet parsing. CSV/XLSX ingestion is outside this consumer.

Existing rules retained: tenant-scoped crew lookup and visit uniqueness; opaque
IDs; inactive crews cannot receive new visits; same-crew assignments are no-ops;
capacity counts distinct visits; apply rechecks current state after preview.

## Transaction and failure boundaries

The writer is importRoutes in a single Bun process. Canonical paths (realpath,
including symlink aliases) share a promise queue across the full read/evaluate/
commit sequence. Rejected or failed operations release the queue. Input is copied
before the first await. Different canonical files have separate queues.

The publication point is a same-directory rename of an exclusively created,
written and fsynced temporary file. The receipt and additions are published
atomically. A pre-rename failure leaves the original bytes intact; temporary file
cleanup is attempted. Invalid/corrupt state fails closed without migration.
The existing JSON state schema and exported screen API remain compatible;
previously unused `uploads` now stores versioned receipts under encoded tuple keys.

No multiprocess/external-writer coordination or hard-link alias coordination is
provided. No directory fsync or power-loss durability guarantee is claimed. A
process killed before rename may leave an orphan temporary file; no automatic
orphan recovery is implemented. Actual disk exhaustion, permission failure,
process interruption and power loss were not injected.

## Observed checks

- Baseline public test: 1 pass, 3 assertions.
- Regression suite against original implementation: 1 pass, 21 fail, 27 assertions
  (`red.log`). This reproduced critical invalid-input, tenant, capacity,
  atomicity, replay, conflict and concurrent-update failures before the fix.
- Final `bun test`: 31 pass, 0 fail, 207 assertions (`green.log`), including the
  unchanged public test and 30 added cases.
- 30 concurrent distinct uploads: every result applied; 30 unique visits and
  30 upload receipts persisted.
- 12 identical concurrent requests through real and symlink paths: one applied,
  eleven replayed. Contention for the final capacity slot: one applied, two rejected.
- Concurrent changed rows under one identity: one applied, one rejected.
- Replay from a newly spawned local Bun process used the persisted receipt and
  left file bytes unchanged. This is sequential persistence validation, not a
  claim of multiprocess write safety.
- Injected rename rejection: rejected with visible error, original bytes intact,
  no remaining temporary file; subsequent same-ID retry applied then replayed.
- Corrupt JSON/schema and conflicting legacy assignments rejected without mutation;
  repairing corrupt state allowed the next transaction.
- Original source/evidence checksums: all seven OK after the final source edit.

## Performance and remaining gates

Indexed domain evaluation is O(crews + assignments + rows), rather than repeated
crew/assignment scans. Parsing/serialization and receipt storage remain proportional
to total state size. The file transaction serializes all its tenants and includes
fsync latency; receipt history grows with accepted uploads. No pruning is performed
because it would weaken indefinite replay behavior. No representative-size latency
or throughput benchmark or target was supplied or measured. The test suite's run
time is not a production performance measurement. Bun executes TypeScript; no separate static type check was run and no
dependencies were installed.

Local self-inspection covered API compatibility, tenant/input boundaries, atomic
publication, retry identity, capacity, queue lifecycle and index complexity.
Independent review is **pending/unavailable**, not approved: this experiment
explicitly forbids delegation and additional chats. The frozen NEXUS minimum says:
"Migração persistente, difícil reversão ou risco material exige DEEP e review
independente antes da conclusão; indisponibilidade mantém esse gate pendente."
See the selected method's `references/invocation.md`. Local implementation and
validation are delivered; this report does not claim that the independent-review
gate is closed.
