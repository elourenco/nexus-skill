import * as fs from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";

export type Row = { visitId: string; crewId: string };
export type State = {
  crews: { tenant: string; id: string; status: "active" | "paused" | "archived"; capacity: number }[];
  assignments: { tenant: string; visitId: string; crewId: string }[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: "applied" | "preview" | "replay" | "rejected";
  assignments: State["assignments"];
  errors: string[];
};
type Receipt = { version: 1; fingerprint: string; assignments: State["assignments"] };
const pending = new Map<string, Promise<void>>();
const rejected = (...errors: string[]): Result => ({ status: "rejected", assignments: [], errors });
const object = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === "object" && !Array.isArray(value);
const isRow = (value: unknown): value is Row =>
  object(value) && typeof value.visitId === "string" && typeof value.crewId === "string";
const isAssignment = (value: unknown): value is State["assignments"][number] =>
  isRow(value) && typeof (value as Record<string, unknown>).tenant === "string";

function isState(value: unknown): value is State {
  return object(value) && Array.isArray(value.crews) && value.crews.every(c =>
    object(c) && typeof c.tenant === "string" && typeof c.id === "string" &&
    ["active", "paused", "archived"].includes(c.status as string) &&
    typeof c.capacity === "number" && Number.isSafeInteger(c.capacity) && c.capacity >= 0
  ) && Array.isArray(value.assignments) && value.assignments.every(isAssignment) &&
    object(value.uploads);
}

// One process, one transaction per canonical file. Queue failures do not poison
// subsequent imports; entries are released when the last waiting call finishes.
async function serialized<T>(file: string, operation: () => Promise<T>): Promise<T> {
  const previous = pending.get(file) ?? Promise.resolve();
  const result = previous.then(operation);
  const tail = result.then(() => {}, () => {});
  pending.set(file, tail);
  try { return await result; }
  finally { if (pending.get(file) === tail) pending.delete(file); }
}

async function replaceState(file: string, state: State): Promise<void> {
  const temporary = join(dirname(file), `.routes-${randomUUID()}.tmp`);
  const metadata = await fs.stat(file);
  const handle = await fs.open(temporary, "wx", metadata.mode & 0o777);
  try {
    await handle.writeFile(JSON.stringify(state), "utf8");
    await handle.sync();
    await handle.close();
    // Same-directory rename publishes assignments and receipt together. This is
    // atomic publication, not a guarantee of directory durability after power loss.
    await fs.rename(temporary, file);
  } finally {
    await handle.close().catch(() => {});
    await fs.rm(temporary, { force: true }).catch(() => {});
  }
}

async function evaluate(
  file: string, tenant: string, uploadId: string, rows: Row[], apply: boolean,
): Promise<Result> {
  const parsed: unknown = JSON.parse(await fs.readFile(file, "utf8"));
  if (!isState(parsed)) return rejected("Invalid state file; no changes made");
  const state = parsed;
  // Tuple encoding avoids delimiter collisions and object prototype keys.
  const key = JSON.stringify([tenant, uploadId]);
  const fingerprint = JSON.stringify(rows.map(row => [row.visitId, row.crewId]));
  if (Object.hasOwn(state.uploads, key)) {
    const receipt = state.uploads[key];
    if (!object(receipt) || receipt.version !== 1 || typeof receipt.fingerprint !== "string" ||
      !Array.isArray(receipt.assignments) || !receipt.assignments.every(isAssignment) ||
      receipt.assignments.some(a => a.tenant !== tenant)) {
      return rejected("Invalid upload receipt; no changes made");
    }
    if (receipt.fingerprint !== fingerprint) return rejected("Upload ID already used with different ordered rows");
    return { status: "replay", assignments: receipt.assignments, errors: [] };
  }

  const crews = new Map<string, State["crews"][number]>();
  for (const crew of state.crews) {
    if (crew.tenant !== tenant) continue;
    if (crews.has(crew.id)) return rejected("Ambiguous crew in state; no changes made");
    crews.set(crew.id, crew);
  }
  const assigned = new Map<string, string>();
  const visitsByCrew = new Map<string, Set<string>>();
  for (const assignment of state.assignments) {
    if (assignment.tenant !== tenant) continue;
    const existing = assigned.get(assignment.visitId);
    if (existing !== undefined && existing !== assignment.crewId) {
      return rejected("Conflicting assignments in state; no changes made");
    }
    assigned.set(assignment.visitId, assignment.crewId);
    let visits = visitsByCrew.get(assignment.crewId);
    if (!visits) { visits = new Set(); visitsByCrew.set(assignment.crewId, visits); }
    visits.add(assignment.visitId);
  }

  const additions: State["assignments"] = [];
  const errors: string[] = [];
  for (const [index, row] of rows.entries()) {
    const fail = (message: string) => errors.push(`Row ${index + 1}: ${message}`);
    const crew = crews.get(row.crewId);
    if (!crew) { fail("unknown crew for tenant"); continue; }
    const existing = assigned.get(row.visitId);
    if (existing !== undefined) {
      if (existing !== row.crewId) fail("visit is assigned to another crew");
      // An existing same-crew assignment needs no new capacity, even if paused.
      continue;
    }
    if (crew.status !== "active") { fail("crew is not active"); continue; }
    let visits = visitsByCrew.get(crew.id);
    if (!visits) { visits = new Set(); visitsByCrew.set(crew.id, visits); }
    if (visits.size >= crew.capacity) { fail("crew capacity exceeded"); continue; }
    assigned.set(row.visitId, crew.id);
    visits.add(row.visitId);
    additions.push({ tenant, visitId: row.visitId, crewId: crew.id });
  }
  if (errors.length) return rejected(...errors);
  if (!apply) return { status: "preview", assignments: additions, errors: [] };

  const receipt: Receipt = { version: 1, fingerprint, assignments: additions };
  state.assignments.push(...additions);
  state.uploads[key] = receipt;
  await replaceState(file, state);
  return { status: "applied", assignments: additions, errors: [] };
}

// Existing API: state file already exists. rows is untrusted JSON; malformed input
// returns rejected. IDs follow the public Row string contract, preserved verbatim.
// Files are shared only by importer calls in a single Bun process.
export async function importRoutes(
  file: string, tenant: string, uploadId: string, rows: unknown, apply: boolean,
): Promise<Result> {
  if (typeof tenant !== "string" || typeof uploadId !== "string" || typeof apply !== "boolean") {
    return rejected("Invalid tenant, upload ID or apply flag");
  }
  if (!Array.isArray(rows)) return rejected("Rows must be an array");
  const input: Row[] = [];
  const errors: string[] = [];
  // Snapshot before awaiting: later caller mutations cannot change a queued batch.
  for (let i = 0; i < rows.length; i++) {
    const row: unknown = rows[i];
    if (!isRow(row)) errors.push(`Row ${i + 1}: visitId and crewId must be strings`);
    else input.push({ visitId: row.visitId, crewId: row.crewId });
  }
  if (errors.length) return rejected(...errors);
  try {
    const canonical = await fs.realpath(file);
    return await serialized(canonical, () => evaluate(canonical, tenant, uploadId, input, apply));
  } catch (error) {
    return rejected(`State operation failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
