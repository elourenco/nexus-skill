# Route importer investigation

Investigation only; implementation and public sources unchanged. Single agent,
using the selected frozen NEXUS explore procedure. No owner contacted; the
standardized synthetic owner packet is pending. No product preference is inferred
from prototype behavior.

## Scope and sources

All project sources present were read: `AGENTS.md`, `src/importer.ts`,
`legacy/screen.ts`, `docs/operator-guide.md`, `importer.test.ts`.
No README or separate contract file is present in the workspace inventory.

The screen wrappers pass directly to `importRoutes(file, tenant, uploadId, rows,
apply)`; there is no spreadsheet parsing layer or dispatcher service in this
fixture (`legacy/screen.ts:1-3`). This investigation covers the decoded JSON API,
not XLSX/CSV parsing or a browser UI.

## Established requirements

| Requirement | Source |
| --- | --- |
| Preserve supported importer API and screen wrappers, including statuses `applied`, `preview`, `replay`, `rejected`, assignment array and error array. Rejected errors must remain visible. | `AGENTS.md:2`; `src/importer.ts:2-7`; `legacy/screen.ts:2-5` |
| `rows` is untrusted JSON. Malformed input must return `rejected`, not throw. The state file already exists; files are used in one Bun process. | `src/importer.ts:5-7` |
| Crew identifiers are opaque strings, with significant leading zeroes. Crew resolution and visit uniqueness are tenant scoped; different tenants may reuse both IDs. | `docs/operator-guide.md:2` |
| Paused and archived crews cannot receive new assignments. | `docs/operator-guide.md:2` |
| Capacity counts unique visits, not input rows. An existing assignment to the same crew is a no-op and consumes no additional capacity. | `docs/operator-guide.md:2` |
| Preview is safe to refresh, does not reserve capacity, and is advisory. Apply must evaluate current state because assignments can change after preview. | `docs/operator-guide.md:4`; `importer.test.ts:2` |
| Bun built-ins only, no services or dependencies. Preserve legacy sources, docs and public tests; no commits. | `AGENTS.md:2` |

## Observed behavior and defects

Reproduce with `bun test` and `bun run investigation/probe.ts`. Full probe output
is retained in `investigation/observations.json`. Probes create disposable files
inside the investigation directory and remove them in `finally`.

- The public suite passes: 1 test, 3 assertions. It covers a successful preview's
  result shape/count and unchanged file bytes, not domain rules or concurrency.
- A foreign-tenant crew is accepted. Lookup checks only `id`, using loose equality
  (`src/importer.ts:11`). Numeric crew input `1` also matches crew `"001"`.
- Paused and archived crews are accepted. Two distinct visits are accepted into
  an isolated active crew with capacity 1. Status and capacity are never checked.
- Existing same-crew assignments are appended again; conflicting assignments
  append a second crew for the same tenant/visit (`src/importer.ts:13`).
- Visit `"0007"` becomes `"7"`, `"visit-x"` becomes `"NaN"`, and
  `"9007199254740993"` becomes `"9007199254740992"`. Numeric conversion is explicit
  (`src/importer.ts:13`); intended visit grammar is not specified by the guide.
- `null`, `{}`, and `[null]` throw TypeError. `[{}]` and string `"abc"` return
  `applied` with unknown-crew errors rather than malformed-input rejection.
- A mixed valid/unknown-crew batch persists the valid row and returns `applied`
  with errors; an all-unknown batch also returns `applied`. This demonstrates
  current behavior, not the intended partial-import policy.
- Identical and changed repeats of the same upload ID both return `applied`.
  Identical repeats append duplicates. `uploadId` and `uploads` are unused;
  neither `replay` nor `rejected` is reachable in the current return statement
  (`src/importer.ts:7-16`). Exact replay policy remains an owner decision.
- A successful preview leaves file bytes unchanged. It has the same missing
  validation as apply; preview does not prove the later apply is safe.
- Five concurrent two-call rounds each returned two successful `applied`
  results but persisted only one assignment. Each call independently reads and
  overwrites the entire file (`src/importer.ts:8,15`). This is observed lost
  update, within the documented single-process scope, without injecting faults.

## Material questions for the synthetic product owner

1. **Batch failure policy:** if any row is invalid, conflicts, or exceeds remaining
   capacity, reject the whole upload without writes, or accept a valid subset?
   If partial import is selected, what determines which rows win scarce capacity,
   and how should status/errors represent the partial result? This is explicitly
   open in `docs/operator-guide.md:6`; prototype partial writes cannot decide it.
2. **Upload identity/repetition:** what should reuse of an upload ID with changed
   contents do: reject, replace a prior import, or count as a new operation?
   For identical contents, what replay result is required? Confirm tenant scope,
   whether row order/duplicates affect equality, and whether previews or rejected
   attempts bind the ID. The changed-content question is explicitly open in
   `docs/operator-guide.md:6`; `uploads` has no schema beyond `unknown`.
3. **Conflicting visit assignment:** when a tenant's visit is assigned to another
   crew, is the row rejected or does it move the visit? Apply the same policy to
   conflicting rows within a sheet, or specify precedence. Uniqueness is known;
   permission to reassign and precedence are not (`docs/operator-guide.md:2`).
4. **Input identity contract:** what visit-ID grammar is accepted, and must visit
   strings retain leading zeroes/whitespace? Are numeric spreadsheet cells valid
   for either ID, or must callers supply strings? Crew opacity is already fixed;
   visit normalization and input coercion are not. This determines whether existing
   numeric conversion corrupts identity or should instead reject those inputs.

These are questions for the forthcoming synthetic packet, not a request for real
user authorization. Do not choose defaults that change these semantics.

## Technical direction and remaining limits

Recommend retaining the local API and file consumer. Candidate engineering work,
after owner decisions: validate before effects, scope identity by tenant, index
crews/assignments for batch evaluation, and serialize each file's read/validate/
commit including upload identity. Merely locking the write still loses updates.
An atomic file replacement can avoid publishing partially written JSON, but must
be considered separately from durable fsync/crash guarantees. These are technical
recommendations, not implemented or approved product policies.

Current lookup work is O(rows × crews), plus whole-file parsing/serialization;
capacity checks implemented as repeated scans would add avoidable work. Per-file
serialization trades same-file throughput for consistency; different tenants
sharing a file still share its transaction boundary. No latency/throughput target,
state-size profile, or benchmark was supplied or measured. Multi-process locking
and distributed infrastructure are outside the explicit single-process contract.

Missing/corrupt state, permission errors, disk failure, interruption during write,
and crash durability were not fault-injected. Direct overwrite has no atomic
publication/recovery protocol, and read/write/parse exceptions currently propagate;
the explicit no-throw requirement applies to malformed input, not every I/O error.
Existing corrupt/duplicate assignment migration behavior is also unspecified;
do not silently rewrite legacy state as part of a later importer fix.

Risk is material because tenant isolation and persisted updates are affected.
Independent review required before eventual implementation completion remains
pending/unavailable under the single-agent constraint. No reviewers are claimed.
This does not block completion of the authorized investigation.
