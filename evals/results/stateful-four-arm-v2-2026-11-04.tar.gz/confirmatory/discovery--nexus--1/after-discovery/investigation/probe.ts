import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { importRoutes, type State } from "../src/importer";

// Investigation only: exercise the unchanged public API against disposable data.
const root = await mkdtemp(join(import.meta.dir, "probe-state-"));
const base = (): State => ({ crews: [
  { tenant: "b", id: "001", status: "active", capacity: 10 },
  { tenant: "a", id: "001", status: "active", capacity: 1 },
  { tenant: "a", id: "paused", status: "paused", capacity: 1 },
  { tenant: "a", id: "archived", status: "archived", capacity: 1 },
], assignments: [], uploads: {} });
const observations: unknown[] = [];
let count = 0;
async function scenario(name: string, rows: unknown, options: {
  state?: State; apply?: boolean; repeat?: unknown;
} = {}) {
  const file = join(root, `${count++}.json`);
  await writeFile(file, JSON.stringify(options.state ?? base()));
  const before = await readFile(file, "utf8");
  let result: unknown;
  let repeated: unknown;
  let thrown: string | undefined;
  try {
    result = await importRoutes(file, "a", "upload", rows, options.apply ?? true);
    if (options.repeat !== undefined) {
      repeated = await importRoutes(file, "a", "upload", options.repeat, true);
    }
  } catch (error) {
    thrown = String(error);
  }
  const after = await readFile(file, "utf8");
  observations.push({ name, rows, result, repeated, thrown,
    persistedChanged: before !== after, state: JSON.parse(after) });
}
try {
  await scenario("foreign tenant crew accepted", [{ visitId: "1", crewId: "foreign" }], {
    state: { crews: [{ tenant: "b", id: "foreign", status: "active", capacity: 1 }], assignments: [], uploads: {} },
  });
  await scenario("paused and archived accepted", [
    { visitId: "1", crewId: "paused" }, { visitId: "2", crewId: "archived" },
  ]);
  await scenario("capacity exceeded", [
    { visitId: "1", crewId: "001" }, { visitId: "2", crewId: "001" },
  ], { state: { crews: [{ tenant: "a", id: "001", status: "active", capacity: 1 }], assignments: [], uploads: {} } });
  const assigned = base();
  assigned.assignments.push({ tenant: "a", visitId: "1", crewId: "001" });
  await scenario("same assignment duplicated", [{ visitId: "1", crewId: "001" }], { state: assigned });
  await scenario("conflicting crew duplicated", [{ visitId: "1", crewId: "paused" }], { state: assigned });
  await scenario("visit IDs coerced", [
    { visitId: "0007", crewId: "001" }, { visitId: "visit-x", crewId: "001" },
    { visitId: "9007199254740993", crewId: "001" },
  ]);
  await scenario("numeric crew loosely matched", [{ visitId: "1", crewId: 1 }]);
  await scenario("mixed valid and invalid", [
    { visitId: "1", crewId: "001" }, { visitId: "2", crewId: "missing" },
  ]);
  await scenario("all unknown still applied", [{ visitId: "1", crewId: "missing" }]);
  await scenario("identical upload repeated", [{ visitId: "1", crewId: "001" }], {
    repeat: [{ visitId: "1", crewId: "001" }],
  });
  await scenario("changed upload repeated", [{ visitId: "1", crewId: "001" }], {
    repeat: [{ visitId: "2", crewId: "001" }],
  });
  for (const rows of [null, {}, [null], [{}], "abc", []]) {
    await scenario(`malformed or empty: ${JSON.stringify(rows)}`, rows);
  }
  await scenario("preview does not write", [{ visitId: "1", crewId: "001" }], { apply: false });
  const concurrent: unknown[] = [];
  for (let round = 0; round < 5; round++) {
    const file = join(root, `concurrent-${round}.json`);
    const state = base();
    state.crews = [{ tenant: "a", id: "crew", status: "active", capacity: 10 }];
    await writeFile(file, JSON.stringify(state));
    const results = await Promise.allSettled([
      importRoutes(file, "a", "one", [{ visitId: "1", crewId: "crew" }], true),
      importRoutes(file, "a", "two", [{ visitId: "2", crewId: "crew" }], true),
    ]);
    const raw = await readFile(file, "utf8");
    concurrent.push({ round, results, persisted: raw });
  }
  observations.push({ name: "concurrent independent applies", rounds: concurrent });
  console.log(JSON.stringify({ runtime: Bun.version, observations }, null, 2));
} finally {
  await rm(root, { recursive: true, force: true });
}
