import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

test("preserves opaque IDs, signed safe cents, whitespace and CRLF", () => {
  const rows = parseLedger('\n  \r\n{"tenant":"b","visitId":"0042","cents":-50}\r\n{"tenant":"a","visitId":" 001 ","cents":9007199254740991}\n{"tenant":"a","visitId":"x","cents":-9007199254740991}\n');
  expect(rows).toEqual([
    { tenant: "b", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: " 001 ", cents: Number.MAX_SAFE_INTEGER },
    { tenant: "a", visitId: "x", cents: Number.MIN_SAFE_INTEGER },
  ]);
  expect(parseLedger(" \n\r\n")).toEqual([]);
});

test("accepts a document-leading BOM", () => {
  expect(parseLedger('\ufeff{"tenant":"a","visitId":"0042","cents":0}\n')).toEqual([
    { tenant: "a", visitId: "0042", cents: 0 },
  ]);
});

test("rejects malformed lines and invalid entry types without skipping", () => {
  const invalid = [
    "{", "null", "[]", "42", '"text"', "true", "{}",
    '{"tenant":7,"visitId":"v","cents":1}',
    '{"tenant":"a","visitId":42,"cents":1}',
    '{"tenant":"a","visitId":"v","cents":"1"}',
    '{"tenant":"a","visitId":"v","cents":null}',
    '{"tenant":"a","visitId":"v","cents":1.5}',
    '{"tenant":"a","visitId":"v","cents":9007199254740992}',
    '{"tenant":"a","visitId":"v","cents":-9007199254740992}',
    '{"tenant":"a","visitId":"v","cents":1e999}',
  ];
  for (const line of invalid) {
    expect(() => parseLedger('\n{"tenant":"ok","visitId":"v","cents":1}\n' + line)).toThrow(/line 3/i);
  }
});
