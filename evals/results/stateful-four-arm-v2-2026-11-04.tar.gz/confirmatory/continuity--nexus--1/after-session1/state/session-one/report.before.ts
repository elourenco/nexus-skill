export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text:string):Entry[]{return text.trim().split("\n").filter(Boolean).map(line=>JSON.parse(line))}
export function renderSummary(entries:Entry[]):string{throw new Error("pending output format decision")}
