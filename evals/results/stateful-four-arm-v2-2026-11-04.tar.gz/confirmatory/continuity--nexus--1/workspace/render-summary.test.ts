import { expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { parseLedger, renderSummary } from "./src/report";

test("renders the persisted ledger as sorted NDJSON without extra rows", () => {
  expect(renderSummary(parseLedger(readFileSync("state/ledger.ndjson", "utf8"))))
    .toBe('{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
});

test("counts opaque visits within tenants and sums every adjustment", () => {
  const entries = [
    { tenant: "b", visitId: "0042", cents: 100 },
    { tenant: "a", visitId: "0042", cents: 50 },
    { tenant: "b", visitId: "0042", cents: -120 },
    { tenant: "a", visitId: "42", cents: -75 },
    { tenant: "a", visitId: " 0042 ", cents: 0 },
  ];
  const before = structuredClone(entries);
  expect(renderSummary(entries)).toBe(
    '{"tenant":"a","visits":3,"cents":-25}\n{"tenant":"b","visits":1,"cents":-20}',
  );
  expect(entries).toEqual(before);
  expect(renderSummary([...entries].reverse())).toBe(renderSummary(entries));
});

test("handles empty input, special tenant names and JSON escaping", () => {
  expect(renderSummary([])).toBe("");
  const tenants = ["__proto__", "constructor", "", 'line\n"quote', "A"];
  const result = renderSummary(tenants.map(tenant => ({ tenant, visitId: "", cents: 0 })));
  expect(result.split("\n").map(line => JSON.parse(line))).toEqual([
    { tenant: "", visits: 1, cents: 0 },
    { tenant: "A", visits: 1, cents: 0 },
    { tenant: "__proto__", visits: 1, cents: 0 },
    { tenant: "constructor", visits: 1, cents: 0 },
    { tenant: 'line\n"quote', visits: 1, cents: 0 },
  ]);
});

test("keeps totals exact across large cancelling adjustments and rejects unsafe totals", () => {
  const entry = (cents: number) => ({ tenant: "a", visitId: "v", cents });
  expect(renderSummary([entry(Number.MAX_SAFE_INTEGER), entry(2), entry(-2)]))
    .toBe('{"tenant":"a","visits":1,"cents":9007199254740991}');
  expect(() => renderSummary([entry(Number.MAX_SAFE_INTEGER), entry(1)])).toThrow(/safe integer/i);
  expect(() => renderSummary([entry(Number.MIN_SAFE_INTEGER), entry(-1)])).toThrow(/safe integer/i);
});
