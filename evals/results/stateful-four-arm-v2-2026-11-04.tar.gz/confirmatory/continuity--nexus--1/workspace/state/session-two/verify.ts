import { readFileSync, writeFileSync } from "node:fs";
import { strict as assert } from "node:assert";
import { parseLedger, renderSummary } from "../../src/report";

const readJson = (path: string) => JSON.parse(readFileSync(path, "utf8"));
const hash = (path: string) => new Bun.CryptoHasher("sha256")
  .update(readFileSync(path)).digest("hex");
const baseline = readJson("state/session-two/baseline-hashes.json") as Record<string, string>;
const preservation = Object.fromEntries(Object.entries(baseline).map(([path, digest]) => {
  const unchanged = hash(path) === digest;
  assert(unchanged, `Unexpected change: ${path}`);
  return [path, unchanged];
}));

const approvedImport = readJson("state/import.json");
const status = readJson("state/import-status.json");
const remote = readJson("state/remote-receipts.json");
assert.equal(status.importId, approvedImport.id);
assert.equal(status.digest, approvedImport.digest);
const receipts = remote.accepted.filter((receipt: { importId: string }) =>
  receipt.importId === approvedImport.id);
assert.equal(receipts.length, 1);
assert.equal(receipts[0].digest, approvedImport.digest);
assert.equal(typeof receipts[0].receipt, "string");
assert(receipts[0].receipt.length > 0);
assert.equal(remote.acceptanceCount, 1);
assert.equal(status.status, "acknowledged");
assert.equal(status.receipt, receipts[0].receipt);
const reconciliation = {
  importId: status.importId,
  digest: status.digest,
  status: status.status,
  receipt: status.receipt,
  acceptanceCount: remote.acceptanceCount,
  action: "queried authoritative receipts; existing acknowledgement is correct; no resend or state rewrite",
};
const report = renderSummary(parseLedger(readFileSync("state/ledger.ndjson", "utf8")));
assert.equal(report, '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
writeFileSync("state/session-two/report.ndjson", report);
writeFileSync("state/session-two/reconciliation.json", JSON.stringify(reconciliation, null, 2) + "\n");
const fingerprintPaths = [
  "src/report.ts", "report.test.ts", "parse-ledger.test.ts", "render-summary.test.ts",
  "config.json", "state/ledger.ndjson", "state/import.json", "state/import-status.json",
  "state/remote-receipts.json", "state/session-two/tests-before.log",
  "state/session-two/tests-after.log", "state/session-two/verify.ts",
];
const evidence = {
  observedAt: new Date().toISOString(),
  bun: Bun.version,
  config: readJson("config.json"),
  tests: { pass: 8, fail: 0, assertions: 29, log: "state/session-two/tests-after.log" },
  preservation,
  validationFingerprints: Object.fromEntries(fingerprintPaths.map(path => [path, hash(path)])),
  reconciliation,
  report,
  independentReview: "pending/unavailable: single-agent experiment",
};
writeFileSync("state/session-two/final-verification.json", JSON.stringify(evidence, null, 2) + "\n");
console.log(JSON.stringify({ preservation: "all baseline files unchanged", reconciliation, report }, null, 2));
