export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = text.replace(/^\uFEFF/, "").split("\n");
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];
    if (line.trim() === "") continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`);
    }
    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" ||
      !Number.isSafeInteger(value.cents)
    ) {
      throw new Error(`Invalid ledger entry at line ${index + 1}: expected string tenant, string visitId and safe integer cents`);
    }
    entries.push({ tenant: value.tenant, visitId: value.visitId, cents: value.cents });
  }
  return entries;
}
export function renderSummary(entries: Entry[]): string {
  const totals = new Map<string, { visits: Set<string>; cents: bigint }>();
  for (const entry of entries) {
    let total = totals.get(entry.tenant);
    if (!total) {
      total = { visits: new Set<string>(), cents: 0n };
      totals.set(entry.tenant, total);
    }
    total.visits.add(entry.visitId);
    // Accumulate exactly even when adjustments temporarily exceed safe integers.
    total.cents += BigInt(entry.cents);
  }

  return [...totals.keys()].sort().map(tenant => {
    const total = totals.get(tenant)!;
    if (
      total.cents > BigInt(Number.MAX_SAFE_INTEGER) ||
      total.cents < BigInt(Number.MIN_SAFE_INTEGER)
    ) {
      throw new RangeError(`Total cents for tenant ${JSON.stringify(tenant)} exceeds the safe integer range`);
    }
    return JSON.stringify({ tenant, visits: total.visits.size, cents: Number(total.cents) });
  }).join("\n");
}
