import { expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { parseLedger, renderSummary } from "./src/report";

test("renders the persisted ledger as sorted NDJSON with unique visits and all adjustments", () => {
  const entries = parseLedger(readFileSync("state/ledger.ndjson", "utf8"));
  const before = structuredClone(entries);
  expect(renderSummary(entries)).toBe(
    '{"tenant":"a","visits":1,"cents":200}\n' +
    '{"tenant":"b","visits":1,"cents":150}\n',
  );
  expect(entries).toEqual(before);
});

test("counts visits within each opaque tenant and escapes NDJSON strings", () => {
  const entries = [
    { tenant: "__proto__", visitId: "0042", cents: 10 },
    { tenant: "", visitId: "", cents: 0 },
    { tenant: "__proto__", visitId: "42", cents: 20 },
    { tenant: "__proto__", visitId: "0042", cents: -5 },
    { tenant: 'a\n"', visitId: "0042", cents: -50 },
    { tenant: "constructor", visitId: "0042", cents: 1 },
  ];
  const output = renderSummary(entries);
  expect(output.trimEnd().split("\n").map(line => JSON.parse(line))).toEqual([
    { tenant: "", visits: 1, cents: 0 },
    { tenant: "__proto__", visits: 2, cents: 25 },
    { tenant: 'a\n"', visits: 1, cents: -50 },
    { tenant: "constructor", visits: 1, cents: 1 },
  ]);
  expect(renderSummary([...entries].reverse())).toBe(output);
  expect(renderSummary([])).toBe("");
});

test("sums exactly through intermediate overflow and accepts safe final boundaries", () => {
  for (const boundary of [Number.MAX_SAFE_INTEGER, Number.MIN_SAFE_INTEGER]) {
    const entries = [boundary, boundary, -boundary].map(cents => ({
      tenant: "a", visitId: "same", cents,
    }));
    expect(JSON.parse(renderSummary(entries))).toEqual({ tenant: "a", visits: 1, cents: boundary });
  }
});

test("rejects unsafe final totals and invalid direct input amounts", () => {
  for (const boundary of [Number.MAX_SAFE_INTEGER, Number.MIN_SAFE_INTEGER]) {
    expect(() => renderSummary([boundary, Math.sign(boundary)].map(cents => ({
      tenant: "a", visitId: "1", cents,
    })))).toThrow('Summary cents exceed safe integer range for tenant "a"');
  }
  for (const cents of [0.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1]) {
    expect(() => renderSummary([{ tenant: "a", visitId: "1", cents }]))
      .toThrow('Invalid cents for tenant "a"');
  }
});
