export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = text.replace(/^\uFEFF/, "").split("\n");

  for (const [index, line] of lines.entries()) {
    if (line.trim() === "") continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`);
    }

    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" ||
      !Number.isSafeInteger(value.cents)
    ) {
      throw new Error(`Invalid ledger entry at line ${index + 1}`);
    }

    entries.push({ tenant: value.tenant, visitId: value.visitId, cents: value.cents });
  }

  return entries;
}
export function renderSummary(entries: Entry[]): string {
  const tenants = new Map<string, { visits: Set<string>; cents: bigint }>();

  for (const entry of entries) {
    if (!Number.isSafeInteger(entry.cents)) {
      throw new Error(`Invalid cents for tenant ${JSON.stringify(entry.tenant)}`);
    }
    let total = tenants.get(entry.tenant);
    if (!total) {
      total = { visits: new Set<string>(), cents: 0n };
      tenants.set(entry.tenant, total);
    }
    total.visits.add(entry.visitId);
    total.cents += BigInt(entry.cents);
  }

  const limit = BigInt(Number.MAX_SAFE_INTEGER);
  const lines = [...tenants.keys()].sort().map(tenant => {
    const total = tenants.get(tenant)!;
    if (total.cents < -limit || total.cents > limit) {
      throw new RangeError(`Summary cents exceed safe integer range for tenant ${JSON.stringify(tenant)}`);
    }
    return JSON.stringify({ tenant, visits: total.visits.size, cents: Number(total.cents) });
  });
  return lines.length === 0 ? "" : lines.join("\n") + "\n";
}
