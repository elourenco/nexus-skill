import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

test("preserves opaque IDs, duplicate visits, and signed integer cents", () => {
  const entries = [
    { tenant: "b", visitId: "001", cents: Number.MAX_SAFE_INTEGER },
    { tenant: "a", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: "0042", cents: Number.MIN_SAFE_INTEGER },
    { tenant: "", visitId: "", cents: 0 },
  ];
  expect(parseLedger(entries.map(entry => JSON.stringify(entry)).join("\n"))).toEqual(entries);
});

test("accepts initial BOM, CRLF, whitespace and empty input", () => {
  const entry = { tenant: "a", visitId: "0042", cents: 250 };
  expect(parseLedger(`\uFEFF\r\n \t\r\n${JSON.stringify(entry)}\r\n`)).toEqual([entry]);
  expect(parseLedger("")).toEqual([]);
  expect(parseLedger("\uFEFF \n\t\r\n")).toEqual([]);
});

test("rejects malformed JSON without skipping data and reports physical line", () => {
  expect(() => parseLedger('\n{"tenant":"a","visitId":"1","cents":0}\n{broken}\n'))
    .toThrow("Invalid ledger JSON at line 3");
});

test("rejects invalid shapes, field types, fractional and unsafe cents", () => {
  const invalid: unknown[] = [
    null, [], true, 1, "entry", {},
    { tenant: 1, visitId: "1", cents: 0 },
    { tenant: "a", visitId: 42, cents: 0 },
    { tenant: "a", visitId: "1", cents: "100" },
    { tenant: "a", visitId: "1", cents: null },
    { tenant: "a", visitId: "1" },
    { tenant: "a", cents: 0 },
    { visitId: "1", cents: 0 },
    { tenant: "a", visitId: "1", cents: 0.5 },
    { tenant: "a", visitId: "1", cents: Number.MAX_SAFE_INTEGER + 1 },
    { tenant: "a", visitId: "1", cents: Number.MIN_SAFE_INTEGER - 1 },
  ];
  for (const value of invalid) {
    expect(() => parseLedger(JSON.stringify(value))).toThrow("Invalid ledger entry at line 1");
  }
  expect(() => parseLedger('{"tenant":"a","visitId":"1","cents":1e400}'))
    .toThrow("Invalid ledger entry at line 1");
});
