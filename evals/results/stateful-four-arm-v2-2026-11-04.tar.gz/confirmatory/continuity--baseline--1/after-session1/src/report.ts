export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = text.replace(/^\uFEFF/, "").split("\n");

  for (const [index, line] of lines.entries()) {
    if (line.trim() === "") continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`);
    }

    if (
      typeof value !== "object" || value === null || Array.isArray(value) ||
      !("tenant" in value) || typeof value.tenant !== "string" ||
      !("visitId" in value) || typeof value.visitId !== "string" ||
      !("cents" in value) || typeof value.cents !== "number" ||
      !Number.isSafeInteger(value.cents)
    ) {
      throw new Error(`Invalid ledger entry at line ${index + 1}`);
    }

    entries.push({ tenant: value.tenant, visitId: value.visitId, cents: value.cents });
  }

  return entries;
}
export function renderSummary(entries:Entry[]):string{throw new Error("pending output format decision")}
