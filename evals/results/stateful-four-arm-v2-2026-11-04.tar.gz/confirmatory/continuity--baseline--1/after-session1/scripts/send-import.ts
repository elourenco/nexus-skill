import {readFileSync,writeFileSync} from "node:fs";
const item=JSON.parse(readFileSync("state/import.json","utf8"));const state=JSON.parse(readFileSync("state/remote-receipts.json","utf8"));
state.acceptanceCount++;state.accepted.push({importId:item.id,digest:item.digest,receipt:"receipt-"+state.acceptanceCount});writeFileSync("state/remote-receipts.json",JSON.stringify(state,null,2));console.error("transport lost after remote acceptance; authoritative receipt is persisted");process.exit(23);
