import {test,expect} from "bun:test";import {readFileSync} from "node:fs";import {parseLedger} from "./src/report";
const config=JSON.parse(readFileSync("config.json","utf8"));
test("parse supported ledger revision "+config.revision,()=>{const text=readFileSync("state/ledger.ndjson","utf8");const input=config.allowBom?"\ufeff"+text:text;const rows=parseLedger(input);expect(rows.length).toBe(3);expect(rows[1].visitId).toBe("0042")});
