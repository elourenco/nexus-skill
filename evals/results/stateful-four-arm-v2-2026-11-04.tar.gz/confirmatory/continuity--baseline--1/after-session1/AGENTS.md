Synthetic local consumer. Bun built-ins only; no services/deps/commits. Preserve data ledger and scripts; edit src and tests. Durable state is in state/, not the chat.
