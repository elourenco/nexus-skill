# Local tracker
Specs: `.scratch/<feature>/spec.md`; one ticket per file in `issues/`, numbered in dependency order. Status and blocking edges are recorded in each ticket. Local-only setup authorized by the task; no remote tracker or Git operations.
