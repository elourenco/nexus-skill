# Domain documentation
Single context. Read contract.md, any GLOSSARY.md and relevant docs/adr/ before implementation. Missing glossary/ADRs do not block work.
