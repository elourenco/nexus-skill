import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

test("rejects wrong record shapes and field types without returning partial data", () => {
  const valid = '{"tenant":"a","visitId":"0042","cents":-50}';
  for (const invalid of ["null", "[]", "42", '"entry"', "{}",
    '{"tenant":1,"visitId":"0042","cents":1}',
    '{"tenant":"a","visitId":42,"cents":1}',
    '{"tenant":"a","visitId":"0042","cents":"1"}']) {
    expect(() => parseLedger(valid + "\n" + invalid)).toThrow();
  }
});

test("rejects fractional, unsafe and nonfinite cents", () => {
  for (const cents of ["1.5", "9007199254740992", "-9007199254740992", "1e309"]) {
    expect(() => parseLedger(`{"tenant":"a","visitId":"x","cents":${cents}}`)).toThrow();
  }
});

test("preserves opaque IDs, ordering, adjustments and safe integer limits", () => {
  expect(parseLedger('\n  \n{"tenant":" b ","visitId":"0042","cents":-50}\r\n\n{"tenant":"a","visitId":"001","cents":9007199254740991}\n{"tenant":"a","visitId":"001","cents":-9007199254740991}\n')).toEqual([
    { tenant: " b ", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: "001", cents: 9007199254740991 },
    { tenant: "a", visitId: "001", cents: -9007199254740991 },
  ]);
  expect(parseLedger("")).toEqual([]);
});

test("rejects malformed JSON with the physical line number", () => {
  expect(() => parseLedger('\n{"tenant":"a","visitId":"x","cents":0}\n{')).toThrow("line 3");
});
