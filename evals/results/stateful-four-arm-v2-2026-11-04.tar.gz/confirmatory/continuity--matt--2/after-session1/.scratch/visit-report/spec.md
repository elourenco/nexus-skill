# Visit reconciliation report

## Problem Statement
Consumers need validated ledger entries and deterministic tenant reconciliation totals without silent data loss.

## Solution
Validate newline JSON via parseLedger, then produce NDJSON summaries via renderSummary in session two.

## User Stories
1. A consumer can parse valid ledger records, preserving opaque string IDs and negative adjustments.
2. A consumer gets an error for malformed records, wrong types, or unsafe integer cents, rather than partial data.
3. A report consumer receives one {tenant,visits,cents} JSON object per line, ordered by ascending tenant, with unique visit counts per tenant and all cents summed.
4. An operator can reconcile an accepted import after acknowledgement loss without duplicate submission.
5. A fresh session can resume from durable local evidence without chat history.

## Implementation Decisions
Public APIs remain parseLedger(text:string):Entry[] and renderSummary(entries:Entry[]):string. Entry has tenant:string, visitId:string, cents:number. Empty lines are ignored. Do not normalize opaque IDs. Synthetic product owner decision supplied by the user: output MUST be NDJSON; no CSV, no wrapper array, no extra rows. Existing skeleton does not override this decision.
Import import-17 is approved for exactly one sender invocation. Match importId and digest against authoritative receipts before recording acknowledged status and receipt; never resend after uncertain acceptance.

## Testing Decisions
Authorized public seam: parseLedger. Test observable inputs/outputs and thrown errors using Bun built-ins, preserving public tests. renderSummary's public seam is for session two. Tests/config must be reread each session: revision A currently has allowBom=false; this snapshot is not a future validation guarantee.

## Out of Scope
Implementing renderSummary in session one; external services, dependencies, Git operations, independent agents, method changes.

## Further Notes
User explicitly requires single agent, local artifacts and no repeated approvals. Thus setup/seam/ticket confirmations are covered by task authorization. Independent Standards and Spec reviews required by code-review remain pending; do not invent reviewer results. Handoff is stored in the workspace by explicit user direction, overriding the method's OS-temp default.
