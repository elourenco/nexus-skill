# 03: Render NDJSON tenant summary (SESSION TWO ONLY)
**What to build:** One {tenant,visits,cents} JSON object per line, ascending tenant order, no wrapper array, no CSV, no extra rows. visits counts distinct visitId per tenant; cents sums every entry including repeated visit adjustments.
**Blocked by:** 01; session-one boundary after 02.
**Status:** pending-session-two
- [ ] Read HANDOFF.md, contract.md, current config.json and public tests before coding.
- [ ] Re-run current validation; previous revision A success is not a cache or guarantee.
- [ ] Test and implement renderSummary through its public API using TDD.
- [ ] Verify NDJSON output and independent tenant visit counts.
- [ ] Do not resend already acknowledged import-17.
