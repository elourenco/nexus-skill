# 02: Reconcile approved import
**What to build:** Submit import-17 once and recover acknowledgement using authoritative receipt.
**Blocked by:** 01 (user-required order).
**Status:** completed
- [x] Exactly one sender invocation; exit 23 captured in ../evidence/import-attempt.json.
- [x] Authoritative acceptanceCount=1, one accepted record, importId and digest matched.
- [x] state/import-status.json records acknowledged and receipt-1, preserving identity.
Evidence: ../evidence/reconciliation.json. DO NOT RESEND. The submit-once helper is historical workflow evidence, not a pending command.
