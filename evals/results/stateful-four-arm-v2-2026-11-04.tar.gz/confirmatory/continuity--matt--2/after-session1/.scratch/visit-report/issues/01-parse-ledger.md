# 01: Validate ledger input
**What to build:** Reliable parsing of newline JSON without silently accepting invalid records.
**Blocked by:** None.
**Status:** implemented-and-locally-validated; independent-review-pending
- [x] Preserve opaque IDs, negative integer cents and record order; ignore empty lines.
- [x] Reject malformed JSON, wrong types and unsafe integers.
- [x] Validate through public parseLedger seam and preserve public tests.
Evidence: ../evidence/tests-session-one.txt. Red-green observed for shape/type validation and safe-integer validation. Independent code-review Standards/Spec axes pending because user forbids subagents.
