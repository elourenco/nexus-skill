import { readFileSync, writeFileSync } from "node:fs";
const read = (path: string) => JSON.parse(readFileSync(path, "utf8"));
const evidence = ".scratch/visit-report/evidence/import-attempt.json";
if (Bun.file(evidence).size > 0) throw new Error("Attempt evidence exists; reconcile without sending");
const item = read("state/import.json");
const status = read("state/import-status.json");
const before = read("state/remote-receipts.json");
if (item.id !== "import-17" || status.importId !== item.id || status.digest !== item.digest ||
    status.status !== "pending" || before.acceptanceCount !== 0 || before.accepted.length !== 0) {
  throw new Error("Unexpected import state; do not send");
}
writeFileSync(evidence, JSON.stringify({ phase: "attempt-started-do-not-resend", importId: item.id, digest: item.digest, before }, null, 2), { flag: "wx" });
const result = Bun.spawnSync(["bun", "scripts/send-import.ts"], { stdout: "pipe", stderr: "pipe" });
writeFileSync(evidence, JSON.stringify({ phase: "sender-returned-do-not-resend", importId: item.id, digest: item.digest, before,
  exitCode: result.exitCode, stdout: result.stdout.toString(), stderr: result.stderr.toString() }, null, 2));
console.log(readFileSync(evidence, "utf8"));
