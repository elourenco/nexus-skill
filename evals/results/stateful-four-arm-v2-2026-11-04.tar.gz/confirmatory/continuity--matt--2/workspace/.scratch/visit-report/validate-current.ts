import { strict as assert } from "node:assert";
import { readFileSync, writeFileSync } from "node:fs";
import { parseLedger, renderSummary } from "../../src/report";

const read = (path: string) => JSON.parse(readFileSync(path, "utf8"));
const item = read("state/import.json");
const local = read("state/import-status.json");
const remote = read("state/remote-receipts.json");
const matches = remote.accepted.filter((receipt: { importId: string; digest: string }) =>
  receipt.importId === item.id && receipt.digest === item.digest);
assert.equal(remote.acceptanceCount, 1);
assert.equal(remote.accepted.length, 1);
assert.equal(matches.length, 1);
assert.equal(typeof matches[0].receipt, "string");
assert.equal(local.importId, item.id);
assert.equal(local.digest, item.digest);
assert.equal(local.status, "acknowledged");
assert.equal(local.receipt, matches[0].receipt);

writeFileSync(".scratch/visit-report/evidence/reconciliation-session-two.json", JSON.stringify({
  import: item, authoritativeRemote: remote, localStatus: local,
  identityMatched: true, senderInvokedThisSession: false, stateWriteNeeded: false,
}, null, 2) + "\n");
const output = renderSummary(parseLedger(readFileSync("state/ledger.ndjson", "utf8")));
assert.equal(output, '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}');
writeFileSync(".scratch/visit-report/evidence/summary.ndjson", output);
console.log(output);
console.log("Import identity and receipt matched; acceptanceCount=1; acknowledged; no resend.");
