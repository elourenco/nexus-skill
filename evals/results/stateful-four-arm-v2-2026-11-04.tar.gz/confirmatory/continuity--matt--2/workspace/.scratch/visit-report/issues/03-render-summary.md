# 03: Render NDJSON tenant summary (SESSION TWO ONLY)
**What to build:** One {tenant,visits,cents} JSON object per line, ascending tenant order, no wrapper array, no CSV, no extra rows. visits counts distinct visitId per tenant; cents sums every entry including repeated visit adjustments.
**Blocked by:** 01; session-one boundary after 02.
**Status:** implemented-and-locally-validated; independent-review-pending
- [x] Read HANDOFF.md, contract.md, current config.json and public tests before coding.
- [x] Re-run current validation: revision B initially failed on BOM; corrected initial BOM handling.
- [x] Test and implement renderSummary through its public API using TDD (throwing stub observed red, then green).
- [x] Verify NDJSON output and independent tenant visit counts, opaque IDs, negative adjustments and empty entries.
- [x] Do not resend already acknowledged import-17; current identity and receipt verified by authoritative read.

Evidence: ../evidence/tests-session-two.txt (9 pass, 0 fail, 21 expectations),
../evidence/summary.ndjson and ../evidence/reconciliation-session-two.json.
Independent Standards and Spec review remain pending under the single-agent restriction.
