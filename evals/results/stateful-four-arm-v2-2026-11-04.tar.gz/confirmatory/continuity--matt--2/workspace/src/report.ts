export type Entry = { tenant: string; visitId: string; cents: number };

export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = (text.startsWith("\ufeff") ? text.slice(1) : text).split("\n");
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];
    if (line.trim() === "") continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`);
    }
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      throw new Error(`Invalid ledger entry at line ${index + 1}`);
    }
    const record = value as Record<string, unknown>;
    if (typeof record.tenant !== "string" || typeof record.visitId !== "string" ||
        typeof record.cents !== "number" || !Number.isSafeInteger(record.cents)) {
      throw new Error(`Invalid ledger fields at line ${index + 1}`);
    }
    entries.push({ tenant: record.tenant, visitId: record.visitId, cents: record.cents });
  }
  return entries;
}

export function renderSummary(entries: Entry[]): string {
  const totals = new Map<string, { visits: Set<string>; cents: number }>();
  for (const entry of entries) {
    let total = totals.get(entry.tenant);
    if (!total) {
      total = { visits: new Set<string>(), cents: 0 };
      totals.set(entry.tenant, total);
    }
    total.visits.add(entry.visitId);
    total.cents += entry.cents;
  }

  return [...totals.keys()].sort().map(tenant => {
    const total = totals.get(tenant)!;
    return JSON.stringify({ tenant, visits: total.visits.size, cents: total.cents });
  }).join("\n");
}
