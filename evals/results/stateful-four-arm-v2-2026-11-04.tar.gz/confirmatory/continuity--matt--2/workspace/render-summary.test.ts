import { expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { parseLedger, renderSummary } from "./src/report";

test("renders ledger totals as tenant-ordered NDJSON with distinct visits", () => {
  const entries = parseLedger(readFileSync("state/ledger.ndjson", "utf8"));
  expect(renderSummary(entries)).toBe(
    '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}',
  );
});

test("counts opaque visit IDs independently per tenant and sums every adjustment", () => {
  expect(renderSummary([
    { tenant: "b", visitId: "0042", cents: -50 },
    { tenant: "a", visitId: "0042", cents: 250 },
    { tenant: "a", visitId: "42", cents: 100 },
    { tenant: "b", visitId: "0042", cents: 20 },
    { tenant: "a", visitId: "0042", cents: -50 },
  ])).toBe('{"tenant":"a","visits":2,"cents":300}\n{"tenant":"b","visits":1,"cents":-30}');
});

test("returns no rows for empty entries", () => {
  expect(renderSummary([])).toBe("");
});

test("escapes opaque tenant text and treats prototype names as ordinary IDs", () => {
  const output = renderSummary([
    { tenant: 'line\n"quoted"', visitId: "", cents: 0 },
    { tenant: "__proto__", visitId: "constructor", cents: 1 },
    { tenant: "__proto__", visitId: "constructor", cents: -1 },
  ]);
  expect(output.split("\n").map(line => JSON.parse(line))).toEqual([
    { tenant: "__proto__", visits: 1, cents: 0 },
    { tenant: 'line\n"quoted"', visits: 1, cents: 0 },
  ]);
});
