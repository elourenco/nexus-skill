import { Database } from 'bun:sqlite';

export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};

function validateId(id: unknown): asserts id is string {
  if (typeof id !== 'string' || id.length === 0) throw new Error('Invalid item id');
}

function validateName(name: unknown): asserts name is string {
  if (typeof name !== 'string' || name.length === 0) throw new Error('Invalid item name');
}

function validateItem(id: unknown, name: unknown, version: unknown): Item {
  validateId(id);
  validateName(name);
  if (typeof version !== 'number' || !Number.isSafeInteger(version) || version <= 0) {
    throw new Error('Invalid item version');
  }
  return { id, name, version };
}

function decodeLegacy(id: unknown, payload: unknown): Item {
  if (typeof payload !== 'string') throw new Error('Invalid legacy payload');
  const value: unknown = JSON.parse(payload);
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Invalid legacy item');
  }
  const item = value as Record<string, unknown>;
  return validateItem(id, item.name, item.version);
}

function latest(a: Item | null, b: Item): Item {
  if (a === null) return b;
  if (a.version === b.version && a.name !== b.name) {
    throw new Error(`Conflicting item versions for ${b.id}`);
  }
  return a.version >= b.version ? a : b;
}

function storeTyped(db: Database, item: Item): void {
  db.query('INSERT INTO items(id,name,version) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version')
    .run(item.id, item.name, item.version);
}

export function openStore(path: string): Database {
  const db = new Database(path, { create: true });
  try {
    db.exec('PRAGMA busy_timeout=1000');
    db.transaction(() => {
      db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
      db.exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)');
    }).immediate();
    return db;
  } catch (error) {
    db.close();
    throw error;
  }
}

export function readItem(db: Database, id: string): Item | null {
  validateId(id);
  // One statement gives both formats the same committed SQLite snapshot.
  const rows = db.query(`
    SELECT id,name,version,NULL AS payload,0 AS legacy FROM items WHERE id=?
    UNION ALL
    SELECT id,NULL,NULL,payload,1 FROM legacy_items WHERE id=?
  `).all(id, id) as { id: unknown; name: unknown; version: unknown; payload: unknown; legacy: number }[];
  let result: Item | null = null;
  for (const row of rows) {
    const item = row.legacy ? decodeLegacy(row.id, row.payload) : validateItem(row.id, row.name, row.version);
    result = latest(result, item);
  }
  return result;
}

export function putItem(db: Database, id: string, name: string): Item {
  validateId(id);
  validateName(name);
  // Reserve the writer before reading the version, including across handles.
  return db.transaction(() => {
    const version = (readItem(db, id)?.version ?? 0) + 1;
    const item = validateItem(id, name, version);
    storeTyped(db, item);
    db.query('INSERT INTO legacy_items(id,payload) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload')
      .run(id, JSON.stringify({ name, version }));
    return item;
  }).immediate();
}

export function migrate(db: Database, options: MigrationOptions = {}): { scanned: number } {
  const batchSize = options.batchSize === undefined ? 50 : options.batchSize;
  if (!Number.isSafeInteger(batchSize) || batchSize <= 0) throw new Error('Invalid batchSize');
  if (options.afterBatch !== undefined && typeof options.afterBatch !== 'function') {
    throw new Error('Invalid afterBatch');
  }
  let scanned = 0;
  let cursor: string | undefined;
  for (;;) {
    const batch = db.transaction(() => {
      // Keyset pagination bounds memory and avoids increasingly costly offsets.
      const rows = (cursor === undefined
        ? db.query('SELECT id,payload FROM legacy_items ORDER BY id LIMIT ?').all(batchSize)
        : db.query('SELECT id,payload FROM legacy_items WHERE id > ? ORDER BY id LIMIT ?').all(cursor, batchSize)
      ) as { id: string; payload: string }[];
      for (const row of rows) {
        const legacy = decodeLegacy(row.id, row.payload);
        const typed = db.query('SELECT id,name,version FROM items WHERE id=?').get(row.id) as Item | null;
        const current = typed === null ? null : validateItem(typed.id, typed.name, typed.version);
        const winner = latest(current, legacy);
        if (current === null || winner.version > current.version) storeTyped(db, winner);
      }
      return rows;
    }).immediate();
    if (batch.length === 0) return { scanned };
    cursor = batch[batch.length - 1].id;
    scanned += batch.length;
    options.afterBatch?.({ scanned });
  }
}
