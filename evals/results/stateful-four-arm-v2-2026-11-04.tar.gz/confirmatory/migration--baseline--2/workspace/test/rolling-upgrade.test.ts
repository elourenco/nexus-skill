import { expect, test } from 'bun:test';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore, putItem, readItem, migrate } from '../src/store';
import { openLegacy, legacyPut, legacyRead } from '../legacy/producer';

function fixture(run: (path: string) => void) {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-rolling-'));
  try { run(join(dir, 'catalog.sqlite')); }
  finally { rmSync(dir, { recursive: true, force: true }); }
}

function rawLegacy(db: ReturnType<typeof openStore>, id: string, payload: string) {
  db.query('INSERT INTO legacy_items VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').run(id, payload);
}

function typed(db: ReturnType<typeof openStore>) {
  return db.query('SELECT * FROM items ORDER BY id').all();
}

test('opens a real legacy-only database without changing legacy bytes', () => fixture(path => {
  copyFileSync(new URL('../data/legacy.sqlite', import.meta.url), path);
  const old = openLegacy(path);
  const before = old.query('SELECT * FROM legacy_items ORDER BY id').all();
  const db = openStore(path);
  try {
    expect(readItem(db, 'alpha')).toEqual({ id: 'alpha', name: 'Desktop edit before upgrade', version: 2 });
    const batches: number[] = [];
    expect(migrate(db, { batchSize: 3, afterBatch: ({ scanned }) => batches.push(scanned) })).toEqual({ scanned: 4 });
    expect(batches).toEqual([3, 4]);
    expect(old.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(before);
    expect(readItem(db, "id'with punctuation")?.name).toBe('  Keep these spaces  ');
    expect(readItem(db, 'beta')?.name).toBe('Café — São Paulo');
  } finally { db.close(); old.close(); }
}));

test('old and new writers alternate through two handles before and after migration', () => fixture(path => {
  const old = openLegacy(path);
  const db = openStore(path);
  try {
    legacyPut(old, 'a', 'old');
    expect(putItem(db, 'a', '  新しい 🚀  ').version).toBe(2);
    expect(legacyRead(old, 'a')).toEqual(readItem(db, 'a'));
    migrate(db);
    legacyPut(old, 'a', 'desktop after migration');
    expect(readItem(db, 'a')?.version).toBe(3);
    expect(putItem(db, 'a', 'new again').version).toBe(4);
    legacyPut(old, 'a', 'final');
    expect(migrate(db)).toEqual({ scanned: 1 });
    expect(migrate(db)).toEqual({ scanned: 1 });
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'final', version: 5 });
  } finally { db.close(); old.close(); }
}));

test('committed batches survive interruption and reopen; old writes remain discoverable', () => fixture(path => {
  let db = openStore(path);
  const old = openLegacy(path);
  try {
    for (const id of ['a', 'b', 'z']) legacyPut(old, id, id);
    const failure = new Error('interrupted');
    expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => {
      expect(scanned).toBe(2);
      expect(typed(old).length).toBe(2);
      legacyPut(old, 'a', 'updated behind cursor');
      legacyPut(old, 'z', 'updated ahead');
      throw failure;
    } })).toThrow(failure);
    db.close();
    db = openStore(path);
    expect(readItem(db, 'a')?.name).toBe('updated behind cursor');
    expect(migrate(db, { batchSize: 1 })).toEqual({ scanned: 3 });
    expect(typed(db)).toEqual([
      { id: 'a', name: 'updated behind cursor', version: 2 },
      { id: 'b', name: 'b', version: 1 },
      { id: 'z', name: 'updated ahead', version: 2 },
    ]);
  } finally { db.close(); old.close(); }
}));

test('a callback can write between successful batches without locks or stale copying', () => fixture(path => {
  const db = openStore(path);
  const old = openLegacy(path);
  try {
    legacyPut(old, 'a', 'a'); legacyPut(old, 'z', 'z');
    const calls: number[] = [];
    expect(migrate(db, { batchSize: 1, afterBatch: ({ scanned }) => {
      calls.push(scanned);
      if (scanned === 1) { legacyPut(old, 'a', 'behind'); legacyPut(old, 'z', 'ahead'); }
    } })).toEqual({ scanned: 2 });
    expect(calls).toEqual([1, 2]);
    expect(readItem(db, 'a')?.name).toBe('behind');
    expect(typed(db)[1]).toEqual({ id: 'z', name: 'ahead', version: 2 });
    migrate(db);
    expect(typed(db)[0]).toEqual({ id: 'a', name: 'behind', version: 2 });
  } finally { db.close(); old.close(); }
}));

test('bad data rolls back its entire batch, preserves source bytes, and permits repair', () => fixture(path => {
  const db = openStore(path);
  try {
    for (const id of ['a', 'b', 'c']) legacyPut(db, id, id);
    rawLegacy(db, 'd', '{broken');
    const before = db.query('SELECT * FROM legacy_items ORDER BY id').all();
    const batches: number[] = [];
    expect(() => migrate(db, { batchSize: 2, afterBatch: x => batches.push(x.scanned) })).toThrow();
    expect(batches).toEqual([2]);
    expect(typed(db).map((x: any) => x.id)).toEqual(['a', 'b']);
    expect(db.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(before);
    rawLegacy(db, 'd', JSON.stringify({ name: 'repaired', version: 1 }));
    expect(migrate(db, { batchSize: 2 })).toEqual({ scanned: 4 });
    expect(typed(db).length).toBe(4);
  } finally { db.close(); }
}));

test('higher typed version survives copying; divergent equal versions throw', () => fixture(path => {
  const db = openStore(path);
  try {
    legacyPut(db, 'a', 'old');
    db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'new', 5);
    expect(migrate(db)).toEqual({ scanned: 1 });
    expect(readItem(db, 'a')?.version).toBe(5);
    expect(putItem(db, 'a', 'published').version).toBe(6);
    rawLegacy(db, 'a', JSON.stringify({ name: 'conflict', version: 6 }));
    expect(() => readItem(db, 'a')).toThrow();
    expect(() => putItem(db, 'a', 'overwrite')).toThrow();
    expect(() => migrate(db)).toThrow();
    expect(typed(db)[0]).toEqual({ id: 'a', name: 'published', version: 6 });
  } finally { db.close(); }
}));

test('storage failure rolls back both formats, including insert and update', () => fixture(path => {
  const db = openStore(path);
  try {
    putItem(db, 'existing', 'original');
    db.exec(`CREATE TRIGGER fail_insert BEFORE INSERT ON legacy_items BEGIN SELECT RAISE(ABORT, 'storage failure'); END`);
    expect(() => putItem(db, 'new', 'new')).toThrow();
    expect(readItem(db, 'new')).toBeNull();
    expect(() => putItem(db, 'existing', 'changed')).toThrow();
    expect(readItem(db, 'existing')).toEqual({ id: 'existing', name: 'original', version: 1 });
    expect(legacyRead(db, 'existing')?.name).toBe('original');
  } finally { db.close(); }
}));

test('invalid options, inputs, persisted values and version overflow throw without mutation', () => fixture(path => {
  const db = openStore(path);
  try {
    legacyPut(db, 'a', 'a');
    for (const batchSize of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, null, '2']) {
      expect(() => migrate(db, { batchSize: batchSize as number })).toThrow();
      expect(typed(db)).toEqual([]);
    }
    for (const value of ['', null, 42]) {
      expect(() => readItem(db, value as string)).toThrow();
      expect(() => putItem(db, value as string, 'valid')).toThrow();
      expect(() => putItem(db, 'valid', value as string)).toThrow();
    }
    for (const payload of ['null', '[]', '{}', '{', '{"name":"","version":1}', '{"name":7,"version":1}', '{"name":"ok","version":0}', '{"name":"ok","version":1.5}', '{"name":"ok","version":9007199254740992}']) {
      rawLegacy(db, 'bad', payload);
      expect(() => readItem(db, 'bad')).toThrow();
      expect(() => migrate(db)).toThrow();
      expect(typed(db)).toEqual([]);
    }
    db.query('DELETE FROM legacy_items WHERE id=?').run('bad');
    rawLegacy(db, 'max', JSON.stringify({ name: 'max', version: Number.MAX_SAFE_INTEGER }));
    expect(() => putItem(db, 'max', 'overflow')).toThrow();
    expect(legacyRead(db, 'max')?.version).toBe(Number.MAX_SAFE_INTEGER);
    db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'invalid older copy', 0);
    expect(() => readItem(db, 'a')).toThrow();
    expect(() => migrate(db)).toThrow();
  } finally { db.close(); }
}));

test('empty migration has no callback; default batches and large opaque names are preserved', () => fixture(path => {
  const db = openStore(path);
  try {
    expect(migrate(db, { afterBatch: () => { throw new Error('empty callback'); } })).toEqual({ scanned: 0 });
    const name = '  名🚀 '.repeat(20000);
    for (let i = 0; i < 51; i++) legacyPut(db, `sparse-${i * 100}`, name);
    const batches: number[] = [];
    expect(migrate(db, { afterBatch: x => batches.push(x.scanned) })).toEqual({ scanned: 51 });
    expect(batches).toEqual([50, 51]);
    expect(readItem(db, 'sparse-5000')?.name).toBe(name);
    expect(putItem(db, "λ' ; --", '   ').name).toBe('   ');
  } finally { db.close(); }
}));
