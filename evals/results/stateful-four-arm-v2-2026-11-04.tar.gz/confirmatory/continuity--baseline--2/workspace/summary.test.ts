import { expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { parseLedger, renderSummary } from "./src/report";

test("renders the persisted ledger as ordered NDJSON, counting visits once and all adjustments", () => {
  const entries = parseLedger(readFileSync("state/ledger.ndjson", "utf8"));
  expect(renderSummary(entries)).toBe(
    '{"tenant":"a","visits":1,"cents":200}\n{"tenant":"b","visits":1,"cents":150}',
  );
});

test("keeps opaque tenant/visit identities, escapes JSON, and leaves input untouched", () => {
  const entries = Object.freeze([
    Object.freeze({ tenant: "__proto__", visitId: "0042", cents: -2 }),
    Object.freeze({ tenant: "a\n\"", visitId: "0042", cents: 3 }),
    Object.freeze({ tenant: "__proto__", visitId: "42", cents: 2 }),
    Object.freeze({ tenant: "a\n\"", visitId: "0042", cents: 4 }),
    Object.freeze({ tenant: "", visitId: "", cents: 0 }),
  ]);
  const snapshot = JSON.stringify(entries);
  const output = renderSummary([...entries]);
  expect(output.split("\n").map(line => JSON.parse(line))).toEqual([
    { tenant: "", visits: 1, cents: 0 },
    { tenant: "__proto__", visits: 2, cents: 0 },
    { tenant: "a\n\"", visits: 1, cents: 7 },
  ]);
  expect(JSON.stringify(entries)).toBe(snapshot);
  expect(renderSummary([])).toBe("");
});

test("uses exact sums and rejects unsafe final totals in both directions", () => {
  const row = (cents: number) => ({ tenant: "a", visitId: "1", cents });
  for (const limit of [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER]) {
    const adjustment = Math.sign(limit);
    expect(renderSummary([row(limit), row(adjustment), row(-adjustment)]))
      .toBe(JSON.stringify({ tenant: "a", visits: 1, cents: limit }));
    expect(() => renderSummary([row(limit), row(adjustment)]))
      .toThrow('Unsafe cents total for tenant "a"');
  }
  expect(() => renderSummary([row(0.5)])).toThrow("Invalid cents");
});

test("accepts only a document-leading BOM and preserves physical error lines", () => {
  const row = '{"tenant":"a","visitId":"1","cents":1}';
  expect(parseLedger(`\ufeff\n${row}\r\n`)).toEqual([{ tenant: "a", visitId: "1", cents: 1 }]);
  expect(parseLedger("\ufeff")).toEqual([]);
  expect(() => parseLedger(`${row}\n\ufeff${row}`)).toThrow("line 2");
  expect(() => parseLedger(`\ufeff${row}\ninvalid`)).toThrow("line 2");
});
