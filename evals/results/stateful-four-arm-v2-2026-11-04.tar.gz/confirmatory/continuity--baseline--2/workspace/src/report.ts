export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = (text.startsWith("\ufeff") ? text.slice(1) : text).split("\n");

  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];
    if (/^[\t\r ]*$/.test(line)) continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`);
    }

    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      throw new Error(`Invalid ledger entry at line ${index + 1}`);
    }
    const row = value as Record<string, unknown>;
    if (
      typeof row.tenant !== "string" ||
      typeof row.visitId !== "string" ||
      typeof row.cents !== "number" ||
      !Number.isSafeInteger(row.cents)
    ) {
      throw new Error(`Invalid ledger fields at line ${index + 1}`);
    }
    entries.push({ tenant: row.tenant, visitId: row.visitId, cents: row.cents });
  }

  return entries;
}
export function renderSummary(entries: Entry[]): string {
  const tenants = new Map<string, { visits: Set<string>; cents: bigint }>();

  for (const entry of entries) {
    if (!Number.isSafeInteger(entry.cents)) {
      throw new Error(`Invalid cents for tenant ${JSON.stringify(entry.tenant)}`);
    }
    let total = tenants.get(entry.tenant);
    if (!total) {
      total = { visits: new Set(), cents: 0n };
      tenants.set(entry.tenant, total);
    }
    total.visits.add(entry.visitId);
    total.cents += BigInt(entry.cents);
  }

  // Accumulate exactly so adjustments can cancel even after an unsafe subtotal.
  const min = BigInt(Number.MIN_SAFE_INTEGER);
  const max = BigInt(Number.MAX_SAFE_INTEGER);
  return [...tenants.keys()].sort().map((tenant) => {
    const total = tenants.get(tenant)!;
    if (total.cents < min || total.cents > max) {
      throw new Error(`Unsafe cents total for tenant ${JSON.stringify(tenant)}`);
    }
    return JSON.stringify({ tenant, visits: total.visits.size, cents: Number(total.cents) });
  }).join("\n");
}
