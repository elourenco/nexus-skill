export type Entry={tenant:string;visitId:string;cents:number};
export function parseLedger(text: string): Entry[] {
  const entries: Entry[] = [];
  const lines = text.split("\n");

  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];
    if (/^[\t\r ]*$/.test(line)) continue;

    let value: unknown;
    try {
      value = JSON.parse(line);
    } catch {
      throw new Error(`Invalid ledger JSON at line ${index + 1}`);
    }

    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      throw new Error(`Invalid ledger entry at line ${index + 1}`);
    }
    const row = value as Record<string, unknown>;
    if (
      typeof row.tenant !== "string" ||
      typeof row.visitId !== "string" ||
      typeof row.cents !== "number" ||
      !Number.isSafeInteger(row.cents)
    ) {
      throw new Error(`Invalid ledger fields at line ${index + 1}`);
    }
    entries.push({ tenant: row.tenant, visitId: row.visitId, cents: row.cents });
  }

  return entries;
}
export function renderSummary(entries:Entry[]):string{throw new Error("pending output format decision")}
