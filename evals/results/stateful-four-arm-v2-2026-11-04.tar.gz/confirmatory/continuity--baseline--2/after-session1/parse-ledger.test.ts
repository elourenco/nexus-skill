import { expect, test } from "bun:test";
import { parseLedger } from "./src/report";

test("ignores blank lines and preserves opaque IDs, duplicates and adjustments", () => {
  const row = { tenant: " a ", visitId: "0042", cents: -50 };
  expect(parseLedger(`\n \t\r\n${JSON.stringify(row)}\r\n${JSON.stringify(row)}\n`))
    .toEqual([row, row]);
  expect(parseLedger("")).toEqual([]);
});

test("accepts safe integer boundaries and zero", () => {
  for (const cents of [Number.MIN_SAFE_INTEGER, 0, Number.MAX_SAFE_INTEGER]) {
    expect(parseLedger(JSON.stringify({ tenant: "a", visitId: "", cents }))[0].cents)
      .toBe(cents);
  }
});

test("rejects malformed JSON without skipping lines", () => {
  expect(() => parseLedger('\n{"tenant":"a","visitId":"1","cents":1}\nbroken'))
    .toThrow("line 3");
});

test("rejects wrong shapes, missing fields and invalid amounts", () => {
  const invalid = [null, [], 1, "row", {},
    { tenant: 1, visitId: "1", cents: 1 },
    { tenant: "a", visitId: 42, cents: 1 },
    { tenant: "a", visitId: "1", cents: "1" },
    { tenant: "a", visitId: "1", cents: null },
    { tenant: "a", visitId: "1", cents: 0.5 },
    { tenant: "a", visitId: "1", cents: Number.MAX_SAFE_INTEGER + 1 },
    { tenant: "a", visitId: "1", cents: Number.MIN_SAFE_INTEGER - 1 },
  ];
  for (const row of invalid) {
    expect(() => parseLedger(JSON.stringify(row))).toThrow("line 1");
  }
  expect(() => parseLedger('{"tenant":"a","visitId":"1","cents":1e309}'))
    .toThrow("line 1");
});
