import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { importRoutes } from "../src/importer";

// Observation only: no implementation changes or assumed product decisions.
const dir = await mkdtemp(join(import.meta.dir, "probe-state-"));
const crew = (id = "c", tenant = "a", status = "active", capacity = 1) =>
  ({ id, tenant, status, capacity });
const base = (crews = [crew()], assignments: unknown[] = []) =>
  ({ crews, assignments, uploads: {} });
let serial = 0;
async function scenario(name: string, initial: unknown, calls: { rows: unknown; tenant?: string; uploadId?: string; apply?: boolean }[], concurrent = false) {
  const file = join(dir, `${serial++}.json`);
  const before = JSON.stringify(initial);
  await writeFile(file, before);
  const run = async (call: typeof calls[number]) => {
    try {
      return await importRoutes(file, call.tenant ?? "a", call.uploadId ?? "u", call.rows, call.apply ?? true);
    } catch (error) {
      return { thrown: error instanceof Error ? error.message : String(error) };
    }
  };
  const results = [];
  if (concurrent) results.push(...await Promise.all(calls.map(run)));
  else for (const call of calls) results.push(await run(call));
  const after = await readFile(file, "utf8");
  let persisted: unknown;
  try { persisted = JSON.parse(after); } catch { persisted = { invalidJSON: after }; }
  console.log(JSON.stringify({ name, results, unchanged: before === after, persisted }));
}
try {
  await scenario("opaque visit ID", base(), [{ rows: [{ visitId: "0007", crewId: "c" }] }]);
  await scenario("foreign crew", base([crew("c", "b")]), [{ rows: [{ visitId: "7", crewId: "c" }] }]);
  await scenario("paused crew", base([crew("c", "a", "paused")]), [{ rows: [{ visitId: "7", crewId: "c" }] }]);
  await scenario("archived crew", base([crew("c", "a", "archived")]), [{ rows: [{ visitId: "7", crewId: "c" }] }]);
  await scenario("zero capacity", base([crew("c", "a", "active", 0)]), [{ rows: [{ visitId: "7", crewId: "c" }] }]);
  await scenario("duplicate visit same crew", base(), [{ rows: [{ visitId: "7", crewId: "c" }, { visitId: "7", crewId: "c" }] }]);
  await scenario("existing visit same crew", base(undefined, [{ tenant: "a", visitId: "7", crewId: "c" }]), [{ rows: [{ visitId: "7", crewId: "c" }] }]);
  await scenario("existing visit different crew", base([crew(), crew("d")], [{ tenant: "a", visitId: "7", crewId: "c" }]), [{ rows: [{ visitId: "7", crewId: "d" }] }]);
  await scenario("mixed valid and unknown crew", base(), [{ rows: [{ visitId: "7", crewId: "c" }, { visitId: "8", crewId: "missing" }] }]);
  for (const rows of [null, {}, [null], [{}], [{ visitId: {}, crewId: "c" }], [{ visitId: "7", crewId: 1 }]]) {
    await scenario(`malformed ${JSON.stringify(rows)}`, base([crew(), crew("1")]), [{ rows }]);
  }
  await scenario("identical replay", base(), [1, 2].map(() => ({ rows: [{ visitId: "7", crewId: "c" }] })));
  await scenario("changed upload", base(), [{ rows: [{ visitId: "7", crewId: "c" }] }, { rows: [{ visitId: "8", crewId: "c" }] }]);
  await scenario("refresh preview then apply", base(), [false, false, true].map(apply => ({ rows: [{ visitId: "7", crewId: "c" }], apply })));
  await scenario("stale preview", base(), [
    { rows: [{ visitId: "7", crewId: "c" }], apply: false },
    { rows: [{ visitId: "8", crewId: "c" }], uploadId: "other" },
    { rows: [{ visitId: "7", crewId: "c" }] },
  ]);
  await scenario("concurrent distinct uploads", base([crew("c", "a", "active", 10)]), [
    { rows: [{ visitId: "7", crewId: "c" }], uploadId: "u1" },
    { rows: [{ visitId: "8", crewId: "c" }], uploadId: "u2" },
  ], true);
} finally {
  await rm(dir, { recursive: true, force: true });
}
