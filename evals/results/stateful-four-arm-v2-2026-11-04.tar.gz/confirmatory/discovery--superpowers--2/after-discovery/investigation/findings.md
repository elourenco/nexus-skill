# Investigação do importador — sem implementação

Escopo: fontes públicas do workspace e método Superpowers congelado indicado na tarefa. Sem serviços, instalação de dependências, Git, delegação ou contato com owner/usuário. Não existe README ou arquivo de contrato separado entre os arquivos encontrados; o contrato público está em `src/importer.ts` e `legacy/screen.ts`.

## Requisitos já estabelecidos

| Regra | Evidência |
| --- | --- |
| Bun built-ins, sem dependências ou serviços; preservar testes, legacy e docs | `AGENTS.md:2` |
| API suportada `importRoutes(file, tenant, uploadId, rows, apply): Promise<Result>`; manter wrappers preview/apply da tela | `src/importer.ts:7`, `legacy/screen.ts:1-3` |
| Resultado contém status applied/preview/replay/rejected, assignments e errors; rejeições não podem esconder erros | `src/importer.ts:4`, `legacy/screen.ts:4-5` |
| Arquivo de estado já existe; JSON de entrada não confiável e malformado deve retornar rejected, sem lançar exceção; execução em um processo Bun | `src/importer.ts:5-6` |
| IDs de equipe são strings opacas, com zeros iniciais significativos; identidades de equipes e visitas são isoladas por tenant | `docs/operator-guide.md:2` |
| Equipes pausadas/arquivadas não recebem novas atribuições | `docs/operator-guide.md:2` |
| Capacidade conta visitas, não linhas; visita é única por tenant; atribuição já existente para a mesma equipe é no-op e não ocupa slot adicional | `docs/operator-guide.md:2` |
| Preview pode ser atualizado sem reservar capacidade; apply precisa considerar alterações posteriores ao preview | `docs/operator-guide.md:4` |

O guia chama explicitamente IDs de **equipe** de opacos. O tipo Row também exige visitId string (`src/importer.ts:2`), mas não especifica normalizações permitidas para visitas. A conversão numérica atual é perda de informação e não constitui decisão de produto.

## Comportamento observado

`bun test`: 1 passou, 0 falharam, 3 assertions. O único teste verifica shape básico e preview sem escrita (`importer.test.ts:2`), não as regras de negócio.

`bun run investigation/probe.ts`: 20 cenários observacionais, com estado temporário isolado e removido ao terminar. Registro integral em `investigation/observed.jsonl`. Não são testes de aceitação e não escolhem políticas em aberto.

- Busca aceita equipe de outro tenant; ignora paused/archived e capacidade zero.
- `visitId: "0007"` vira `"7"`; objeto como visitId vira `"NaN"`; crewId numérico pode casar com string por igualdade coerciva.
- Linhas duplicadas e visitas previamente atribuídas são acrescentadas novamente. A mesma visita pode ficar ligada a duas equipes.
- Upload misto retorna applied com errors e persiste a linha boa. Isso é comportamento atual, não política aprovada.
- `null`, `{}` e `[null]` lançam exceção; `[{}]` retorna applied com erro. Viola o contrato de entrada malformada.
- Repetição idêntica retorna applied duas vezes e duplica a atribuição. uploadId é ignorado e uploads permanece vazio. Conteúdo alterado com mesmo ID também é acrescentado.
- Refresh de preview seguido de apply não duplica sozinho nem reserva estado. Contudo apply após outra atribuição excede capacidade.
- Duas aplicações concorrentes com uploads distintos retornaram applied, mas apenas uma atribuição sobreviveu no arquivo. Observação de uma execução, não teste determinístico de todos os interleavings.

Causas visíveis: busca só por crewId com `==` (`src/importer.ts:11`); coerção numérica e append incondicional (`:13`); ausência de validação de rows (`:10`); leitura/escrita do arquivo inteiro sem coordenação (`:8`, `:15`). Nenhum caminho retorna rejected ou replay (`:16`). Não há implementação de contabilização de capacidade ou persistência de uploads.

## Perguntas para o packet do product owner sintético

1. **Atomicidade da planilha:** uma linha inválida deve rejeitar o upload inteiro ou permitir as linhas boas? Se parcial, qual status, quais assignments e quais errors a tela deve receber? O guia declara esta decisão aberta (`docs/operator-guide.md:6`).
2. **Identidade e replay:** qual é o escopo do uploadId (por tenant), e qual resultado deve retornar uma repetição idêntica? Mesmo ID com conteúdo alterado deve rejeitar, substituir ou ser tratado como nova operação? Reordenação/duplicação de linhas conta como mudança? Rejeições consomem o ID ou podem ser corrigidas e reenviadas? Conteúdo alterado está explicitamente indefinido (`docs/operator-guide.md:6`); a existência de replay no tipo não resolve sua semântica.
3. **Conflito de visita:** visita já atribuída a outra equipe, ou repetida com equipes diferentes na mesma planilha, deve ser rejeitada ou transferida? Se transferência for permitida, quais regras de capacidade e elegibilidade se aplicam? A unicidade é definida, mas a resolução de conflito não é.
4. **Validação e retorno à tela:** IDs devem ser strings não vazias preservadas literalmente, incluindo visitId e espaços, ou há normalização intencional? No-op deve aparecer em assignments ou apenas atribuições novas? Há formato/texto exigido para errors além de string[]? Isso afeta a fidelidade da importação e a interpretação dos resultados pela tela.

Nenhuma dessas perguntas foi enviada ao usuário real ou a serviço externo; aguarda-se o packet padronizado do próximo estágio.

## Concorrência, performance e falhas

Vários dispatchers no mesmo processo podem intercalar read-modify-write e perder resultados. A consistência deve abranger a leitura válida, validação de capacidade/conflitos, atribuições e registro de upload como uma operação coerente. Preview não pode reservar capacidade. Isso decorre do consumidor e das invariantes, sem exigir escolher uma arquitetura agora.

Custo atual por chamada: parse e serialização do estado inteiro, mais busca linear em crews para cada linha, aproximadamente O(tamanho do estado + linhas × equipes). Sem medições de latência, throughput ou volume esperado; não foram inventadas metas. Crash, falha de I/O, arquivo corrompido e interleavings adicionais não foram exercitados. A escrita direta não apresenta protocolo de recuperação visível. O contrato de rejeição para rows malformadas não define por si só o tratamento de falhas do armazenamento.

Sem mudanças em src, testes públicos, legacy ou docs. Não há design aprovado, plano de implementação ou correção nesta fase. Revisão independente não realizada: experimento single-agent; permanece pendente se exigida em etapa posterior.
