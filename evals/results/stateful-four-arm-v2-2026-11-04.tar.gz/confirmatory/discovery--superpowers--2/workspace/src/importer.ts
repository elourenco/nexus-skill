import { open, readFile, realpath, rename, unlink } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';

export type Row = { visitId: string; crewId: string };
export type State = {
  crews: { tenant: string; id: string; status: 'active' | 'paused' | 'archived'; capacity: number }[];
  assignments: { tenant: string; visitId: string; crewId: string }[];
  uploads: Record<string, unknown>;
};
export type Result = {
  status: 'applied' | 'preview' | 'replay' | 'rejected';
  assignments: State['assignments'];
  errors: string[];
};

const isObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);
const isId = (value: unknown): value is string => typeof value === 'string' && value.length > 0;
const reject = (...errors: string[]): Result => ({ status: 'rejected', assignments: [], errors });
const key = (tenant: string, id: string): string => JSON.stringify([tenant, id]);

function parseRows(value: unknown): Row[] | undefined {
  if (!Array.isArray(value)) return;
  const rows: Row[] = [];
  for (const item of value) {
    if (!isObject(item) || !isId(item.visitId) || !isId(item.crewId)) return;
    rows.push({ visitId: item.visitId, crewId: item.crewId });
  }
  return rows;
}

function validState(value: unknown): value is State {
  if (!isObject(value) || !Array.isArray(value.crews) ||
      !Array.isArray(value.assignments) || !isObject(value.uploads)) return false;
  const crews = new Set<string>();
  for (const crew of value.crews) {
    if (!isObject(crew) || !isId(crew.tenant) || !isId(crew.id) ||
        !['active', 'paused', 'archived'].includes(crew.status as string) ||
        !Number.isSafeInteger(crew.capacity) || (crew.capacity as number) < 0) return false;
    const id = key(crew.tenant, crew.id);
    if (crews.has(id)) return false;
    crews.add(id);
  }
  const visits = new Set<string>();
  for (const item of value.assignments) {
    if (!isObject(item) || !isId(item.tenant) || !isId(item.visitId) || !isId(item.crewId)) return false;
    const id = key(item.tenant, item.visitId);
    if (visits.has(id) || !crews.has(key(item.tenant, item.crewId))) return false;
    visits.add(id);
  }
  return true;
}

function evaluate(state: State, tenant: string, rows: Row[]): Result {
  const crews = new Map(state.crews.filter(c => c.tenant === tenant).map(c => [c.id, c]));
  const visits = new Map<string, string>();
  const counts = new Map<string, number>();
  for (const item of state.assignments) {
    if (item.tenant !== tenant) continue;
    visits.set(item.visitId, item.crewId);
    counts.set(item.crewId, (counts.get(item.crewId) ?? 0) + 1);
  }
  const assignments: State['assignments'] = [];
  const errors: string[] = [];
  for (const [index, row] of rows.entries()) {
    const error = (reason: string) => errors.push(`Row ${index + 1}: ${reason}`);
    const crew = crews.get(row.crewId);
    if (!crew) { error('unknown crew in tenant'); continue; }
    const existing = visits.get(row.visitId);
    if (existing !== undefined) {
      if (existing !== row.crewId) error('visit is assigned to another crew');
      continue;
    }
    if (crew.status !== 'active') { error('crew is not active'); continue; }
    const count = counts.get(crew.id) ?? 0;
    if (count >= crew.capacity) { error('crew capacity exceeded'); continue; }
    visits.set(row.visitId, row.crewId);
    counts.set(crew.id, count + 1);
    assignments.push({ tenant, visitId: row.visitId, crewId: row.crewId });
  }
  return errors.length ? reject(...errors) : { status: 'preview', assignments, errors: [] };
}

type Receipt = { version: 1; rows: Row[]; assignments: State['assignments'] };

function validReceipt(value: unknown, tenant: string): value is Receipt {
  return isObject(value) && value.version === 1 && parseRows(value.rows) !== undefined &&
    Array.isArray(value.assignments) && value.assignments.every(item =>
      isObject(item) && item.tenant === tenant && isId(item.visitId) && isId(item.crewId));
}

// A gate always resolves, including after a failed transaction; no rejected queue tails.
const queues = new Map<string, Promise<void>>();
async function serialized<T>(file: string, action: () => Promise<T>): Promise<T> {
  const previous = queues.get(file) ?? Promise.resolve();
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  queues.set(file, gate);
  await previous;
  try {
    return await action();
  } finally {
    release();
    if (queues.get(file) === gate) queues.delete(file);
  }
}

async function persist(file: string, state: State): Promise<void> {
  // Same directory keeps rename on the same filesystem. The live file is never truncated.
  const temporary = `${file}.${randomUUID()}.tmp`;
  try {
    const handle = await open(temporary, 'wx', 0o600);
    try {
      await handle.writeFile(JSON.stringify(state));
      await handle.sync();
    } finally {
      await handle.close();
    }
    // Commit point: both assignments and receipt become visible together.
    await rename(temporary, file);
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

// Existing state file; untrusted JSON must reject rather than throw.
// All callers sharing this file run in one Bun process; external writers are unsupported.
export async function importRoutes(file: string, tenant: string, uploadId: string, rows: unknown, apply: boolean): Promise<Result> {
  // Snapshot before the first await so caller mutations cannot alter queued work.
  const input = parseRows(rows);
  if (!isId(tenant) || !isId(uploadId) || typeof apply !== 'boolean' || !input) {
    return reject('Invalid upload identity, mode, or rows; IDs must be nonempty strings');
  }
  try {
    // Canonicalize aliases before queuing; persist to the target rather than replace a symlink.
    const canonical = await realpath(file);
    return await serialized<Result>(canonical, async () => {
      const state: unknown = JSON.parse(await readFile(canonical, 'utf8'));
      if (!validState(state)) return reject('Invalid route state');
      const identity = key(tenant, uploadId);
      if (Object.hasOwn(state.uploads, identity)) {
        const receipt = state.uploads[identity];
        if (!validReceipt(receipt, tenant)) return reject('Invalid upload receipt');
        if (JSON.stringify(receipt.rows) !== JSON.stringify(input)) {
          return reject('Upload identity already used with different ordered rows');
        }
        return { status: 'replay', assignments: receipt.assignments, errors: [] };
      }
      const result = evaluate(state, tenant, input);
      if (result.status === 'rejected' || !apply) return result;
      state.assignments.push(...result.assignments);
      const receipt: Receipt = { version: 1, rows: input, assignments: result.assignments };
      state.uploads[identity] = receipt;
      await persist(canonical, state);
      return { ...result, status: 'applied' };
    });
  } catch {
    return reject('Unable to read or persist route state');
  }
}
