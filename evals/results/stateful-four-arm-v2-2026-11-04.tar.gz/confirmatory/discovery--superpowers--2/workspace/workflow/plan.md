# Route Importer Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans in this single-agent workspace.

**Goal:** Atomic, tenant-safe, replay-safe route imports preserving the screen API.
**Architecture:** Indexed validation under a per-file queue; atomic state+receipt replacement.
**Tech Stack:** TypeScript, Bun test, Node filesystem built-ins.
**Spec:** workflow/design.md

## Global Constraints
- Bun built-ins only, no dependencies or services.
- Preserve existing tests, legacy/ and docs/ as evidence; no commits.
- Single process; existing state file; untrusted JSON returns rejected instead of throwing.
- No delegation or extra approvals; independent review pending.

## Review Focus
- Malformed rows/IDs: reject with no state changes.
- Duplicate/no-op visits at capacity: consume slots only for new unique visits.
- Upload tuple collisions and ordered contents: no identity confusion.
- Concurrent capacity/replay: no lost updates or duplicate effects.
- Corrupt files and failed rename: fail closed and release the queue.

### Task 1: Validate and evaluate atomic batches
Files: modify src/importer.ts; create importer.acceptance.test.ts.
Interfaces: preserve importRoutes(file, tenant, uploadId, rows, apply): Promise<Result>.
- [x] Write tests for tenant boundaries, literal IDs, malformed JSON values, status,
  capacity, duplicate visits, conflicts, rejected byte preservation, and advisory previews.
- [x] Run bun test importer.acceptance.test.ts; observe prototype failures.
- [x] Implement input/state validation and indexed, all-or-nothing evaluation.
- [x] Run bun test; expect all Task 1 and public tests green.

### Task 2: Persist replay and serialize commits safely
Files: same source and new test file.
Interfaces: same API; receipts live in State.uploads, legacy empty uploads remains valid.
- [x] Add tests for same/different identity, ordered changes, rejected retry, restart,
  prototype-like IDs, concurrent replay/capacity/conflicts/lost updates, symlink alias,
  corrupt files and failed rename with recovery.
- [x] Run bun test; observe new failures before implementation.
- [x] Implement receipts, canonical-file queues and synced temporary-file rename.
- [x] Run bun test; expect all tests green, no temporary artifacts after failure.

### Final verification
- [x] Review implementation against sources and spec using frozen review checklist.
- [x] Run full bun test; record observed outcomes and limitations.
- [x] Leave independent review pending and all changes local; retain workflow evidence.
