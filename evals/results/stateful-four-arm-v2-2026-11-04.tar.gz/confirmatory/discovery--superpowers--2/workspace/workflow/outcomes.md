# Observed outcomes

Implemented in src/importer.ts; added importer.acceptance.test.ts. Existing importer.test.ts,
legacy/screen.ts, docs/operator-guide.md, AGENTS.md and investigation artifacts were preserved.
No README or separate contract file exists in the workspace listing; API and screen source
provide the public contract. No external services, installation, Git initialization, commits,
publication, method edits or delegation were performed.

The owner packet resolves the discovery questions about batch atomicity, replay identity,
ordered content and crew conflict. Rejected calls leave the state bytes unchanged and do not
reserve upload identity. Preview does not reserve anything. Validation checks current tenant,
crew status, visit ownership and distinct-visit capacity. Successful apply atomically persists
assignments and its receipt; identical requests replay without a write, including after restart.

Validation evidence:
- Task 1 RED: 24 failures against the prototype; GREEN: 25 tests passed including public test.
- Task 2 RED: 12 failures for missing receipts/coordination/atomic persistence; GREEN: 39 passed.
- Final `bun test`: 43 passed, 0 failed, 230 assertions across 2 files, Bun 1.4.2.
- Real temporary state files exercise tenant isolation, zero-preserving IDs, invalid JSON values,
  status, duplicate/no-op visits, conflicts, byte-preserving rejects, advisory preview, tuple
  identities, ordered changes, retries and empty batches.
- Concurrent tests exercise 20 distinct uploads, 10 identical retries, capacity contention,
  changed-content contention, crew conflict and symlink aliases.
- A fresh local Bun process replays the persisted receipt. A 150,000-visit batch persisted fully.
- One injected filesystem rename error exercises the real temp-write/sync path, unchanged live
  bytes, temp cleanup, queue release, retry and subsequent replay. Corrupt state is rejected
  without repair or rewrite. This is not an exhaustive filesystem fault campaign.

Engineering choices (not synthetic owner preferences): preserve nonempty string IDs verbatim,
ignore row properties outside Row, report only new assignments for no-ops, and return original
committed effects for replay. These retain typed identifiers and the original added-list shape.
Storage errors also return rejected with a visible error. Malformed existing state fails closed;
this change does not migrate or repair prototype-corrupted data.

Limits: queue coordination covers one process and canonical pathname (including symlinks), not
hard-link aliases, multiple processes or external writers. Reads and writes of the same file
serialize. Index evaluation is O(crews + assignments + rows); JSON read/rewrite cost scales
with the full state including retained receipts. Receipts are not pruned because that would
invalidate replay guarantees. No production latency/throughput target or sustained load was
measured; the large-batch assertion is a capacity check, not an SLA. File sync plus rename
avoids partial visible files; directory metadata/power-loss durability and process-crash
recovery/orphan cleanup have not been validated. No standalone TypeScript typechecker was
installed or run; Bun tests transpiled and executed the implementation.

Method adaptations and costs:
1. Workspace-local artifacts/direct commands replace Git-dependent scripts because this fixture
   has no .git and forbids initialization/commits; there is no commit-based recovery.
2. Explicit authorization and SINGLE-AGENT override additional approval/dispatch gates;
   independent design/code review remains pending. Author self-review is not independent review.
3. Literal nonempty IDs and effect-list returns follow the existing Row/API shape; a consumer
   requiring normalization or a full no-op report needs an explicit future contract decision.
4. Leave all work and evidence local; branch integration menu and cleanup are inapplicable under
   the user's no-commit/no-publication constraints. No integration guarantee is claimed.

Self-review: source inspected against requirements, planned review focus and frozen reviewer
checklist. No known critical/important findings remain from this author pass; no fabricated
reviewer approval and no deferred minor findings. Independent review is pending.
