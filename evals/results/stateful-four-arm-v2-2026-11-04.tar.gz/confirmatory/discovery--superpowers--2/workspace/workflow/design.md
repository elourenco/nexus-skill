# Local route importer design

Sources: AGENTS.md, src/importer.ts, legacy/screen.ts, docs/operator-guide.md,
investigation/findings.md, and the supplied synthetic owner packet.

Goal: trustworthy multi-dispatcher imports in one Bun process, retaining the screen API.
Owner decisions: atomic batches; identity tenant + uploadId; identical ordered rows replay;
changed rows reject; tenants independent; conflicting crew assignments reject.
Rejected attempts do not consume identity because rejection leaves state unchanged.

Approaches (engineering decision, not an owner preference): use a per-canonical-file
promise queue and whole-file atomic replacement. Optimistic retries require a CAS the
filesystem API does not provide; cross-process locks/database exceed the single-process
scope. Queue previews too so every read observes one committed snapshot. Distinct files
remain independent. Build tenant crew/visit indexes for O(state + rows) validation.

Validate all input before evaluation; preserve string IDs literally, reject empty/nonstring
IDs rather than silently coerce. This is a conservative implementation choice from Row's
string contract, not a newly claimed owner preference. Return only new effects in assignments;
no-ops contribute none. Replay returns the original effect list. Errors are nonempty on rejection.
These return choices keep the existing added-assignments interpretation and API shape.

Validate state shape/invariants and fail closed on corrupt state. Store versioned receipts
under collision-free JSON tuple keys with exact ordered (visitId, crewId) pairs and effect list.
Additional row fields are outside Row and ignored. Check receipts before current eligibility
so a committed upload remains replay after crews change. Preview never records a receipt.

Commit assignments and receipt together using an exclusive sibling temporary file, file sync,
then rename. Never truncate the live state. Pre-rename I/O failure rejects and cleans the temp;
release queue even after failure. No durability claim for power loss/directory metadata, no
coordination across processes, hard links, or external state writers. State file must exist.
No services, dependencies, commits, method edits, or changes to legacy/, docs/, original tests, fixture scripts or data.

Independent design/code review pending: single-agent experiment forbids dispatch.
Scope approval comes from the explicit user instruction; no further product approval required.
