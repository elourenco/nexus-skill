import { test, expect, spyOn } from 'bun:test';
import { mkdtempSync, writeFileSync, readFileSync, rmSync, symlinkSync, readdirSync } from 'node:fs';
import * as fsPromises from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { importRoutes, type State, type Result } from './src/importer';
import { preview, apply } from './legacy/screen';

const crew = (tenant = 'a', id = '01', capacity = 2, status: State['crews'][number]['status'] = 'active') => ({ tenant, id, capacity, status });
const row = (visitId = '0007', crewId = '01') => ({ visitId, crewId });
const assignment = (visitId = '0007', crewId = '01', tenant = 'a') => ({ tenant, visitId, crewId });
async function fixture(run: (file: string, initial: string) => Promise<void>, state: State = { crews: [crew()], assignments: [], uploads: {} }) {
  const dir = mkdtempSync(join(tmpdir(), 'routes-acceptance-'));
  const file = join(dir, 'state.json');
  const initial = JSON.stringify(state, null, 2);
  writeFileSync(file, initial);
  try { await run(file, initial); } finally { rmSync(dir, { recursive: true, force: true }); }
}
const saved = (file: string): State => JSON.parse(readFileSync(file, 'utf8'));
function rejected(result: Result, file: string, initial: string) {
  expect(result.status).toBe('rejected');
  expect(result.assignments).toEqual([]);
  expect(result.errors.length).toBeGreaterThan(0);
  expect(readFileSync(file, 'utf8')).toBe(initial);
}

test('preserves opaque IDs and selects crews within tenant through screen wrappers', async () => {
  await fixture(async file => {
    expect(await apply(file, 'a', 'u', [row()])).toEqual({ status: 'applied', assignments: [assignment()], errors: [] });
    expect(saved(file).assignments).toEqual([assignment()]);
  }, { crews: [crew('b', '01', 0, 'paused'), crew()], assignments: [], uploads: {} });
});

test('rejects a crew that exists only in another tenant', async () => {
  await fixture(async (file, initial) => rejected(await importRoutes(file, 'b', 'u', [row()], true), file, initial));
});

for (const status of ['paused', 'archived'] as const) test(`rejects new assignments to ${status} crew atomically`, async () => {
  await fixture(async (file, initial) => rejected(await apply(file, 'a', 'u', [row('good'), row('bad', 'closed')]), file, initial),
    { crews: [crew(), crew('a', 'closed', 2, status)], assignments: [], uploads: {} });
});

for (const rows of [null, {}, 'rows', 4, [null], [{}], [row('x', 'missing')], [{ visitId: 7, crewId: '01' }], [{ visitId: '7', crewId: 1 }], [row('')], [row('x', '')], [row('valid'), null]]) {
  test(`malformed or invalid rows reject without effects: ${JSON.stringify(rows)}`, async () => {
    await fixture(async (file, initial) => rejected(await importRoutes(file, 'a', 'u', rows, true), file, initial));
  });
}

test('does not normalize whitespace or numeric-looking strings', async () => {
  await fixture(async file => {
    const result = await apply(file, 'a', 'u', [row(' 007 ', ' 01 ')]);
    expect(result.assignments).toEqual([assignment(' 007 ', ' 01 ')]);
    expect(saved(file).assignments).toEqual([assignment(' 007 ', ' 01 ')]);
  }, { crews: [crew('a', ' 01 ')], assignments: [], uploads: {} });
});

test('counts distinct visits rather than duplicate spreadsheet rows', async () => {
  await fixture(async file => {
    const result = await apply(file, 'a', 'u', [row(), row(), row('8')]);
    expect(result.status).toBe('applied');
    expect(result.assignments).toEqual([assignment(), assignment('8')]);
    expect(saved(file).assignments).toEqual([assignment(), assignment('8')]);
  });
});

test('capacity includes existing visits but excludes other tenants', async () => {
  await fixture(async (file, initial) => {
    rejected(await apply(file, 'a', 'u', [row('new'), row('excess')]), file, initial);
    expect((await apply(file, 'a', 'u', [row('new')])).status).toBe('applied');
    expect(saved(file).assignments).toHaveLength(3);
  }, { crews: [crew(), crew('b')], assignments: [assignment('old'), assignment('other', '01', 'b')], uploads: {} });
});

test('same-crew assignments remain no-ops even at capacity and on paused crew', async () => {
  await fixture(async file => {
    expect(await apply(file, 'a', 'u', [row(), row()])).toEqual({ status: 'applied', assignments: [], errors: [] });
    expect(saved(file).assignments).toEqual([assignment()]);
  }, { crews: [crew('a', '01', 1, 'paused')], assignments: [assignment()], uploads: {} });
});

test('rejects conflicting existing assignment', async () => {
  await fixture(async (file, initial) => rejected(await apply(file, 'a', 'u', [row('good'), row('old', '02')]), file, initial),
    { crews: [crew(), crew('a', '02')], assignments: [assignment('old')], uploads: {} });
});

test('rejects conflicting crews for one visit within the batch', async () => {
  await fixture(async (file, initial) => rejected(await apply(file, 'a', 'u', [row(), row('0007', '02')]), file, initial),
    { crews: [crew(), crew('a', '02')], assignments: [], uploads: {} });
});

test('preview refreshes reserve nothing and apply revalidates current capacity', async () => {
  await fixture(async (file, initial) => {
    for (let i = 0; i < 2; i++) {
      expect((await preview(file, 'a', 'preview', [row()])).status).toBe('preview');
      expect(readFileSync(file, 'utf8')).toBe(initial);
    }
    expect((await apply(file, 'a', 'other', [row('8')])).status).toBe('applied');
    const current = readFileSync(file, 'utf8');
    rejected(await apply(file, 'a', 'preview', [row()]), file, current);
  }, { crews: [crew('a', '01', 1)], assignments: [], uploads: {} });
});

test('zero capacity rejects a new visit', async () => {
  await fixture(async (file, initial) => rejected(await apply(file, 'a', 'u', [row()]), file, initial),
    { crews: [crew('a', '01', 0)], assignments: [], uploads: {} });
});

test('identical upload replays original effects from disk even after crew pauses', async () => {
  await fixture(async file => {
    const first = await apply(file, 'a', 'u', [row(), row()]);
    const state = saved(file);
    state.crews[0].status = 'paused';
    writeFileSync(file, JSON.stringify(state));
    const committed = readFileSync(file, 'utf8');
    expect(await apply(file, 'a', 'u', [row(), row()])).toEqual({ ...first, status: 'replay' });
    expect(await preview(file, 'a', 'u', [row(), row()])).toEqual({ ...first, status: 'replay' });
    expect(readFileSync(file, 'utf8')).toBe(committed);
  });
});

test('changed, reordered or removed rows under committed identity reject without mutation', async () => {
  await fixture(async file => {
    await apply(file, 'a', 'u', [row('1'), row('2')]);
    const committed = readFileSync(file, 'utf8');
    for (const rows of [[row('2'), row('1')], [row('1')], [row('1'), row('3')], [row('1'), row('2'), row('2')]]) {
      rejected(await apply(file, 'a', 'u', rows), file, committed);
      rejected(await preview(file, 'a', 'u', rows), file, committed);
    }
  });
});

test('rejected upload does not consume identity and can be corrected', async () => {
  await fixture(async (file, initial) => {
    rejected(await apply(file, 'a', 'u', [row('x', 'missing')]), file, initial);
    expect((await apply(file, 'a', 'u', [row()])).status).toBe('applied');
    expect((await apply(file, 'a', 'u', [row()])).status).toBe('replay');
  });
});

test('preview does not consume identity or constrain later rows', async () => {
  await fixture(async (file, initial) => {
    expect((await preview(file, 'a', 'u', [row()])).status).toBe('preview');
    expect(readFileSync(file, 'utf8')).toBe(initial);
    expect((await apply(file, 'a', 'u', [row('other')])).status).toBe('applied');
  });
});

test('upload identities are independent per tenant and cannot collide on separators', async () => {
  await fixture(async file => {
    for (const [tenant, uploadId] of [['a', 'b:c'], ['a:b', 'c'], ['b', 'b:c'], ['__proto__', 'constructor']]) {
      expect((await apply(file, tenant, uploadId, [row()])).status).toBe('applied');
      expect((await apply(file, tenant, uploadId, [row()])).status).toBe('replay');
    }
    expect(saved(file).assignments).toHaveLength(4);
  }, { crews: [crew(), crew('a:b'), crew('b'), crew('__proto__')], assignments: [], uploads: {} });
});

test('empty batch can be committed and replayed', async () => {
  await fixture(async file => {
    expect(await apply(file, 'a', 'u', [])).toEqual({ status: 'applied', assignments: [], errors: [] });
    expect(await apply(file, 'a', 'u', [])).toEqual({ status: 'replay', assignments: [], errors: [] });
  });
});

test('concurrent distinct uploads do not lose assignments or receipts', async () => {
  await fixture(async file => {
    const results = await Promise.all(Array.from({ length: 20 }, (_, i) => apply(file, 'a', `u${i}`, [row(`v${i}`)])));
    expect(results.every(r => r.status === 'applied')).toBe(true);
    expect(saved(file).assignments).toHaveLength(20);
    for (let i = 0; i < 20; i++) expect((await apply(file, 'a', `u${i}`, [row(`v${i}`)])).status).toBe('replay');
  }, { crews: [crew('a', '01', 20)], assignments: [], uploads: {} });
});

test('concurrent capacity competition admits exactly one upload', async () => {
  await fixture(async file => {
    const results = await Promise.all([apply(file, 'a', 'u1', [row('1')]), apply(file, 'a', 'u2', [row('2')])]);
    expect(results.map(r => r.status).sort()).toEqual(['applied', 'rejected']);
    expect(saved(file).assignments).toHaveLength(1);
    expect(results.find(r => r.status === 'rejected')!.errors.length).toBeGreaterThan(0);
  }, { crews: [crew('a', '01', 1)], assignments: [], uploads: {} });
});

test('concurrent identical identity has one application and remaining replays', async () => {
  await fixture(async file => {
    const results = await Promise.all(Array.from({ length: 10 }, () => apply(file, 'a', 'u', [row()])));
    expect(results.filter(r => r.status === 'applied')).toHaveLength(1);
    expect(results.filter(r => r.status === 'replay')).toHaveLength(9);
    expect(saved(file).assignments).toEqual([assignment()]);
  });
});

test('concurrent changed content under one identity has exactly one winner', async () => {
  await fixture(async file => {
    const results = await Promise.all([apply(file, 'a', 'u', [row('1')]), apply(file, 'a', 'u', [row('2')])]);
    expect(results.map(r => r.status).sort()).toEqual(['applied', 'rejected']);
    expect(saved(file).assignments).toHaveLength(1);
  });
});

test('concurrent crew conflict has exactly one winner', async () => {
  await fixture(async file => {
    const results = await Promise.all([apply(file, 'a', 'u1', [row()]), apply(file, 'a', 'u2', [row('0007', '02')])]);
    expect(results.map(r => r.status).sort()).toEqual(['applied', 'rejected']);
    expect(saved(file).assignments).toHaveLength(1);
  }, { crews: [crew(), crew('a', '02')], assignments: [], uploads: {} });
});

test('symlink paths share the same serialization queue and preserve the link', async () => {
  await fixture(async file => {
    const alias = join(file, '..', 'alias.json');
    symlinkSync(file, alias);
    const results = await Promise.all([apply(file, 'a', 'u1', [row('1')]), apply(alias, 'a', 'u2', [row('2')])]);
    expect(results.map(r => r.status)).toEqual(['applied', 'applied']);
    expect(saved(file).assignments).toHaveLength(2);
    expect(saved(alias)).toEqual(saved(file));
  });
});

test('corrupt state rejects without rewriting and subsequent valid state remains usable', async () => {
  await fixture(async file => {
    for (const text of ['{', '{}', JSON.stringify({ crews: [crew('a', '01', -1)], assignments: [], uploads: {} })]) {
      writeFileSync(file, text);
      rejected(await apply(file, 'a', 'u', [row()]), file, text);
    }
    writeFileSync(file, JSON.stringify({ crews: [crew()], assignments: [], uploads: {} }));
    expect((await apply(file, 'a', 'u', [row()])).status).toBe('applied');
  });
});

test('failed atomic rename preserves bytes, removes temp, releases queue and allows retry', async () => {
  await fixture(async (file, initial) => {
    // Inject only the filesystem commit failure; all reads, temp writes and cleanup are real.
    const rename = spyOn(fsPromises, 'rename').mockRejectedValueOnce(new Error('synthetic rename failure'));
    try { rejected(await apply(file, 'a', 'u', [row()]), file, initial); }
    finally { rename.mockRestore(); }
    expect(readdirSync(join(file, '..')).sort()).toEqual(['state.json']);
    expect((await apply(file, 'a', 'u', [row()])).status).toBe('applied');
    expect((await apply(file, 'a', 'u', [row()])).status).toBe('replay');
  });
});

test('persisted receipt replays in a fresh Bun process', async () => {
  await fixture(async file => {
    await apply(file, 'a', 'u', [row()]);
    const committed = readFileSync(file, 'utf8');
    const child = Bun.spawn([process.execPath, '--eval', `
      import { importRoutes } from './src/importer.ts';
      console.log(JSON.stringify(await importRoutes(process.argv[1], 'a', 'u', [{visitId:'0007', crewId:'01'}], true)));
    `, file], { cwd: import.meta.dir, stdout: 'pipe', stderr: 'pipe' });
    const [output, error, exit] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
    expect(exit).toBe(0);
    expect(error).toBe('');
    expect(JSON.parse(output)).toEqual({ status: 'replay', assignments: [assignment()], errors: [] });
    expect(readFileSync(file, 'utf8')).toBe(committed);
  });
});

test('large valid batch is not limited by argument spreading', async () => {
  await fixture(async file => {
    const rows = Array.from({ length: 150_000 }, (_, i) => row(`visit-${i}`));
    const result = await apply(file, 'a', 'large', rows);
    expect(result.status).toBe('applied');
    expect(result.assignments).toHaveLength(150_000);
    expect(saved(file).assignments).toHaveLength(150_000);
  }, { crews: [crew('a', '01', 150_000)], assignments: [], uploads: {} });
});

test('malformed upload identity and mode reject without filesystem effects', async () => {
  await fixture(async (file, initial) => {
    rejected(await apply(file, '', 'u', [row()]), file, initial);
    rejected(await apply(file, 'a', '', [row()]), file, initial);
    rejected(await importRoutes(file, 'a', 'u', [row()], null as never), file, initial);
  });
});

test('caller mutations after invocation do not change queued upload contents', async () => {
  await fixture(async file => {
    const rows = [row()];
    const result = apply(file, 'a', 'u', rows);
    rows[0].visitId = 'changed';
    rows.push(row('extra'));
    expect((await result).assignments).toEqual([assignment()]);
    expect((await apply(file, 'a', 'u', [row()])).status).toBe('replay');
  });
});
