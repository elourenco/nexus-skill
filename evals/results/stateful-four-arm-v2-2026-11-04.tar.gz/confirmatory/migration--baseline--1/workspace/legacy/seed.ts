import { existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { openLegacy, legacyPut } from './producer';

const path = resolve(process.argv[2] ?? new URL('../data/legacy.sqlite', import.meta.url).pathname);
if (existsSync(path)) throw new Error('Refusing to overwrite existing database');
mkdirSync(dirname(path), { recursive: true });
const db = openLegacy(path);
try {
  legacyPut(db, 'alpha', 'Original title');
  legacyPut(db, 'alpha', 'Desktop edit before upgrade');
  legacyPut(db, 'beta', 'Café — São Paulo');
  legacyPut(db, "id'with punctuation", '  Keep these spaces  ');
  legacyPut(db, 'zeta', 'Final catalog row');
} finally { db.close(); }
