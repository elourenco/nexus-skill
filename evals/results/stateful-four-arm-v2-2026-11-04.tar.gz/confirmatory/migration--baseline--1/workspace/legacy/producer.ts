import { Database } from 'bun:sqlite';

export function openLegacy(path: string): Database {
  const db = new Database(path, { create: true });
  db.exec('PRAGMA busy_timeout=1000');
  db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
  return db;
}

export function legacyRead(db: Database, id: string): { id: string; name: string; version: number } | null {
  const row = db.query('SELECT payload FROM legacy_items WHERE id = ?').get(id) as { payload: string } | null;
  return row ? { id, ...JSON.parse(row.payload) } : null;
}

export function legacyPut(db: Database, id: string, name: string) {
  return db.transaction(() => {
    const version = (legacyRead(db, id)?.version ?? 0) + 1;
    db.query('INSERT INTO legacy_items(id,payload) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload')
      .run(id, JSON.stringify({ name, version }));
    return { id, name, version };
  }).immediate();
}
