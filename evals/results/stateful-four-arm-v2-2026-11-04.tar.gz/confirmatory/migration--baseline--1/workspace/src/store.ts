import { Database } from 'bun:sqlite';

export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};

function validateId(id: string): void {
  if (typeof id !== 'string' || id.length === 0) throw new Error('Invalid item id');
}

function validateName(name: string): void {
  if (typeof name !== 'string' || name.length === 0) throw new Error('Invalid item name');
}

function validateItem(item: Item): Item {
  validateId(item.id);
  validateName(item.name);
  if (!Number.isSafeInteger(item.version) || item.version <= 0) {
    throw new Error('Invalid item version');
  }
  return item;
}

function parseLegacy(id: string, payload: string): Item {
  if (typeof payload !== 'string') throw new Error('Invalid legacy payload');
  const value = JSON.parse(payload);
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Invalid legacy item');
  }
  return validateItem({ id, name: value.name, version: value.version });
}

function latest(a: Item | null, b: Item | null): Item | null {
  if (!a) return b;
  if (!b) return a;
  if (a.version === b.version && a.name !== b.name) {
    throw new Error(`Conflicting item versions for ${a.id}`);
  }
  return a.version >= b.version ? a : b;
}

function writeTyped(db: Database, item: Item): void {
  db.query(`INSERT INTO items(id,name,version) VALUES(?,?,?)
    ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version`)
    .run(item.id, item.name, item.version);
}

export function openStore(path: string): Database {
  const db = new Database(path, { create: true });
  try {
    db.exec('PRAGMA busy_timeout=1000');
    db.transaction(() => {
      db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
      db.exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)');
    }).immediate();
    return db;
  } catch (error) {
    db.close();
    throw error;
  }
}

export function readItem(db: Database, id: string): Item | null {
  validateId(id);
  // One statement gives both formats the same committed SQLite snapshot.
  const rows = db.query(`SELECT id,name,version,NULL AS payload,0 AS legacy FROM items WHERE id=?
    UNION ALL SELECT id,NULL,NULL,payload,1 FROM legacy_items WHERE id=?`).all(id, id) as {
    id: string; name: string; version: number; payload: string; legacy: number;
  }[];
  let result: Item | null = null;
  for (const row of rows) {
    const item = row.legacy
      ? parseLegacy(row.id, row.payload)
      : validateItem({ id: row.id, name: row.name, version: row.version });
    result = latest(result, item);
  }
  return result;
}

export function putItem(db: Database, id: string, name: string): Item {
  validateId(id);
  validateName(name);
  // Acquire the writer lock before choosing a version, including across handles.
  return db.transaction(() => {
    const item = validateItem({ id, name, version: (readItem(db, id)?.version ?? 0) + 1 });
    writeTyped(db, item);
    db.query(`INSERT INTO legacy_items(id,payload) VALUES(?,?)
      ON CONFLICT(id) DO UPDATE SET payload=excluded.payload`)
      .run(id, JSON.stringify({ name, version: item.version }));
    return item;
  }).immediate();
}

export function migrate(db: Database, options: MigrationOptions = {}): { scanned: number } {
  const batchSize = options.batchSize === undefined ? 50 : options.batchSize;
  if (!Number.isSafeInteger(batchSize) || batchSize <= 0) {
    throw new Error('Invalid migration batch size');
  }
  let scanned = 0;
  let cursor: string | undefined;
  // Restart the keyset scan on every call: old desktops can edit any earlier id.
  for (;;) {
    const rows = db.transaction(() => {
      const batch = (cursor === undefined
        ? db.query('SELECT id,payload FROM legacy_items ORDER BY id LIMIT ?').all(batchSize)
        : db.query('SELECT id,payload FROM legacy_items WHERE id > ? ORDER BY id LIMIT ?').all(cursor, batchSize)
      ) as { id: string; payload: string }[];
      for (const row of batch) {
        const source = parseLegacy(row.id, row.payload);
        const current = readItem(db, row.id);
        const winner = latest(current, source)!;
        writeTyped(db, winner);
      }
      return batch;
    }).immediate();
    if (rows.length === 0) break;
    cursor = rows[rows.length - 1]!.id;
    scanned += rows.length;
    options.afterBatch?.({ scanned });
  }
  return { scanned };
}
