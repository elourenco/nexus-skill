import { expect, test } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore, putItem, readItem, migrate } from '../src/store';
import { legacyPut, legacyRead } from '../legacy/producer';

function withStore(run: (db: ReturnType<typeof openStore>) => void) {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-public-'));
  const db = openStore(join(dir, 'catalog.sqlite'));
  try { run(db); } finally { db.close(); rmSync(dir, { recursive: true, force: true }); }
}

test('new writer round trip', () => withStore(db => {
  expect(putItem(db, 'a', 'Alpha')).toEqual({ id: 'a', name: 'Alpha', version: 1 });
  expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Alpha', version: 1 });
  expect(readItem(db, 'missing')).toBeNull();
}));

test('legacy data remains readable by installed desktop after migration', () => withStore(db => {
  legacyPut(db, 'a', 'Alpha');
  expect(migrate(db)).toEqual({ scanned: 1 });
  expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Alpha', version: 1 });
  expect(legacyRead(db, 'a')).toEqual({ id: 'a', name: 'Alpha', version: 1 });
}));
