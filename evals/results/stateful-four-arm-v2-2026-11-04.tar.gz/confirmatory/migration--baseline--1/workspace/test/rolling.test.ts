import { expect, test } from 'bun:test';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore, readItem, putItem, migrate } from '../src/store';
import { legacyPut, legacyRead, openLegacy } from '../legacy/producer';

type DB = ReturnType<typeof openStore>;
function fixture(run: (db: DB, path: string) => void, seed = false) {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-rolling-'));
  const path = join(dir, 'catalog.sqlite');
  if (seed) copyFileSync(new URL('../data/legacy.sqlite', import.meta.url), path);
  const db = openStore(path);
  try { run(db, path); } finally { db.close(); rmSync(dir, { recursive: true, force: true }); }
}
function rawLegacy(db: DB, id: string, payload: string) {
  db.query('INSERT OR REPLACE INTO legacy_items(id,payload) VALUES(?,?)').run(id, payload);
}
function typed(db: DB, id: string) {
  return db.query('SELECT id,name,version FROM items WHERE id=?').get(id);
}

test('real legacy database survives interrupted upgrade and reopen byte for byte', () => fixture((db, path) => {
  const before = db.query('SELECT * FROM legacy_items ORDER BY id').all();
  const callbacks: number[] = [];
  expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => {
    callbacks.push(scanned);
    throw new Error('interrupted');
  } })).toThrow('interrupted');
  expect(callbacks).toEqual([2]);
  expect(db.query('SELECT count(*) AS n FROM items').get()).toEqual({ n: 2 });
  const reopened = openStore(path);
  try {
    expect(migrate(reopened, { batchSize: 2, afterBatch: ({ scanned }) => callbacks.push(scanned) })).toEqual({ scanned: before.length });
    expect(callbacks).toEqual([2, 2, 4]);
    expect(reopened.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(before);
    for (const row of before as { id: string }[]) {
      expect(readItem(reopened, row.id)).toEqual(legacyRead(reopened, row.id));
    }
  } finally { reopened.close(); }
}, true));

test('old and new handles see writes before, between and after migrations', () => fixture((db, path) => {
  const old = openLegacy(path);
  try {
    legacyPut(old, 'a', 'desktop');
    legacyPut(old, 'z', 'last');
    expect(readItem(db, 'a')?.name).toBe('desktop');
    expect(putItem(db, 'a', '  Café 🌍  ')).toEqual({ id: 'a', name: '  Café 🌍  ', version: 2 });
    expect(legacyRead(old, 'a')).toEqual(readItem(db, 'a'));
    const callbacks: number[] = [];
    migrate(db, { batchSize: 1, afterBatch: ({ scanned }) => {
      callbacks.push(scanned);
      if (scanned === 1) {
        legacyPut(old, 'a', 'edited behind cursor');
        legacyPut(old, 'z', 'edited ahead of cursor');
      }
    } });
    expect(callbacks).toEqual([1, 2]);
    expect(readItem(db, 'a')?.name).toBe('edited behind cursor');
    expect(typed(db, 'z')).toEqual(legacyRead(old, 'z'));
    migrate(db);
    expect(typed(db, 'a')).toEqual(legacyRead(old, 'a'));
    legacyPut(old, 'a', 'after migration');
    expect(putItem(db, 'a', 'new edit').version).toBe(5);
    expect(legacyRead(old, 'a')).toEqual(readItem(db, 'a'));
  } finally { old.close(); }
}));

test('higher versions win without version changes; divergent equal versions throw', () => fixture(db => {
  db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'typed newer', 8);
  rawLegacy(db, 'a', '{"name":"old","version":2}');
  expect(readItem(db, 'a')?.version).toBe(8);
  migrate(db);
  expect(typed(db, 'a')).toEqual({ id: 'a', name: 'typed newer', version: 8 });
  expect(legacyRead(db, 'a')?.version).toBe(2);
  expect(putItem(db, 'a', 'next').version).toBe(9);
  rawLegacy(db, 'a', '{"name":"conflict","version":9}');
  expect(() => readItem(db, 'a')).toThrow('Conflicting');
  expect(() => putItem(db, 'a', 'overwrite')).toThrow('Conflicting');
  expect(() => migrate(db)).toThrow('Conflicting');
}));

test('bad row rolls back its whole batch, preserves committed batches and can be repaired', () => fixture(db => {
  for (const id of ['a', 'b', 'c']) legacyPut(db, id, id);
  rawLegacy(db, 'd', '{broken');
  const before = db.query('SELECT * FROM legacy_items ORDER BY id').all();
  const callbacks: number[] = [];
  expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => callbacks.push(scanned) })).toThrow();
  expect(callbacks).toEqual([2]);
  expect(typed(db, 'a')).not.toBeNull();
  expect(typed(db, 'b')).not.toBeNull();
  expect(typed(db, 'c')).toBeNull();
  expect(typed(db, 'd')).toBeNull();
  expect(db.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(before);
  rawLegacy(db, 'd', '{"name":"fixed","version":1}');
  expect(migrate(db, { batchSize: 2 })).toEqual({ scanned: 4 });
  expect(readItem(db, 'd')?.name).toBe('fixed');
}));

test('failed publishing rolls back typed write, including updates', () => fixture(db => {
  putItem(db, 'a', 'before');
  db.exec(`CREATE TRIGGER fail_legacy_update BEFORE UPDATE ON legacy_items
    BEGIN SELECT RAISE(ABORT, 'disk failure simulation'); END;
    CREATE TRIGGER fail_legacy_insert BEFORE INSERT ON legacy_items
    WHEN NEW.id = 'b' BEGIN SELECT RAISE(ABORT, 'disk failure simulation'); END;`);
  expect(() => putItem(db, 'a', 'after')).toThrow();
  expect(typed(db, 'a')).toEqual({ id: 'a', name: 'before', version: 1 });
  expect(legacyRead(db, 'a')?.name).toBe('before');
  expect(() => putItem(db, 'b', 'new')).toThrow();
  expect(typed(db, 'b')).toBeNull();
  expect(legacyRead(db, 'b')).toBeNull();
}));

test('invalid batch sizes reject before mutation and empty migration has no callback', () => fixture(db => {
  let calls = 0;
  expect(migrate(db, { afterBatch: () => calls++ })).toEqual({ scanned: 0 });
  expect(calls).toBe(0);
  legacyPut(db, 'a', 'a');
  for (const batchSize of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, null, '2']) {
    expect(() => migrate(db, { batchSize: batchSize as number })).toThrow();
    expect(typed(db, 'a')).toBeNull();
  }
}));

test('validate API inputs, unsafe increments and persisted data even on the stale side', () => fixture(db => {
  for (const id of ['', null, 1]) {
    expect(() => readItem(db, id as string)).toThrow();
    expect(() => putItem(db, id as string, 'name')).toThrow();
  }
  for (const name of ['', null, 1]) expect(() => putItem(db, 'a', name as string)).toThrow();
  for (const payload of ['null', '[]', 'false', '{}', '{',
    '{"name":"","version":1}', '{"name":1,"version":1}',
    ...[0, -1, 1.5, Number.MAX_SAFE_INTEGER + 1, '1', null].map(version => JSON.stringify({ name: 'a', version }))]) {
    rawLegacy(db, 'a', payload);
    expect(() => readItem(db, 'a')).toThrow();
    expect(() => putItem(db, 'a', 'repair')).toThrow();
    expect(() => migrate(db)).toThrow();
    expect(typed(db, 'a')).toBeNull();
  }
  rawLegacy(db, 'a', JSON.stringify({ name: 'limit', version: Number.MAX_SAFE_INTEGER }));
  expect(() => putItem(db, 'a', 'overflow')).toThrow();
  expect(typed(db, 'a')).toBeNull();
  db.query('INSERT INTO items VALUES(?,?,?)').run('a', '', 1);
  expect(() => readItem(db, 'a')).toThrow();
  expect(() => migrate(db)).toThrow();
}));

test('default batching, sparse punctuation ids, Unicode and large names', () => fixture(db => {
  const name = '  🌍 Café\n'.repeat(20_000);
  for (let i = 0; i < 103; i++) legacyPut(db, `id '${i * 19} 漢`, name);
  const seen: number[] = [];
  expect(migrate(db, { afterBatch: ({ scanned }) => seen.push(scanned) })).toEqual({ scanned: 103 });
  expect(seen).toEqual([50, 100, 103]);
  expect(readItem(db, "id '0 漢")?.name).toBe(name);
  expect(migrate(db, { batchSize: 1000 })).toEqual({ scanned: 103 });
}));

test('two upgraded handles allocate versions from the latest state of both formats', () => fixture((db, path) => {
  const second = openStore(path);
  const old = openLegacy(path);
  try {
    expect(putItem(db, 'a', 'first').version).toBe(1);
    expect(putItem(second, 'a', 'second').version).toBe(2);
    expect(legacyPut(old, 'a', 'third').version).toBe(3);
    expect(putItem(db, 'a', 'fourth').version).toBe(4);
    expect(readItem(second, 'a')).toEqual(legacyRead(old, 'a'));
    expect(readItem(second, 'a')?.name).toBe('fourth');
  } finally { second.close(); old.close(); }
}));

test('invalid persisted legacy ids abort the batch without discarding source bytes', () => fixture(db => {
  rawLegacy(db, '', '{"name":"bad id","version":1}');
  legacyPut(db, 'z', 'valid');
  const before = db.query('SELECT * FROM legacy_items ORDER BY id').all();
  expect(() => migrate(db)).toThrow('Invalid item id');
  expect(db.query('SELECT * FROM items').all()).toEqual([]);
  expect(db.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(before);
}));
