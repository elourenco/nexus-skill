# Catalog rolling upgrade

Run `bun test test`. Bun is available at `/Users/elourenco/.bun/bin/bun`.

Only `src/store.ts` is production code to complete. The public API is synchronous:

```ts
import type { Database } from 'bun:sqlite';
export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};
export function openStore(path: string): Database;
export function readItem(db: Database, id: string): Item | null;
export function putItem(db: Database, id: string, name: string): Item;
export function migrate(db: Database, options?: MigrationOptions): { scanned: number };
```

`openStore` opens/initializes the same SQLite file and returns a handle the caller closes. New records use `items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)`. Existing legacy data is in the table documented under `legacy/`. Table and column names are persistence interfaces consumed by integrations. Do not remove either table or legacy rows.

`readItem` returns the latest committed item from either producer, or null when absent. `putItem` chooses the next version from the latest committed state for that id and returns the stored item. The name is an opaque nonempty string: preserve spaces and Unicode exactly. Valid ids are nonempty strings. Versions are positive safe integers. Invalid input or invalid persisted item data throws; never silently discard or normalize it.

`migrate` visits legacy rows in ascending id order in batches (default 50), copying valid items to typed storage. `scanned` counts visited legacy rows, including rows for which typed storage was already current. The optional `afterBatch` callback runs after each nonempty committed batch with cumulative `scanned`, outside its transaction. It may throw to simulate process interruption; propagate that error. `batchSize` must be a positive safe integer and invalid values must throw before mutation. Callers may reopen the database and call migrate repeatedly. There is no requirement to expose or use a particular progress-marker design.

Operational expectations and coexistence details are in `legacy/INTEGRATION.md`. The callback is the only required failpoint. Do not add network access, background workers, or a new API. The service serializes each synchronous API call, but two handles may be open on the same file; afterBatch may perform a legacy write through another handle.

`data/legacy.sqlite` is a real database created by the old writer and contains only the legacy table. To generate another copy, run `bun legacy/seed.ts /path/to/fresh.sqlite`. The seeder refuses to overwrite an existing file.
