# Catalog upgrade

Source of truth: README.md and legacy/INTEGRATION.md. Single-session implementation.
Method: frozen ask-matt → grill-with-docs → implement → tdd → code-review.
Existing scoped approval settles product decisions and test seams; no further approval needed.
Local markdown tracking; no external tracker, Git operations, installation changes or delegation.

Approved seams: exported store API, shipped legacy producer, and documented SQLite persistence interfaces.
Use real temporary SQLite files. SQL fixture setup/failure injection observes the public persistence contract.

Design: reconcile both valid records by version; equal divergent versions throw. A single read statement
provides one snapshot. Immediate write transactions serialize version allocation and dual-format writes.
Migration uses keyset pagination and immediate transactions per bounded batch, never deletes legacy bytes,
and restarts each invocation from the beginning so later old-writer edits are not skipped forever.

Initial validation: public suite has 1 pass / 1 fail (migration deletes legacy row).
Independent Standards/Spec review: pending; prohibited by single-agent scope. Self-check is not independent review.

Completed validation: `bun test test` on Bun 1.4.2: 35 passed, 0 failed, 196 assertions.
Additional tests are in test/rolling.test.ts; original tests, legacy sources, README and data are unchanged.
Verified interrupted/reopened migrations, malformed-batch rollback and repair, byte preservation,
legacy/new-writer alternation, equal-version corruption, stale-source validation, invalid inputs,
version overflow, second-write storage failure, default/partial batches, sparse/Unicode ids and large names.
Copied the shipped legacy.sqlite and generated a fresh legacy-only database with the unchanged seeder;
both migrate with all four expected items and unchanged legacy payload bytes.
Three real Bun processes (one legacy, two upgraded) completed 120 writes to one id: version 1 → 121.
This is a local contention regression, not a load benchmark or power-loss/durability experiment.

Self-check against Standards: parameterized SQL, shared validation/reconciliation, bounded keyset reads,
no dependencies, retained synchronous API. Removed unnecessary nullable winner assertion during review.
Self-check against Spec: both representations validated; version choice and publication in an immediate
transaction; migration commits by batch and invokes callback afterward; each invocation rescans old ids.
Independent Standards/Spec review remains pending; no reviewers were fabricated or delegated.
No standalone TypeScript checker is configured in the fixture; Bun execution does not establish static type safety.

Retrospective (current session only): the initial public suite caught destructive migration, but missed
new-to-old publication and batch recovery. The added integration tests now cover these seams. A future
project CI should run the existing test command; infrastructure changes are outside this fixture task.
Frozen method and global configuration were not modified. No commit or external action was performed.
