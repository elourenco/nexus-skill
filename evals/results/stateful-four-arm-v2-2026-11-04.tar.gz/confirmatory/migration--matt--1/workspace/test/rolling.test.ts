import { expect, test } from 'bun:test';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore, readItem, putItem, migrate } from '../src/store';
import { openLegacy, legacyPut, legacyRead } from '../legacy/producer';

function fixture(run: (path: string) => void) {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-rolling-'));
  try { run(join(dir, 'catalog.sqlite')); }
  finally { rmSync(dir, { recursive: true, force: true }); }
}

test('read sees committed desktop edits before any migration', () => fixture(path => {
  const legacy = openLegacy(path);
  legacyPut(legacy, "雪'", '  Café 🌿  ');
  const db = openStore(path);
  try {
    expect(readItem(db, "雪'")).toEqual({ id: "雪'", name: '  Café 🌿  ', version: 1 });
    legacyPut(legacy, "雪'", 'Desktop revision');
    expect(readItem(db, "雪'")).toEqual({ id: "雪'", name: 'Desktop revision', version: 2 });
  } finally { db.close(); legacy.close(); }
}));

test('both writers alternate edits with monotonically increasing versions', () => fixture(path => {
  const db = openStore(path);
  const desktop = openLegacy(path);
  try {
    legacyPut(desktop, 'a', 'Desktop');
    expect(putItem(db, 'a', '  Upgraded 雪  ')).toEqual({ id: 'a', name: '  Upgraded 雪  ', version: 2 });
    expect(legacyRead(desktop, 'a')).toEqual({ id: 'a', name: '  Upgraded 雪  ', version: 2 });
    legacyPut(desktop, 'a', 'Desktop again');
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Desktop again', version: 3 });
    expect(putItem(db, 'a', 'Final')).toEqual({ id: 'a', name: 'Final', version: 4 });
    expect(legacyRead(desktop, 'a')).toEqual({ id: 'a', name: 'Final', version: 4 });
  } finally { desktop.close(); db.close(); }
}));

test('committed batches survive interruption and reopening without losing desktop names', () => fixture(path => {
  let db = openStore(path);
  const desktop = openLegacy(path);
  try {
    legacyPut(desktop, 'a', 'Alpha');
    legacyPut(desktop, 'b', 'Beta');
    legacyPut(desktop, 'z', 'Zeta');
    const interruption = new Error('Process interrupted');
    expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => {
      expect(scanned).toBe(2);
      // Must succeed through another handle: callback is outside the write transaction.
      legacyPut(desktop, 'a', 'Edited between batches');
      throw interruption;
    } })).toThrow(interruption);
    expect(db.query('SELECT id FROM items ORDER BY id').all()).toEqual([{ id: 'a' }, { id: 'b' }]);
    expect(legacyRead(desktop, 'b')).toEqual({ id: 'b', name: 'Beta', version: 1 });
    db.close();
    db = openStore(path);
    const batches: number[] = [];
    expect(migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => batches.push(scanned) })).toEqual({ scanned: 3 });
    expect(batches).toEqual([2, 3]);
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Edited between batches', version: 2 });
    expect(legacyRead(desktop, 'z')).toEqual({ id: 'z', name: 'Zeta', version: 1 });
    expect(migrate(db)).toEqual({ scanned: 3 });
  } finally { desktop.close(); db.close(); }
}));

test('malformed row rolls back its whole batch, preserves original bytes, and permits repair', () => fixture(path => {
  const db = openStore(path);
  try {
    for (const id of ['a', 'b', 'c', 'd']) legacyPut(db, id, id.toUpperCase());
    db.query('UPDATE legacy_items SET payload=? WHERE id=?').run('{broken', 'd');
    const original = db.query('SELECT * FROM legacy_items ORDER BY id').all();
    const callbacks: number[] = [];
    expect(() => migrate(db, { batchSize: 2, afterBatch: ({ scanned }) => callbacks.push(scanned) })).toThrow();
    expect(callbacks).toEqual([2]);
    expect(db.query('SELECT id FROM items ORDER BY id').all()).toEqual([{ id: 'a' }, { id: 'b' }]);
    expect(db.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(original);
    db.query('UPDATE legacy_items SET payload=? WHERE id=?').run('{ "name": "D repaired", "version": 1 }', 'd');
    expect(migrate(db, { batchSize: 2 })).toEqual({ scanned: 4 });
    expect(readItem(db, 'd')).toEqual({ id: 'd', name: 'D repaired', version: 1 });
  } finally { db.close(); }
}));

test('typed-ahead data cannot be reverted and old edits remain visible after migration completes', () => fixture(path => {
  const db = openStore(path);
  try {
    legacyPut(db, 'a', 'Older');
    db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'Ahead', 8);
    expect(migrate(db)).toEqual({ scanned: 1 });
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Ahead', version: 8 });
    expect(putItem(db, 'a', 'Publish')).toEqual({ id: 'a', name: 'Publish', version: 9 });
    legacyPut(db, 'a', 'Late desktop');
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Late desktop', version: 10 });
    expect(migrate(db)).toEqual({ scanned: 1 });
    expect(db.query('SELECT * FROM items').get()).toEqual({ id: 'a', name: 'Late desktop', version: 10 });
  } finally { db.close(); }
}));

test('divergent equal versions throw from every API without mutation', () => fixture(path => {
  const db = openStore(path);
  try {
    legacyPut(db, 'a', 'Desktop');
    db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'Conflicting', 1);
    expect(() => readItem(db, 'a')).toThrow();
    expect(() => putItem(db, 'a', 'Overwrite')).toThrow();
    expect(() => migrate(db)).toThrow();
    expect(legacyRead(db, 'a')).toEqual({ id: 'a', name: 'Desktop', version: 1 });
    expect(db.query('SELECT * FROM items').get()).toEqual({ id: 'a', name: 'Conflicting', version: 1 });
  } finally { db.close(); }
}));

test('dual-format writes roll back when the second format rejects a change', () => fixture(path => {
  const db = openStore(path);
  try {
    putItem(db, 'a', 'Original');
    db.exec(`CREATE TRIGGER reject_desktop_update BEFORE UPDATE ON legacy_items
      BEGIN SELECT RAISE(ABORT, 'storage rejected update'); END;
      CREATE TRIGGER reject_desktop_insert BEFORE INSERT ON legacy_items WHEN NEW.id = 'new'
      BEGIN SELECT RAISE(ABORT, 'storage rejected insert'); END;`);
    expect(() => putItem(db, 'a', 'Rejected')).toThrow('storage rejected update');
    expect(() => putItem(db, 'new', 'Rejected')).toThrow('storage rejected insert');
    expect(readItem(db, 'a')).toEqual({ id: 'a', name: 'Original', version: 1 });
    expect(legacyRead(db, 'a')).toEqual({ id: 'a', name: 'Original', version: 1 });
    expect(readItem(db, 'new')).toBeNull();
    expect(db.query('SELECT * FROM items WHERE id=?').get('a')).toEqual({ id: 'a', name: 'Original', version: 1 });
  } finally { db.close(); }
}));

test('invalid batch sizes reject before any writes or callbacks', () => fixture(path => {
  const db = openStore(path);
  try {
    legacyPut(db, 'a', 'Alpha');
    for (const batchSize of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, null, '2']) {
      expect(() => migrate(db, { batchSize: batchSize as number, afterBatch: () => { throw new Error('callback ran'); } })).toThrow('batchSize');
      expect(db.query('SELECT count(*) AS count FROM items').get()).toEqual({ count: 0 });
      expect(legacyRead(db, 'a')).toEqual({ id: 'a', name: 'Alpha', version: 1 });
    }
  } finally { db.close(); }
}));

test('invalid public inputs and version exhaustion leave storage unchanged', () => fixture(path => {
  const db = openStore(path);
  try {
    for (const id of ['', null, 42, {}]) {
      expect(() => readItem(db, id as string)).toThrow();
      expect(() => putItem(db, id as string, 'Name')).toThrow();
    }
    for (const name of ['', null, 42, {}]) expect(() => putItem(db, 'a', name as string)).toThrow();
    expect(readItem(db, 'a')).toBeNull();
    db.query('INSERT INTO legacy_items VALUES(?,?)').run('max', JSON.stringify({ name: 'Maximum', version: Number.MAX_SAFE_INTEGER }));
    expect(() => putItem(db, 'max', 'Overflow')).toThrow();
    expect(legacyRead(db, 'max')).toEqual({ id: 'max', name: 'Maximum', version: Number.MAX_SAFE_INTEGER });
    expect(db.query('SELECT count(*) AS count FROM items').get()).toEqual({ count: 0 });
  } finally { db.close(); }
}));

for (const payload of ['null', '[]', '{}', '"text"', '{',
  '{"name":"","version":1}', '{"name":42,"version":1}', '{"name":"X","version":"1"}',
  '{"name":"X","version":0}', '{"name":"X","version":-1}', '{"name":"X","version":1.5}',
  '{"name":"X","version":9007199254740992}']) {
  test(`invalid legacy data is rejected even behind newer typed data: ${payload}`, () => fixture(path => {
    const db = openStore(path);
    try {
      db.query('INSERT INTO legacy_items VALUES(?,?)').run('a', payload);
      db.query('INSERT INTO items VALUES(?,?,?)').run('a', 'Valid typed', 20);
      expect(() => readItem(db, 'a')).toThrow();
      expect(() => putItem(db, 'a', 'Overwrite')).toThrow();
      expect(() => migrate(db)).toThrow();
      expect(db.query('SELECT payload FROM legacy_items').get()).toEqual({ payload });
    } finally { db.close(); }
  }));
}

for (const [name, version] of [['', 1], ['Bad version', 0], ['Fraction', 1.5], ['Unsafe', 9007199254740992]]) {
  test(`invalid typed data is rejected: ${name}/${version}`, () => fixture(path => {
    const db = openStore(path);
    try {
      legacyPut(db, 'a', 'Valid legacy');
      db.query('INSERT INTO items VALUES(?,?,?)').run('a', name!, version!);
      expect(() => readItem(db, 'a')).toThrow();
      expect(() => putItem(db, 'a', 'Overwrite')).toThrow();
      expect(() => migrate(db)).toThrow();
      expect(legacyRead(db, 'a')).toEqual({ id: 'a', name: 'Valid legacy', version: 1 });
    } finally { db.close(); }
  }));
}

test('default batches are bounded, ordered, include final partial batch, and preserve large names', () => fixture(path => {
  const db = openStore(path);
  try {
    const largeName = '  Café 雪 🌿  '.repeat(10000);
    for (let n = 120; n >= 0; n--) legacyPut(db, `id-${String(n * 17).padStart(5, '0')}`, largeName);
    const batches: number[] = [];
    expect(migrate(db, { afterBatch: ({ scanned }) => {
      batches.push(scanned);
      if (scanned === 50) {
        expect(db.query('SELECT id FROM items ORDER BY id DESC LIMIT 1').get()).toEqual({ id: 'id-00833' });
      }
    } })).toEqual({ scanned: 121 });
    expect(batches).toEqual([50, 100, 121]);
    expect(readItem(db, 'id-02040')).toEqual({ id: 'id-02040', name: largeName, version: 1 });
    expect(legacyRead(db, 'id-02040')).toEqual({ id: 'id-02040', name: largeName, version: 1 });
  } finally { db.close(); }
}));

test('migration notices edits ahead of its cursor and retries edits behind it on the next call', () => fixture(path => {
  const db = openStore(path);
  const desktop = openLegacy(path);
  try {
    for (const id of ["a'", 'm', '雪']) legacyPut(desktop, id, id);
    const counts: number[] = [];
    migrate(db, { batchSize: 1, afterBatch: ({ scanned }) => {
      counts.push(scanned);
      if (scanned === 1) {
        legacyPut(desktop, "a'", 'Behind cursor');
        legacyPut(desktop, '雪', 'Ahead of cursor');
        legacyPut(desktop, '0', 'Inserted behind cursor');
      }
    } });
    expect(counts).toEqual([1, 2, 3]);
    expect(db.query('SELECT name,version FROM items WHERE id=?').get('雪')).toEqual({ name: 'Ahead of cursor', version: 2 });
    expect(readItem(db, "a'")).toEqual({ id: "a'", name: 'Behind cursor', version: 2 });
    expect(migrate(db, { batchSize: 1 })).toEqual({ scanned: 4 });
    expect(db.query('SELECT * FROM items WHERE id=?').get('0')).toEqual({ id: '0', name: 'Inserted behind cursor', version: 1 });
    expect(db.query('SELECT name,version FROM items WHERE id=?').get("a'")).toEqual({ name: 'Behind cursor', version: 2 });
  } finally { desktop.close(); db.close(); }
}));

test('empty migration has no callbacks and successful migration leaves legacy bytes untouched', () => fixture(path => {
  const db = openStore(path);
  try {
    const counts: number[] = [];
    expect(migrate(db, { afterBatch: ({ scanned }) => counts.push(scanned) })).toEqual({ scanned: 0 });
    expect(counts).toEqual([]);
    const payload = '{ "version": 7, "name": "  雪  ", "desktopExtra": true }';
    db.query('INSERT INTO legacy_items VALUES(?,?)').run("id'punctuation", payload);
    expect(migrate(db, { batchSize: 1 })).toEqual({ scanned: 1 });
    expect(db.query('SELECT payload FROM legacy_items').get()).toEqual({ payload });
    expect(readItem(db, "id'punctuation")).toEqual({ id: "id'punctuation", name: '  雪  ', version: 7 });
  } finally { db.close(); }
}));

for (const id of ['', null]) {
  test(`migration rejects invalid persisted id ${JSON.stringify(id)} atomically`, () => fixture(path => {
    const db = openStore(path);
    try {
      db.query('INSERT INTO legacy_items VALUES(?,?)').run(id, '{"name":"Name","version":1}');
      expect(() => migrate(db)).toThrow();
      expect(db.query('SELECT count(*) AS count FROM items').get()).toEqual({ count: 0 });
      expect(db.query('SELECT count(*) AS count FROM legacy_items').get()).toEqual({ count: 1 });
    } finally { db.close(); }
  }));
}

test('concurrent compatible processes allocate versions without lost successful writes', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'catalog-concurrent-'));
  const path = join(dir, 'catalog.sqlite');
  const db = openStore(path);
  const children: ReturnType<typeof Bun.spawn>[] = [];
  try {
    putItem(db, 'shared', 'Initial');
    const storeModule = JSON.stringify(new URL('../src/store.ts', import.meta.url).href);
    const legacyModule = JSON.stringify(new URL('../legacy/producer.ts', import.meta.url).href);
    for (let worker = 0; worker < 3; worker++) {
      const source = `
        import { openStore, putItem } from ${storeModule};
        import { legacyPut } from ${legacyModule};
        const db = openStore(${JSON.stringify(path)});
        await Bun.stdin.text();
        try {
          for (let n = 0; n < 40; n++) {
            ${worker === 0 ? 'legacyPut' : 'putItem'}(db, 'shared', '${worker}:' + n);
          }
        } finally { db.close(); }
      `;
      children.push(Bun.spawn([process.execPath, '-e', source], { stdin: 'pipe', stdout: 'pipe', stderr: 'pipe' }));
    }
    for (const child of children) (child.stdin as { end: (data: string) => void }).end('go');
    const results = await Promise.all(children.map(async child => ({
      exit: await child.exited,
      stderr: await new Response(child.stderr as ReadableStream).text(),
    })));
    expect(results).toEqual([{ exit: 0, stderr: '' }, { exit: 0, stderr: '' }, { exit: 0, stderr: '' }]);
    expect(readItem(db, 'shared')?.version).toBe(121);
    expect(legacyRead(db, 'shared')).toEqual(readItem(db, 'shared'));
    expect(migrate(db)).toEqual({ scanned: 1 });
  } finally {
    for (const child of children) { child.kill(); await child.exited; }
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
}, 10000);

for (const source of ['shipped', 'seeded']) {
  test(`migrates the ${source} legacy-only database without changing desktop results`, () => fixture(path => {
    if (source === 'shipped') {
      copyFileSync(new URL('../data/legacy.sqlite', import.meta.url), path);
    } else {
      const seeded = Bun.spawnSync([process.execPath, new URL('../legacy/seed.ts', import.meta.url).pathname, path]);
      expect(seeded.exitCode).toBe(0);
    }
    const db = openStore(path);
    try {
      const original = db.query('SELECT * FROM legacy_items ORDER BY id').all();
      expect(migrate(db, { batchSize: 3 })).toEqual({ scanned: 4 });
      for (const item of [
        { id: 'alpha', name: 'Desktop edit before upgrade', version: 2 },
        { id: 'beta', name: 'Café — São Paulo', version: 1 },
        { id: "id'with punctuation", name: '  Keep these spaces  ', version: 1 },
        { id: 'zeta', name: 'Final catalog row', version: 1 },
      ]) {
        expect(readItem(db, item.id)).toEqual(item);
        expect(legacyRead(db, item.id)).toEqual(item);
      }
      expect(db.query('SELECT * FROM legacy_items ORDER BY id').all()).toEqual(original);
    } finally { db.close(); }
  }));
}
