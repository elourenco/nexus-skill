# Catalog

A shared catalog edited by installed desktop versions during a rolling upgrade.

## Language

**Item**: A catalog entry identified by a nonempty id, with an opaque nonempty name and positive safe integer version.

**Latest item**: The valid entry with the highest version for an id across producers. Equal versions with different names are corruption.

**Migration batch**: A bounded group of legacy entries copied as one recovery unit without changing their logical versions.
