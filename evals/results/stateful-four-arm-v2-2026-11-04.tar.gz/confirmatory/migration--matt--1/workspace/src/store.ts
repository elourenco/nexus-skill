import { Database } from 'bun:sqlite';

export type Item = { id: string; name: string; version: number };
export type MigrationOptions = {
  batchSize?: number;
  afterBatch?: (info: { scanned: number }) => void;
};

export function openStore(path: string): Database {
  const db = new Database(path, { create: true });
  db.exec('PRAGMA busy_timeout=1000');
  db.exec('CREATE TABLE IF NOT EXISTS legacy_items(id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
  db.exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL)');
  return db;
}

function requireText(value: unknown, field: string): asserts value is string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new Error(`${field} must be a nonempty string`);
  }
}

function itemFrom(id: unknown, name: unknown, version: unknown): Item {
  requireText(id, 'id');
  requireText(name, 'name');
  if (typeof version !== 'number' || !Number.isSafeInteger(version) || version <= 0) {
    throw new Error(`Invalid version for item ${id}`);
  }
  return { id, name, version };
}

function legacyItem(id: unknown, payload: unknown): Item {
  if (typeof payload !== 'string') throw new Error('Legacy payload must be JSON text');
  const value: unknown = JSON.parse(payload);
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Legacy payload must be an item object');
  }
  const fields = value as Record<string, unknown>;
  return itemFrom(id, fields.name, fields.version);
}

function latest(first: Item | null, second: Item): Item {
  if (!first) return second;
  if (first.version === second.version && first.name !== second.name) {
    throw new Error(`Conflicting names at version ${first.version} for item ${first.id}`);
  }
  return first.version >= second.version ? first : second;
}

export function readItem(db: Database, id: string): Item | null {
  requireText(id, 'id');
  // One statement keeps both representations in the same committed snapshot.
  const rows = db.query(`
    SELECT id, name, version, NULL AS payload, 0 AS legacy FROM items WHERE id = ?
    UNION ALL
    SELECT id, NULL, NULL, payload, 1 FROM legacy_items WHERE id = ?
  `).all(id, id) as {
    id: unknown; name: unknown; version: unknown; payload: unknown; legacy: number;
  }[];
  let result: Item | null = null;
  for (const row of rows) {
    const item = row.legacy
      ? legacyItem(row.id, row.payload)
      : itemFrom(row.id, row.name, row.version);
    result = latest(result, item);
  }
  return result;
}

function writeTyped(db: Database, item: Item): void {
  db.query(`INSERT INTO items(id,name,version) VALUES(?,?,?)
    ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version`)
    .run(item.id, item.name, item.version);
}

export function putItem(db: Database, id: string, name: string): Item {
  requireText(id, 'id');
  requireText(name, 'name');
  // Acquire the write lock before reading the version, including across handles.
  return db.transaction(() => {
    const version = (readItem(db, id)?.version ?? 0) + 1;
    const item = itemFrom(id, name, version);
    writeTyped(db, item);
    db.query(`INSERT INTO legacy_items(id,payload) VALUES(?,?)
      ON CONFLICT(id) DO UPDATE SET payload=excluded.payload`)
      .run(id, JSON.stringify({ name, version }));
    return item;
  }).immediate();
}

export function migrate(db: Database, options: MigrationOptions = {}): { scanned: number } {
  const batchSize = options.batchSize === undefined ? 50 : options.batchSize;
  if (!Number.isSafeInteger(batchSize) || batchSize <= 0) {
    throw new Error('batchSize must be a positive safe integer');
  }
  let scanned = 0;
  let cursor: string | undefined;
  while (true) {
    const batch = db.transaction(() => {
      // Start anew on every call: desktops may have edited ids behind an earlier cursor.
      const rows = (cursor === undefined
        ? db.query('SELECT id,payload FROM legacy_items ORDER BY id LIMIT ?').all(batchSize)
        : db.query('SELECT id,payload FROM legacy_items WHERE id > ? ORDER BY id LIMIT ?').all(cursor, batchSize)
      ) as { id: unknown; payload: unknown }[];
      let lastId: string | undefined;
      for (const row of rows) {
        const source = legacyItem(row.id, row.payload);
        const typed = db.query('SELECT id,name,version FROM items WHERE id = ?').get(source.id) as {
          id: unknown; name: unknown; version: unknown;
        } | null;
        const current = typed ? itemFrom(typed.id, typed.name, typed.version) : null;
        const winner = latest(current, source);
        if (!current || winner.version > current.version) writeTyped(db, winner);
        lastId = source.id;
      }
      return { count: rows.length, lastId };
    }).immediate();
    if (batch.count === 0) return { scanned };
    scanned += batch.count;
    cursor = batch.lastId;
    options.afterBatch?.({ scanned });
  }
}
