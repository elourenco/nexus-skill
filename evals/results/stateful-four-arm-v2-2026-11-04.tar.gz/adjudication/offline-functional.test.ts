import { test, expect, afterEach } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const { openServer, openClient } = await import(process.env.SYNC_MODULE ?? '../../fixtures/offline-sync/src/sync.ts');
const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function setup() {
  const root = mkdtempSync(join(tmpdir(), 'sync-oracle-')); roots.push(root);
  const serverRoot = join(root, 'server'); const server = openServer({ root: serverRoot });
  const clientRoot = join(root, 'client');
  const client = (deviceId = 'a', tenantId = 'one', transport = server.transport(tenantId)) =>
    openClient({ root: clientRoot, tenantId, deviceId, transport });
  return { root, serverRoot, server, clientRoot, client };
}
function barrier() {
  let release!: () => void; let entered!: () => void;
  const wait = new Promise<void>(r => { release = r; });
  const started = new Promise<void>(r => { entered = r; });
  return { release, entered, wait, started };
}

test('local records, outbox, sequence and logical clock survive reopen', async () => {
  const s = setup(); let c = s.client(); const first = c.put('note', 'offline');
  c = s.client(); expect(c.get('note')).toBe('offline'); expect(c.pending()).toEqual([first]);
  const second = c.put('other', 'two');
  expect(second.seq).toBe(first.seq + 1); expect(second.clock).toBe(first.clock + 1);
  expect(second.opId).not.toBe(first.opId); await c.sync();
  expect(s.server.get('one', 'note')).toBe('offline'); expect(c.pending()).toEqual([]);
});

test('accepted operation retried after lost acknowledgement is idempotent across both reopenings', async () => {
  const s = setup(); const base = s.server.transport('one');
  const c = s.client('a', 'one', { ...base, async apply(op: any) {
    await base.apply(op); throw new Error('ACK_LOST');
  } });
  const op = c.put('key', 'value'); await expect(c.sync()).rejects.toThrow('ACK_LOST');
  expect(c.pending()).toEqual([op]);
  const reopenedServer = openServer({ root: s.serverRoot });
  const reopenedClient = s.client('a', 'one', reopenedServer.transport('one'));
  expect(reopenedClient.pending()).toEqual([op]);
  await reopenedClient.sync();
  expect(reopenedClient.pending()).toEqual([]);
  expect((await reopenedServer.transport('one').pull(0)).operations).toEqual([op]);
});

test('partial batch failure persists only acknowledged removals and retries remaining operations', async () => {
  const s = setup(); const base = s.server.transport('one'); let calls = 0;
  const c = s.client('a', 'one', { ...base, async apply(op: any) {
    if (++calls === 2) throw new Error('OFFLINE'); await base.apply(op);
  } });
  c.put('first', '1'); const second = c.put('second', '2');
  await expect(c.sync()).rejects.toThrow('OFFLINE');
  expect(c.pending()).toEqual([second]);
  const reopened = s.client(); expect(reopened.pending()).toEqual([second]); await reopened.sync();
  expect((await base.pull(0)).operations).toHaveLength(2);
  expect(s.server.get('one', 'second')).toBe('2');
});

test('an old acknowledgement cannot erase a local edit made while transport is blocked', async () => {
  const s = setup(); const base = s.server.transport('one'); const gate = barrier();
  const c = s.client('a', 'one', { ...base, async apply(op: any) {
    await base.apply(op); gate.entered(); await gate.wait;
  } });
  c.put('key', 'old'); const syncing = c.sync(); await gate.started;
  const newer = c.put('key', 'new'); gate.release(); await syncing;
  expect(c.get('key')).toBe('new'); expect(c.pending()).toEqual([newer]);
  const reopened = s.client(); expect(reopened.pending()).toEqual([newer]); await reopened.sync();
  expect(s.server.get('one', 'key')).toBe('new');
});

test('overlapping sync calls share one flight; edits during pull remain pending and durable', async () => {
  const s = setup(); const base = s.server.transport('one'); const gate = barrier(); let applies = 0; let pulls = 0;
  const c = s.client('a', 'one', { async apply(op: any) { applies++; await base.apply(op); },
    async pull(cursor: number) { pulls++; const feed = await base.pull(cursor); gate.entered(); await gate.wait; return feed; } });
  c.put('key', 'first'); const a = c.sync(); const b = c.sync(); await gate.started;
  const next = c.put('key', 'second'); gate.release(); await Promise.all([a, b]);
  expect(applies).toBe(1); expect(pulls).toBe(1); expect(c.pending()).toEqual([next]);
  expect(s.client().get('key')).toBe('second');
});

test('equal-clock concurrent writes converge despite reverse delivery and duplicate sends', async () => {
  const s = setup(); const a = s.client('a'); const z = s.client('z');
  const low = a.put('key', 'a'); const high = z.put('key', 'z'); const t = s.server.transport('one');
  await t.apply(high); await t.apply(low); await t.apply(high);
  expect(s.server.get('one', 'key')).toBe('z'); expect((await t.pull(0)).operations).toHaveLength(2);
  const reversed = { ...t, async pull(cursor: number) { const f = await t.pull(cursor); return { ...f, operations: [...f.operations].reverse().concat(f.operations) }; } };
  const reader = s.client('reader', 'one', reversed); await reader.sync();
  await a.sync(); await z.sync();
  expect([a.get('key'), z.get('key'), reader.get('key')]).toEqual(['z', 'z', 'z']);
});

test('owner policy: delete wins a same-clock put/delete collision independently of device name', async () => {
  const s = setup(); const deleting = s.client('a'); const writing = s.client('z');
  const deletion = deleting.delete('key'); const insertion = writing.put('key', 'concurrent');
  const t = s.server.transport('one'); await t.apply(deletion); await t.apply(insertion);
  expect(s.server.get('one', 'key')).toBeUndefined();
  const reader = s.client('reader'); await reader.sync();
  expect(reader.get('key')).toBeUndefined(); expect(reader.list()).toEqual({});
  await writing.sync(); expect(writing.get('key')).toBeUndefined();
});

test('persisted tombstones reject delayed stale writes, while a later observed edit can recreate', async () => {
  const s = setup(); const a = s.client('a'); const original = a.put('key', 'old'); const deletion = a.delete('key');
  const stale = s.client('z').put('key', 'stale'); const t = s.server.transport('one');
  await t.apply(deletion); await t.apply(stale); await t.apply(original);
  const reader = s.client('reader'); await reader.sync(); expect(reader.get('key')).toBeUndefined();
  const reopened = s.client('reader'); expect(reopened.get('key')).toBeUndefined();
  const recreated = reopened.put('key', 'recreated'); expect(recreated.clock).toBeGreaterThan(deletion.clock);
  await reopened.sync(); expect(s.server.get('one', 'key')).toBe('recreated');
});

test('tenant identity scopes local state, server feed, operation identity and transport authority', async () => {
  const s = setup(); const one = s.client('same-device', 'one'); const two = s.client('same-device', 'two');
  const x = one.put('same-key', 'one'); const y = two.put('same-key', 'two');
  expect(one.get('same-key')).toBe('one'); expect(two.get('same-key')).toBe('two');
  expect(s.client('same-device', 'one').pending()).toEqual([x]);
  await expect(s.server.transport('two').apply(x)).rejects.toThrow('TENANT_MISMATCH');
  await one.sync(); await two.sync();
  expect((await s.server.transport('one').pull(0)).operations.map((op: any) => op.tenantId)).toEqual(['one']);
  expect(s.server.get('two', 'same-key')).toBe('two');
});

test('received clock and feed cursor survive reopening; distinct devices retain distinct queues', async () => {
  const s = setup(); const sender = s.client('sender');
  sender.put('key', '1'); sender.put('key', '2'); const last = sender.put('key', '3'); await sender.sync();
  const base = s.server.transport('one'); const reader = s.client('reader'); await reader.sync();
  let requested = -1;
  const reopened = s.client('reader', 'one', { ...base, async pull(cursor: number) { requested = cursor; return base.pull(cursor); } });
  const own = reopened.put('other', 'local'); expect(own.clock).toBeGreaterThan(last.clock);
  expect(s.client('sender').pending()).toEqual([]); await reopened.sync(); expect(requested).toBe(3);
  expect(reopened.get('key')).toBe('3');
});

test('failed pull preserves accepted sends and permits a later sync without replaying acknowledged work', async () => {
  const s = setup(); const base = s.server.transport('one'); let fail = true; let applies = 0;
  const remote = s.client('remote'); remote.put('remote', 'value'); await remote.sync();
  const c = s.client('local', 'one', { async apply(op: any) { applies++; await base.apply(op); },
    async pull(cursor: number) { if (fail) { fail = false; throw new Error('PULL_FAILED'); } return base.pull(cursor); } });
  c.put('local', 'value'); await expect(c.sync()).rejects.toThrow('PULL_FAILED');
  expect(c.pending()).toEqual([]); await c.sync(); expect(applies).toBe(1); expect(c.get('remote')).toBe('value');
});
