# Prototype handoff — older demo notes

The demo used one tenant and one phone, kept the app open throughout, and called sync from a button after typing. This is the first file-backed version of an earlier in-memory sketch. Its data files are implementation details and there is no installed data migration requirement for the pilot.

The web prototype used arrival order when merging, while the phone design discussed logical clocks. Both assumed ordinary requests would be acknowledged. The README caller contract is the integration target where it is more specific than this historical note.

The team noticed an unresolved product issue: if a delete and a write have the same logical clock, device-name ordering alone may resurrect a note the user intended to remove. The owner should choose whether deletion has priority in that tie. This is not a request to add a conflict dialog, CRDT package, or wall-clock timestamps.
