# Pilot sync repair

The public API and local-file transport are unchanged. README.md is the caller
contract; the supplied owner decision makes deletion win equal-clock mixed-kind
conflicts before device ordering. Larger clocks still win, so a put after
observing a deletion recreates the note normally.

Changes in `src/sync.ts`:

- Keep the persisted outbox on reopen and scope client files to the unambiguous
  tenant/device pair. Preserve opaque JS strings when encoding storage keys.
- Merge deterministically by clock, deletion priority, JS device-ID comparison,
  then sequence. Keep tombstones and persist the maximum received clock.
- Deduplicate server acceptance by operation ID within the tenant. Keep unique
  losing operations in the feed. Rebuild derived indexes after reopening, giving
  expected O(1) duplicate checks and note reads after first tenant access.
- Share one in-flight sync promise. Capture the batch at invocation and remove
  only each acknowledged operation. Later edits stay queued. Rejections propagate
  without discarding unacknowledged work; retries are safe after uncertain remote
  acceptance. Feed merge, clock and cursor are saved together by atomic rename.

Validation: `bun run test` runs the two preserved public tests and sixteen new
regressions in `tests/sync-regression.test.ts`. Reproductions failed before their
corresponding fixes. Coverage includes restart, identity isolation, detached
snapshots, opaque strings, reversed/duplicated delivery, both mixed-kind tie
orientations, remote-clock recreation, durable deduplication, failure before and
after acceptance, concurrent sync calls, edits during upload/pull, pull failure
and saved-cursor resumption. Transport gates use promises, with no timing sleeps.

Limits: JSON persistence still synchronously rewrites the complete state/log on
each change, so storage cost and latency grow with retained history. No load or
power-loss durability claim is made. The README excludes simultaneous handles
writing the same identity, disk-full recovery and durability beyond atomic
rename. Storage encoding changed; the handoff explicitly requires no installed
data migration. No dependencies, services or commits were introduced.

Independent review is pending. The frozen
[requesting-code-review skill](../../../../sources/superpowers/skills/requesting-code-review/SKILL.md)
says “Dispatch a code reviewer subagent”; this run explicitly prohibits delegation,
so no independent reviewer was invoked or represented as having reviewed it.
