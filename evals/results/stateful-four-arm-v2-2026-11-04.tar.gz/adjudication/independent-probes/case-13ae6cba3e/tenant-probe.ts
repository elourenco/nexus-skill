import assert from 'node:assert/strict';
import {mkdtempSync} from 'node:fs';
import {join} from 'node:path';
import {openClient,openServer} from './src/sync';
const root=mkdtempSync(join(process.cwd(),'state-'));
let server=openServer({root:join(root,'server')});
const client=(tenantId:string)=>openClient({root:join(root,'clients'),tenantId,deviceId:'same-device',transport:server.transport(tenantId)});
let one=client('one'), two=client('two');
const x=one.put('same-key','one'),y=two.put('same-key','two');
assert.equal(x.opId,y.opId);
assert.equal(one.get('same-key'),'one'); assert.equal(two.get('same-key'),'two');
await assert.rejects(server.transport('two').apply(x), /TENANT_MISMATCH/);
await one.sync(); await two.sync();
await server.transport('one').apply(x); await server.transport('two').apply(y);
server=openServer({root:join(root,'server')});
for(const [tenant,value] of [['one','one'],['two','two']]) {
 assert.equal(server.get(tenant,'same-key'),value);
 const feed=await server.transport(tenant).pull(0);
 assert.equal(feed.cursor,1); assert.equal(feed.operations.length,1);
 assert.equal(feed.operations[0].tenantId,tenant);
 const reopened=client(tenant); assert.equal(reopened.get('same-key'),value);
 assert.deepEqual(reopened.pending(),[]);
}
console.log('PASS: equal opId strings preserve independent tenant effects, retry deduplication, authority, feeds and reopen state');
