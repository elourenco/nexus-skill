# Field notes offline prototype

Run `bun test tests`. No install step is needed. The implementation is `src/sync.ts`.

A client is one signed-in tenant/device identity. The `root` is an application storage directory and can be reused after a restart or sign-in change. Different identities may use the same directory. Open at most one live client for a given tenant/device and one live server per server root; replacing a handle represents process restart. Concurrent processes writing the same identity file, malicious filesystem edits, disk-full recovery and power-loss durability beyond atomic rename are outside this pilot.

## Caller contract

```ts
export type Operation = {
  opId: string; tenantId: string; deviceId: string; seq: number; clock: number;
  key: string; kind: 'put' | 'delete'; value?: string;
};
export type Feed = { operations: Operation[]; cursor: number };
export interface Transport {
  apply(op: Operation): Promise<void>;
  pull(cursor: number): Promise<Feed>;
}
export function openClient(options: {
  root: string; tenantId: string; deviceId: string; transport: Transport;
}): {
  put(key: string, value: string): Operation;
  delete(key: string): Operation;
  get(key: string): string | undefined;
  list(): Record<string, string>;
  pending(): Operation[];
  sync(): Promise<void>;
};
export function openServer(options: { root: string }): {
  transport(tenantId: string): Transport;
  get(tenantId: string, key: string): string | undefined;
};
```

`put` and `delete` synchronously store a local edit and return a detached operation. Reads reflect local edits immediately. `pending` is a detached snapshot, in creation order. `get` returns `undefined` for absent/deleted keys; `list` includes only live notes. Keys, values and identity names are opaque strings.

Each operation has a stable identity across retries, a per-identity increasing `seq`, and a logical `clock`. Each local mutation advances the logical clock; receipt of a remote operation advances the local clock to at least its value. Across devices, larger logical clocks take precedence; for equal clocks and the same kind, lexically larger device IDs win, then larger sequence numbers. Use JavaScript string comparison, not locale collation. The owner will resolve equal-clock mixed-kind conflicts. Recreating an observed deleted note is an ordinary later `put`.

`sync` sends a snapshot of the pending operations in order, then pulls from its saved cursor. A resolved `apply` acknowledges that operation; rejection may happen before or after remote acceptance. The first rejection ends that sync and remains visible to the caller. Subsequent calls may retry. Concurrent calls on one client join the current sync; callers can keep editing while it is waiting on transport. Edits created after the initial snapshot stay queued for the next sync. An acknowledgement applies to its specific operation.

The transport is tenant-bound. `apply` rejects a different tenant with `Error('TENANT_MISMATCH')`. Its feed contains each unique accepted operation once, including operations that lose a conflict. The cursor is the count of unique accepted operations in that tenant, with `0` meaning the beginning. `pull(cursor)` returns operations after that cursor and the next cursor. Delivery adapters may reverse or duplicate returned operations without changing the next cursor. Retry and delivery order must not change the resulting notes. Calls and feeds in this pilot contain well-formed operations produced by this API.

The server and client both use local files. Reopening must preserve their externally observable state. The server's `get` exposes the same conflict result as clients after successful synchronization. Network scheduling is represented by wrapping `Transport` methods; tests must not depend on wall-clock sleeps.
