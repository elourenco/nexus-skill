import { afterEach, expect, test } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openClient, openServer, type Operation, type Transport } from '../src/sync';

const roots: string[] = [];
afterEach(() => {
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true });
});
function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'notes-regression-'));
  roots.push(root);
  const serverRoot = join(root, 'server');
  const server = openServer({ root: serverRoot });
  const clientRoot = join(root, 'client');
  function client(deviceId = 'phone', tenantId = 'team', transport = server.transport(tenantId)) {
    return openClient({ root: clientRoot, tenantId, deviceId, transport });
  }
  return { root, serverRoot, server, client };
}

test('reopen preserves offline edits, ordered outbox and operation sequence', async () => {
  const f = fixture();
  let client = f.client();
  const first = client.put('note', 'draft');
  const second = client.delete('removed');
  client = f.client();
  expect(client.get('note')).toBe('draft');
  expect(client.pending()).toEqual([first, second]);
  const third = client.put('note', 'revised');
  expect(third.seq).toBe(3);
  expect(third.clock).toBe(3);
  await client.sync();
  expect(f.server.get('team', 'note')).toBe('revised');
  expect(f.client().pending()).toEqual([]);
});

test('tenant and device pairs sharing a directory have independent durable state', async () => {
  const f = fixture();
  const a = f.client('phone', 'alpha');
  const original = a.put('note', 'alpha only');
  const b = f.client('phone', 'beta');
  expect(b.list()).toEqual({});
  expect(b.pending()).toEqual([]);
  const other = b.put('note', 'beta only');
  expect(other.seq).toBe(1);
  expect(other.clock).toBe(1);
  expect(f.client('phone', 'alpha').pending()).toEqual([original]);
  await b.sync();
  await f.client('phone', 'alpha').sync();
  expect(f.server.get('alpha', 'note')).toBe('alpha only');
  expect(f.server.get('beta', 'note')).toBe('beta only');
});

test('returned operations, pending and list are detached, including opaque keys', async () => {
  const f = fixture();
  const c = f.client();
  const op = c.put('__proto__', 'original');
  op.value = 'changed';
  c.pending()[0].value = 'also changed';
  const listed = c.list();
  listed.__proto__ = 'changed';
  expect(c.get('__proto__')).toBe('original');
  expect(c.pending()[0].value).toBe('original');
  c.put('', 'empty');
  c.put('a/b\u0000💡', 'opaque');
  await c.sync();
  expect(f.server.get('team', '__proto__')).toBe('original');
  expect(f.client().list()).toEqual({ ['__proto__']: 'original', '': 'empty', 'a/b\u0000💡': 'opaque' });
});

for (const scenario of [
  { name: 'higher clock beats larger device', left: 'z', right: 'a', kinds: ['put', 'put'], advance: true, want: 'right' },
  { name: 'same-kind ties use JS device order', left: 'ä', right: 'z', kinds: ['put', 'put'], advance: false, want: 'left' },
  { name: 'delete beats lexically larger put at equal clock', left: 'a', right: 'z', kinds: ['delete', 'put'], advance: false, want: undefined },
  { name: 'delete beats lexically smaller put at equal clock', left: 'a', right: 'z', kinds: ['put', 'delete'], advance: false, want: undefined },
  { name: 'higher-clock put beats an older deletion', left: 'z', right: 'a', kinds: ['delete', 'put'], advance: true, want: 'right' },
] as const) {
  test(`converges across arrival orders and restart: ${scenario.name}`, async () => {
    const f = fixture();
    const left = f.client(scenario.left);
    const right = f.client(scenario.right);
    if (scenario.advance) right.put('other', 'clock advance');
    const first = scenario.kinds[0] === 'delete' ? left.delete('note') : left.put('note', 'left');
    const second = scenario.kinds[1] === 'delete' ? right.delete('note') : right.put('note', 'right');
    for (const [index, operations] of [[first, second], [second, first]].entries()) {
      const serverRoot = join(f.root, `order-${index}`);
      let server = openServer({ root: serverRoot });
      const transport = server.transport('team');
      for (const op of operations) await transport.apply(op);
      expect(server.get('team', 'note')).toBe(scenario.want);
      server = openServer({ root: serverRoot });
      expect(server.get('team', 'note')).toBe(scenario.want);
      const observer = openClient({ root: join(f.root, `observer-${index}`), tenantId: 'team', deviceId: 'reader', transport: {
        apply: op => server.transport('team').apply(op),
        async pull(cursor) {
          const feed = await server.transport('team').pull(cursor);
          return { operations: [...feed.operations].reverse().flatMap(op => [op, op]), cursor: feed.cursor };
        },
      } });
      await observer.sync();
      expect(observer.get('note')).toBe(scenario.want);
    }
  });
}

test('remote clocks survive reopen and an observed deletion can be recreated', async () => {
  const f = fixture();
  const writer = f.client('z');
  writer.put('note', 'one');
  writer.put('note', 'two');
  const deletion = writer.delete('note');
  await writer.sync();
  let reader = f.client('a');
  await reader.sync();
  expect(reader.get('note')).toBeUndefined();
  reader = f.client('a');
  const recreated = reader.put('note', 'intentional recreation');
  expect(recreated.clock).toBe(deletion.clock + 1);
  await reader.sync();
  await writer.sync();
  expect(writer.get('note')).toBe('intentional recreation');
  expect(f.server.get('team', 'note')).toBe('intentional recreation');
});

test('server deduplicates retries durably but retains unique losing operations', async () => {
  const f = fixture();
  const winner = f.client('z').put('note', 'winner');
  const loser = f.client('a').put('note', 'loser');
  let transport = f.server.transport('team');
  await transport.apply(winner);
  await transport.apply(loser);
  await transport.apply(winner);
  const detached = await transport.pull(0);
  expect(detached).toEqual({ operations: [winner, loser], cursor: 2 });
  detached.operations[0].value = 'mutated';
  const restarted = openServer({ root: f.serverRoot });
  transport = restarted.transport('team');
  await transport.apply(loser);
  expect(await transport.pull(1)).toEqual({ operations: [loser], cursor: 2 });
  expect(restarted.get('team', 'note')).toBe('winner');
  await expect(transport.apply({ ...winner, tenantId: 'foreign' })).rejects.toThrow('TENANT_MISMATCH');
  expect(await restarted.transport('foreign').pull(0)).toEqual({ operations: [], cursor: 0 });
});

function deferred<T = void>() {
  let resolve!: (value: T | PromiseLike<T>) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}

for (const accepted of [false, true]) {
  test(`failed apply ${accepted ? 'after' : 'before'} acceptance preserves only unacknowledged operations across reopen`, async () => {
    const f = fixture();
    const real = f.server.transport('team');
    const failure = new Error('link lost');
    let failed = false;
    let pulls = 0;
    const transport: Transport = {
      async apply(op) {
        if (op.seq === 2 && !failed) {
          failed = true;
          if (accepted) await real.apply(op);
          throw failure;
        }
        await real.apply(op);
      },
      async pull(cursor) { pulls++; return real.pull(cursor); },
    };
    let client = f.client('phone', 'team', transport);
    const first = client.put('note', 'one');
    const second = client.put('note', 'two');
    const third = client.put('note', 'three');
    await expect(client.sync()).rejects.toBe(failure);
    expect(pulls).toBe(0);
    expect(client.pending()).toEqual([second, third]);
    client = f.client('phone', 'team', transport);
    expect(client.pending()).toEqual([second, third]);
    await client.sync();
    expect(client.pending()).toEqual([]);
    expect(client.get('note')).toBe('three');
    expect(await real.pull(0)).toEqual({ operations: [first, second, third], cursor: 3 });
  });
}

test('concurrent syncs join one snapshot while edits remain durable for the next sync', async () => {
  const f = fixture();
  const real = f.server.transport('team');
  const entered = deferred();
  const release = deferred();
  const sent: Operation[] = [];
  const transport: Transport = {
    async apply(op) {
      sent.push(structuredClone(op));
      entered.resolve();
      await release.promise;
      await real.apply(op);
    },
    pull: cursor => real.pull(cursor),
  };
  let client = f.client('phone', 'team', transport);
  const first = client.put('note', 'sent snapshot');
  const running = client.sync();
  await entered.promise;
  const concurrent = client.sync();
  const joined = running === concurrent;
  const later = client.put('note', 'typed during upload');
  release.resolve();
  await Promise.all([running, concurrent]);
  expect(joined).toBe(true);
  expect(sent).toEqual([first]);
  expect(client.pending()).toEqual([later]);
  expect(client.get('note')).toBe('typed during upload');
  expect(f.server.get('team', 'note')).toBe('sent snapshot');
  client = f.client();
  expect(client.pending()).toEqual([later]);
  await client.sync();
  expect(f.server.get('team', 'note')).toBe('typed during upload');
});

test('edits during pull survive an older echo and the saved cursor resumes after reopen', async () => {
  const f = fixture();
  const real = f.server.transport('team');
  const entered = deferred();
  const release = deferred();
  const cursors: number[] = [];
  const transport: Transport = {
    apply: op => real.apply(op),
    async pull(cursor) {
      cursors.push(cursor);
      const feed = await real.pull(cursor);
      entered.resolve();
      await release.promise;
      return feed;
    },
  };
  let client = f.client('phone', 'team', transport);
  client.put('note', 'old');
  const running = client.sync();
  await entered.promise;
  const later = client.put('note', 'during pull');
  release.resolve();
  await running;
  expect(client.get('note')).toBe('during pull');
  expect(client.pending()).toEqual([later]);
  client = f.client('phone', 'team', transport);
  await client.sync();
  expect(cursors).toEqual([0, 1]);
  expect(f.server.get('team', 'note')).toBe('during pull');
});

test('pull failure preserves acknowledgements and allows retry on the same handle', async () => {
  const f = fixture();
  const real = f.server.transport('team');
  const failure = new Error('pull offline');
  let failOnce = true;
  const cursors: number[] = [];
  const transport: Transport = {
    apply: op => real.apply(op),
    async pull(cursor) {
      cursors.push(cursor);
      if (failOnce) { failOnce = false; throw failure; }
      return real.pull(cursor);
    },
  };
  const client = f.client('phone', 'team', transport);
  const op = client.put('note', 'durable');
  await expect(client.sync()).rejects.toBe(failure);
  expect(client.pending()).toEqual([]);
  await client.sync();
  expect(cursors).toEqual([0, 0]);
  expect(await real.pull(0)).toEqual({ operations: [op], cursor: 1 });
});

test('opaque strings distinguish unpaired UTF-16 surrogates from replacement characters', async () => {
  const f = fixture();
  const client = f.client();
  client.put('\ud800', 'surrogate key');
  client.put('\ufffd', 'replacement key');
  expect(client.get('\ud800')).toBe('surrogate key');
  expect(client.get('\ufffd')).toBe('replacement key');
  await client.sync();
  expect(f.server.get('team', '\ud800')).toBe('surrogate key');
  expect(f.server.get('team', '\ufffd')).toBe('replacement key');
  for (const [tenant, value] of [['\ud800', 'surrogate tenant'], ['\ufffd', 'replacement tenant']]) {
    const c = f.client('phone', tenant);
    c.put('note', value);
    await c.sync();
  }
  expect(f.server.get('\ud800', 'note')).toBe('surrogate tenant');
  expect(f.server.get('\ufffd', 'note')).toBe('replacement tenant');
});
