import { test, expect, afterEach } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openClient, openServer } from '../src/sync';
const roots: string[] = [];
afterEach(() => { for (const r of roots.splice(0)) rmSync(r, { recursive: true, force: true }); });
function setup() {
  const root = mkdtempSync(join(tmpdir(), 'field-notes-')); roots.push(root);
  const server = openServer({ root: join(root, 'server') });
  const client = openClient({ root: join(root, 'device'), tenantId: 'demo', deviceId: 'phone', transport: server.transport('demo') });
  return { server, client };
}
test('a note is available locally before upload and reaches the server', async () => {
  const { server, client } = setup(); client.put('note', 'hello');
  expect(client.get('note')).toBe('hello'); expect(client.pending()).toHaveLength(1);
  await client.sync(); expect(server.get('demo', 'note')).toBe('hello'); expect(client.pending()).toHaveLength(0);
});
test('editing and removing a note in one session', async () => {
  const { server, client } = setup(); client.put('note', 'one'); await client.sync();
  client.put('note', 'two'); await client.sync(); expect(server.get('demo', 'note')).toBe('two');
  client.delete('note'); await client.sync(); expect(client.list()).toEqual({}); expect(server.get('demo', 'note')).toBeUndefined();
});
