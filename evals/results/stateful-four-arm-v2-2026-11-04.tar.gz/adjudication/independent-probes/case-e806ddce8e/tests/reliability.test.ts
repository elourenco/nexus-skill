import { afterEach, expect, test } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openClient, openServer, type Transport, type Operation } from '../src/sync';

const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'notes-reliability-'));
  roots.push(root);
  const serverRoot = join(root, 'server');
  const server = openServer({ root: serverRoot });
  const client = (deviceId: string, tenantId = 't', transport = server.transport(tenantId)) =>
    openClient({ root: join(root, 'clients'), deviceId, tenantId, transport });
  return { root, serverRoot, server, client };
}
function deferred() {
  let resolve!: () => void;
  const promise = new Promise<void>(r => { resolve = r; });
  return { promise, resolve };
}

test('reopen preserves edits, tombstones, queue, sequence and tenant isolation', async () => {
  const f = fixture();
  let a = f.client('phone');
  const first = a.put('__proto__', 'draft');
  a.delete('removed');
  const snapshot = a.pending();
  snapshot[0].value = 'tampered'; first.value = 'tampered';
  a = f.client('phone');
  expect(a.get('__proto__')).toBe('draft');
  expect(a.pending().map(o => o.kind)).toEqual(['put', 'delete']);
  const other = f.client('phone', 'other');
  expect(other.list()).toEqual({}); expect(other.pending()).toEqual([]);
  other.put('__proto__', 'other tenant'); await other.sync();
  expect(a.put('next', '').seq).toBe(3);
  await a.sync();
  const reopened = f.client('phone');
  expect(reopened.list()).toEqual({ ['__proto__']: 'draft', next: '' });
  expect(reopened.pending()).toEqual([]);
  expect(f.client('phone', 'other').get('__proto__')).toBe('other tenant');
});

test('conflicts converge across replay order, duplicates, delete ties and recreation', async () => {
  const f = fixture();
  const low = f.client('Z'), high = f.client('a');
  const loser = low.put('note', 'Z');
  const winner = high.put('note', 'a');
  const tombstone = low.delete('gone'); // clock 2
  high.put('padding', '');
  // Same clock as the delete, on the lexically larger device.
  const writer = f.client('z'); writer.put('padding', '');
  const mixedPut = writer.put('gone', 'resurrected');
  const ops = [winner, loser, tombstone, mixedPut];
  for (const op of ops) await f.server.transport('t').apply(op);
  const replay: Transport = {
    apply: op => f.server.transport('t').apply(op),
    pull: async cursor => {
      const feed = await f.server.transport('t').pull(cursor);
      return { operations: [...feed.operations].reverse().flatMap(op => [op, { ...op }]), cursor: feed.cursor };
    },
  };
  const reader = f.client('reader', 't', replay);
  await reader.sync();
  expect(reader.get('note')).toBe('a'); expect(f.server.get('t', 'note')).toBe('a');
  expect(reader.get('gone')).toBeUndefined(); expect(f.server.get('t', 'gone')).toBeUndefined();
  expect(reader.put('gone', 'deliberate').clock).toBeGreaterThan(tombstone.clock);
  await reader.sync();
  expect(f.server.get('t', 'gone')).toBe('deliberate');
  const restarted = openServer({ root: f.serverRoot });
  expect(restarted.get('t', 'gone')).toBe('deliberate');
  await restarted.transport('t').apply(winner);
  expect((await restarted.transport('t').pull(0)).cursor).toBe(5);
});

test('same-kind ties use sequence after device, and stale deliveries cannot replace newer notes', async () => {
  const f = fixture();
  const base: Operation = { opId: 'one', tenantId: 't', deviceId: 'a', seq: 1, clock: 10, key: 'k', kind: 'put', value: 'one' };
  const newer = { ...base, opId: 'two', seq: 2, value: 'two' };
  const stale = { ...base, opId: 'old', deviceId: 'z', clock: 9, value: 'old' };
  for (const op of [newer, base, stale]) await f.server.transport('t').apply(op);
  const c = f.client('reader'); await c.sync();
  expect(c.get('k')).toBe('two'); expect(f.server.get('t', 'k')).toBe('two');
  expect(f.client('reader').put('new', 'v').clock).toBe(11);
});

test('sync joins one flight, acknowledges specific operations and keeps edits made during upload', async () => {
  const f = fixture(), entered = deferred(), release = deferred();
  const underlying = f.server.transport('t');
  let calls = 0;
  const c = f.client('phone', 't', {
    apply: async op => { calls++; if (calls === 1) { entered.resolve(); await release.promise; } await underlying.apply(op); },
    pull: cursor => underlying.pull(cursor),
  });
  c.put('k', 'one'); c.put('second', 'two');
  const first = c.sync(); await entered.promise;
  const joined = c.sync();
  const late = c.put('k', 'late');
  expect(joined).toBe(first);
  release.resolve(); await Promise.all([first, joined]);
  expect(calls).toBe(2); expect(c.pending()).toEqual([late]); expect(c.get('k')).toBe('late');
  await c.sync(); expect(calls).toBe(3); expect(f.server.get('t', 'k')).toBe('late');
});

for (const accepted of [false, true]) test(`failed apply (accepted=${accepted}) survives reopen and retry is idempotent`, async () => {
  const f = fixture(); const underlying = f.server.transport('t'); let calls = 0;
  const failure = new Error('connection lost');
  const c = f.client('phone', 't', {
    apply: async op => {
      calls++;
      if (calls === 2) { if (accepted) await underlying.apply(op); throw failure; }
      await underlying.apply(op);
    },
    pull: cursor => underlying.pull(cursor),
  });
  c.put('one', '1'); const second = c.put('two', '2'); const third = c.put('three', '3');
  await expect(c.sync()).rejects.toBe(failure);
  expect(c.pending()).toEqual([second, third]); expect(calls).toBe(2);
  const reopened = f.client('phone'); expect(reopened.pending()).toEqual([second, third]);
  await reopened.sync();
  expect((await openServer({ root: f.serverRoot }).transport('t').pull(0)).cursor).toBe(3);
  expect(reopened.list()).toEqual({ one: '1', two: '2', three: '3' });
});

test('failed pull keeps acknowledgements and saved cursor; mixed-tenant feed cannot partially merge', async () => {
  const f = fixture(), underlying = f.server.transport('t');
  let fail = true; const cursors: number[] = [];
  const c = f.client('phone', 't', {
    apply: op => underlying.apply(op),
    pull: async cursor => { cursors.push(cursor); if (fail) throw new Error('offline'); return underlying.pull(cursor); },
  });
  c.put('local', 'v'); await expect(c.sync()).rejects.toThrow('offline');
  expect(c.pending()).toEqual([]); fail = false; await c.sync();
  expect(cursors).toEqual([0, 0]);
  const reopenedCursors: number[] = [];
  const reopened = f.client('phone', 't', {
    apply: op => underlying.apply(op),
    pull: async cursor => { reopenedCursors.push(cursor); return underlying.pull(cursor); },
  });
  await reopened.sync(); expect(reopenedCursors).toEqual([1]);
  const snapshot = await underlying.pull(0); snapshot.operations[0].value = 'tampered';
  expect(f.server.get('t', 'local')).toBe('v');
  const bad = f.client('reader', 't', { apply: op => underlying.apply(op), pull: async () => ({ cursor: 2, operations: [
    { ...snapshot.operations[0], key: 'injected' }, { ...snapshot.operations[0], tenantId: 'other' },
  ] }) });
  await expect(bad.sync()).rejects.toThrow('TENANT_MISMATCH');
  expect(bad.list()).toEqual({});
  await expect(underlying.apply({ ...snapshot.operations[0], tenantId: 'other' })).rejects.toThrow('TENANT_MISMATCH');
  expect((await underlying.pull(0)).cursor).toBe(1);
});


test('opaque strings retain distinct UTF-16 identities and keys through persistence', async () => {
  const f = fixture();
  const a = f.client('d', '\ud800'), b = f.client('d', '\ufffd');
  a.put('\ud800', 'surrogate'); a.put('\ufffd', 'replacement');
  b.put('', 'other');
  await a.sync(); await b.sync();
  expect(a.get('\ud800')).toBe('surrogate');
  expect(a.get('\ufffd')).toBe('replacement');
  expect(f.server.get('\ud800', '\ud800')).toBe('surrogate');
  expect(f.server.get('\ufffd', '')).toBe('other');
  expect(f.client('d', '\ud800').list()).toEqual({ ['\ud800']: 'surrogate', ['\ufffd']: 'replacement' });
});

for (const leftKind of ['put', 'delete'] as const) for (const rightKind of ['put', 'delete'] as const) {
  test(`equal-clock ${leftKind}/${rightKind} converges in either arrival order`, async () => {
    const f = fixture();
    const a = f.client('Z'), b = f.client('a');
    const left = leftKind === 'put' ? a.put('k', 'left') : a.delete('k');
    const right = rightKind === 'put' ? b.put('k', 'right') : b.delete('k');
    for (const [i, order] of [[left, right], [right, left]].entries()) {
      const server = openServer({ root: join(f.root, `order-${i}`) });
      await Promise.all(order.map(op => server.transport('t').apply(op)));
      const reader = f.client(`reader-${i}`, 't', server.transport('t'));
      await reader.sync();
      const expected = leftKind === 'delete' || rightKind === 'delete' ? undefined : 'right';
      expect(server.get('t', 'k')).toBe(expected); expect(reader.get('k')).toBe(expected);
      expect(reader.list()).toEqual(expected === undefined ? {} : { k: expected });
    }
  });
}

test('edits made during pull stay queued, and persisted tombstones reject stale replay', async () => {
  const f = fixture(), underlying = f.server.transport('t');
  const source = f.client('a'); const old = source.put('k', 'old'); await source.sync();
  const entered = deferred(), release = deferred();
  let pulls = 0;
  let c = f.client('z', 't', {
    apply: op => underlying.apply(op),
    pull: async cursor => {
      pulls++;
      if (pulls === 2) { entered.resolve(); await release.promise; }
      return underlying.pull(cursor);
    },
  });
  await c.sync();
  const syncing = c.sync(); await entered.promise;
  const deletion = c.delete('k'); release.resolve(); await syncing;
  expect(c.pending()).toEqual([deletion]); expect(c.get('k')).toBeUndefined();
  c = f.client('z', 't', {
    apply: op => underlying.apply(op),
    pull: async cursor => { const feed = await underlying.pull(cursor); return { ...feed, operations: [...feed.operations, old] }; },
  });
  expect(c.pending()).toEqual([deletion]); await c.sync();
  expect(c.get('k')).toBeUndefined(); expect(f.server.get('t', 'k')).toBeUndefined();
  c = f.client('z'); expect(c.get('k')).toBeUndefined();
  expect(c.put('k', 'recreated').clock).toBe(deletion.clock + 1);
  await c.sync(); expect(f.server.get('t', 'k')).toBe('recreated');
});
