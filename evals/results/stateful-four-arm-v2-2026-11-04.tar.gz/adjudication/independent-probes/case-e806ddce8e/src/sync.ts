import { mkdirSync, readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { join } from 'node:path';

export type Operation = {
  opId: string; tenantId: string; deviceId: string; seq: number; clock: number;
  key: string; kind: 'put' | 'delete'; value?: string;
};
export type Feed = { operations: Operation[]; cursor: number };
export interface Transport { apply(op: Operation): Promise<void>; pull(cursor: number): Promise<Feed> }
type Local = { seq: number; clock: number; cursor: number; records: Record<string, Operation>; outbox: Operation[] };
// Preserve every JavaScript string, including unpaired UTF-16 surrogates.
const encoded = (s: string) => Buffer.from(s, 'utf16le').toString('base64url');
const clone = <T>(v: T): T => structuredClone(v);
function read<T>(file: string, initial: T): T {
  return existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : initial;
}
function save(file: string, value: unknown): void {
  writeFileSync(file + '.tmp', JSON.stringify(value));
  renameSync(file + '.tmp', file);
}
function compare(a: Operation, b: Operation): number {
  if (a.clock !== b.clock) return a.clock - b.clock;
  if (a.kind !== b.kind) return a.kind === 'delete' ? 1 : -1;
  if (a.deviceId !== b.deviceId) return a.deviceId < b.deviceId ? -1 : 1;
  return a.seq - b.seq;
}
function merge(records: Record<string, Operation>, op: Operation): void {
  const key = encoded(op.key);
  const current = Object.hasOwn(records, key) ? records[key] : undefined;
  if (!current || compare(op, current) > 0) records[key] = clone(op);
}
export function openServer({ root }: { root: string }) {
  mkdirSync(root, { recursive: true });
  const file = join(root, 'server.json');
  const data = read<{ tenants: Record<string, Operation[]> }>(file, { tenants: {} });
  function log(tenantId: string): Operation[] {
    const key = encoded(tenantId);
    return Object.hasOwn(data.tenants, key) ? data.tenants[key] : [];
  }
  // Rebuild disposable indexes from the durable feed on restart.
  const indexes = new Map<string, { seen: Set<string>; records: Record<string, Operation> }>();
  function index(tenantId: string) {
    let result = indexes.get(tenantId);
    if (!result) {
      result = { seen: new Set<string>(), records: {} };
      for (const op of log(tenantId)) {
        result.seen.add(op.opId);
        merge(result.records, op);
      }
      indexes.set(tenantId, result);
    }
    return result;
  }
  return {
    transport(tenantId: string): Transport {
      return {
        async apply(op) {
          if (op.tenantId !== tenantId) throw new Error('TENANT_MISMATCH');
          const tenant = index(tenantId);
          if (tenant.seen.has(op.opId)) return;
          const entries = [...log(tenantId), clone(op)];
          const next = { tenants: { ...data.tenants, [encoded(tenantId)]: entries } };
          save(file, next);
          data.tenants = next.tenants;
          tenant.seen.add(op.opId);
          merge(tenant.records, op);
        },
        async pull(cursor) {
          const entries = log(tenantId);
          return { operations: clone(entries.slice(cursor)), cursor: entries.length };
        },
      };
    },
    get(tenantId: string, key: string): string | undefined {
      const records = index(tenantId).records;
      const op = Object.hasOwn(records, encoded(key)) ? records[encoded(key)] : undefined;
      return op?.kind === 'put' ? op.value : undefined;
    },
  };
}
export function openClient({ root, tenantId, deviceId, transport }: {
  root: string; tenantId: string; deviceId: string; transport: Transport;
}) {
  mkdirSync(root, { recursive: true });
  const file = join(root, `client-${encoded(JSON.stringify([tenantId, deviceId]))}.json`);
  const state = read<Local>(file, { seq: 0, clock: 0, cursor: 0, records: {}, outbox: [] });
  let active: Promise<void> | undefined;
  function mutate(key: string, kind: 'put' | 'delete', value?: string): Operation {
    const seq = ++state.seq;
    const op: Operation = { opId: JSON.stringify([deviceId, seq]), tenantId, deviceId,
      seq, clock: ++state.clock, key, kind, ...(kind === 'put' ? { value } : {}) };
    merge(state.records, op);
    state.outbox.push(op);
    save(file, state);
    return clone(op);
  }
  return {
    put(key: string, value: string): Operation { return mutate(key, 'put', value); },
    delete(key: string): Operation { return mutate(key, 'delete'); },
    get(key: string): string | undefined {
      const op = Object.hasOwn(state.records, encoded(key)) ? state.records[encoded(key)] : undefined;
      return op?.kind === 'put' ? op.value : undefined;
    },
    list(): Record<string, string> {
      return Object.fromEntries(Object.values(state.records)
        .filter(op => op.kind === 'put').map(op => [op.key, op.value!]));
    },
    pending(): Operation[] { return clone(state.outbox); },
    sync(): Promise<void> {
      if (active) return active;
      const batch = clone(state.outbox);
      // Publish the flight before invoking user transport, including reentrant calls.
      active = Promise.resolve().then(async () => {
        for (const op of batch) {
          await transport.apply(clone(op));
          state.outbox = state.outbox.filter(pending => pending.opId !== op.opId);
          save(file, state);
        }
        const feed = await transport.pull(state.cursor);
        // Validate the whole tenant boundary before changing local state or cursor.
        if (feed.operations.some(op => op.tenantId !== tenantId)) throw new Error('TENANT_MISMATCH');
        for (const op of feed.operations) {
          state.clock = Math.max(state.clock, op.clock);
          merge(state.records, op);
        }
        state.cursor = feed.cursor;
        save(file, state);
      }).finally(() => { active = undefined; });
      return active;
    },
  };
}
