# Pilot sync repair

Applied the frozen NEXUS debug/build method in one agent. Sources: README.md,
docs/legacy-handoff.md, existing implementation/tests, and the supplied owner
answer. Public API, original tests and handoff documents are unchanged.

## Changes

- Deterministic merge on client and server: clock, delete priority at equal clock,
  JavaScript device ordering, sequence. Tombstones persist; later observed-clock
  puts can recreate notes. Losing operations remain in the feed.
- Preserve local queue, sequence, logical clock, cursor and records across reopen;
  partition client files by the tenant/device tuple. Encode opaque strings without
  collapsing unpaired UTF-16 surrogates.
- Share one in-flight sync, capture the upload snapshot at invocation, and remove
  only the acknowledged operation. Mid-flight edits remain queued. Rejections
  propagate and release the flight; partial acknowledgements are persisted.
- Deduplicate server accepts by tenant/opId, rebuilding indexes from the durable
  feed after restart. Validate the whole pulled feed's tenant before merging.
- Retain detached operations, queue snapshots and feeds, and atomic file rename.

## Observed verification

Bun 1.4.2 (744846f84), `bun test tests`:

- Original baseline: 2 passed.
- First regression run against the original source: 7 failed, reproducing queue
  loss, order-dependent conflicts, concurrent sync, acknowledgement loss and
  partial cross-tenant merge.
- A later opaque-string test reproduced tenant collision before the encoding fix.
- Final source: 15 passed, 0 failed, 90 assertions across two files. Tests use
  controlled promises, without timing sleeps. Coverage includes before/after
  acceptance failures, reopen/retry, deduplication after server restart, reversed
  and duplicated delivery, both equal-clock arrival orders, recreation, edits
  during upload/pull, and cursor/clock persistence.

Git is absent in this fixture; the implementation was compared with a pre-edit
copy using `diff -u`. No dependencies, external calls or commits were used.

## Limits and gate

Server deduplication and record lookups use in-memory indexes; first access after
restart rebuilds the tenant index. Accepted operations still rewrite the full
server JSON file synchronously, and each client edit/ACK persists its state.
These remain blocking, volume-dependent costs; no load or latency benchmark was
performed. This retains the small-pilot file model, without a compaction protocol.
No installed-data migration is provided, as permitted by the handoff. Disk-full,
power-loss beyond rename, and multiple simultaneous handles/processes for the
same identity/root remain outside the README's scope.

Independent review is PENDING, not approved. The frozen NEXUS invocation contract
requires independent review for material consistency risk and explicitly says
“indisponibilidade mantém esse gate pendente.” The experiment prohibits additional
agents; this implementation's own inspection is not independent review. Method:
/private/tmp/nexus-stateful-benchmark-20261103/remote/skills/nexus/SKILL.md;
contract: references/invocation.md in that same frozen installation.
