import { afterEach, expect, test } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openClient, openServer, type Transport } from '../src/sync';

const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'sync-regression-'));
  roots.push(root);
  const serverRoot = join(root, 'server');
  const server = openServer({ root: serverRoot });
  const client = (tenantId = 'team', deviceId = 'phone', transport = server.transport(tenantId)) =>
    openClient({ root: join(root, 'clients'), tenantId, deviceId, transport });
  return { root, serverRoot, server, client };
}

test('reopening preserves unsent edits, sequence and detached snapshots', async () => {
  const f = fixture();
  let client = f.client();
  const put = client.put('__proto__', 'draft');
  const removed = client.delete('gone');
  put.value = 'tampered';
  client.pending()[0].value = 'tampered';
  client = f.client();
  expect(client.get('__proto__')).toBe('draft');
  expect(client.pending().map(op => op.kind)).toEqual(['put', 'delete']);
  const next = client.put('', 'empty key');
  expect(next.seq).toBe(removed.seq + 1);
  expect(next.clock).toBe(removed.clock + 1);
  await client.sync();
  expect(f.server.get('team', '__proto__')).toBe('draft');
  expect(client.pending()).toEqual([]);
  expect(f.client().list()).toEqual({ ['__proto__']: 'draft', '': 'empty key' });
});

test('same storage root isolates tenant and device identities across reopen', async () => {
  const f = fixture();
  const first = f.client('tenant/a', 'same');
  first.put('note', 'private');
  const second = f.client('tenant', 'a/same');
  expect(second.list()).toEqual({});
  expect(second.put('note', 'other').seq).toBe(1);
  const third = f.client('other', 'same');
  expect(third.list()).toEqual({});
  expect(third.pending()).toEqual([]);
  third.put('note', 'third');
  await third.sync();
  expect(f.client('tenant/a', 'same').get('note')).toBe('private');
  expect(f.client('tenant', 'a/same').pending()).toHaveLength(1);
  expect(f.server.get('tenant/a', 'note')).toBeUndefined();
});

for (const reverse of [false, true]) {
  test(`conflicts converge with ${reverse ? 'reverse' : 'forward'} delivery and duplicates`, async () => {
    const f = fixture();
    const low = f.client('team', 'a');
    const high = f.client('team', 'z');
    const operations = [
      low.put('same-kind', 'a'), high.put('same-kind', 'z'),
      high.put('deleted', 'write'), low.delete('deleted'),
      high.delete('recreated'),
    ];
    low.put('padding', '');
    operations.push(low.put('recreated', 'later'),
      high.put('sequence', 'first'), high.put('sequence', 'second'),
      low.put('lexical', 'lowercase'),
    );
    // Match logical clocks to exercise JavaScript device-ID ordering.
    const upper = f.client('team', 'Z');
    for (let i = 1; i < operations[8].clock; i++) upper.put(`padding-${i}`, '');
    operations.push(upper.put('lexical', 'uppercase'));
    const transport = f.server.transport('team');
    for (const op of reverse ? [...operations].reverse() : operations) await transport.apply(op);
    const reader = f.client('team', 'reader', {
      apply: op => transport.apply(op),
      async pull(cursor) {
        const feed = await transport.pull(cursor);
        return { operations: [...feed.operations].reverse().flatMap(op => [op, op]), cursor: feed.cursor };
      },
    });
    await reader.sync();
    const expected = { 'same-kind': 'z', recreated: 'later', sequence: 'second', lexical: 'lowercase' };
    expect(reader.list()).toEqual(expected);
    expect(reader.get('deleted')).toBeUndefined();
    for (const [key, value] of Object.entries(expected)) expect(f.server.get('team', key)).toBe(value);
    expect(f.server.get('team', 'deleted')).toBeUndefined();
    const reopened = openServer({ root: f.serverRoot });
    expect(reopened.get('team', 'same-kind')).toBe('z');
  });
}

test('observed tombstones advance the durable clock and allow deliberate recreation', async () => {
  const f = fixture();
  const writer = f.client('team', 'z');
  for (let i = 0; i < 8; i++) writer.put('note', 'old');
  const deletion = writer.delete('note');
  await writer.sync();
  await f.client('team', 'a').sync();
  const reader = f.client('team', 'a');
  expect(reader.get('note')).toBeUndefined();
  const recreated = reader.put('note', 'new');
  expect(recreated.clock).toBeGreaterThan(deletion.clock);
  await reader.sync();
  await writer.sync();
  expect(writer.get('note')).toBe('new');
  expect(f.server.get('team', 'note')).toBe('new');
});

function gate() {
  let resolve!: () => void;
  const promise = new Promise<void>(done => { resolve = done; });
  return { promise, resolve };
}

test('concurrent sync joins one snapshot while edits during apply and pull remain pending', async () => {
  const f = fixture();
  const remote = f.server.transport('team');
  const enteredApply = gate(), releaseApply = gate(), enteredPull = gate(), releasePull = gate();
  const applied: string[] = [];
  const client = f.client('team', 'phone', {
    async apply(op) {
      applied.push(op.value!);
      if (applied.length === 1) { enteredApply.resolve(); await releaseApply.promise; }
      await remote.apply(op);
    },
    async pull(cursor) {
      enteredPull.resolve();
      await releasePull.promise;
      return remote.pull(cursor);
    },
  });
  client.put('note', 'one');
  client.put('note', 'two');
  const first = client.sync();
  await enteredApply.promise;
  const joined = client.sync();
  const sharesPromise = joined === first;
  client.put('note', 'three');
  releaseApply.resolve();
  await enteredPull.promise;
  client.put('note', 'four');
  releasePull.resolve();
  await Promise.all([first, joined]);
  expect(sharesPromise).toBe(true);
  expect(applied).toEqual(['one', 'two']);
  expect(client.get('note')).toBe('four');
  expect(client.pending().map(op => op.value)).toEqual(['three', 'four']);
  const reopened = f.client();
  expect(reopened.pending().map(op => op.value)).toEqual(['three', 'four']);
  await reopened.sync();
  expect(f.server.get('team', 'note')).toBe('four');
});

for (const accepted of [false, true]) {
  test(`partial apply failure ${accepted ? 'after' : 'before'} acceptance survives restart and retry`, async () => {
    const f = fixture();
    const remote = f.server.transport('team');
    let calls = 0, pulls = 0;
    const failure = new Error('connection lost');
    const client = f.client('team', 'phone', {
      async apply(op) {
        calls++;
        if (calls === 2) {
          if (accepted) await remote.apply(op);
          throw failure;
        }
        await remote.apply(op);
      },
      async pull(cursor) { pulls++; return remote.pull(cursor); },
    });
    client.put('note', 'one');
    const second = client.put('note', 'two');
    const third = client.put('note', 'three');
    await expect(client.sync()).rejects.toBe(failure);
    expect(pulls).toBe(0);
    expect(client.pending().map(op => op.opId)).toEqual([second.opId, third.opId]);
    const restartedServer = openServer({ root: f.serverRoot });
    const transport = restartedServer.transport('team');
    const restartedClient = f.client('team', 'phone', transport);
    expect(restartedClient.pending()).toHaveLength(2);
    await restartedClient.sync();
    expect(restartedClient.pending()).toEqual([]);
    const feed = await transport.pull(0);
    expect(feed.cursor).toBe(3);
    expect(feed.operations.map(op => op.value)).toEqual(['one', 'two', 'three']);
    expect(restartedServer.get('team', 'note')).toBe('three');
    feed.operations[0].value = 'tampered';
    expect((await transport.pull(0)).operations[0].value).toBe('one');
  });
}

test('pull failure retains acknowledgements and retries the saved durable cursor', async () => {
  const f = fixture();
  const remote = f.server.transport('team');
  let fail = false;
  const cursors: number[] = [];
  const transport: Transport = {
    apply: op => remote.apply(op),
    async pull(cursor) {
      cursors.push(cursor);
      if (fail) throw new Error('pull failed');
      return remote.pull(cursor);
    },
  };
  const client = f.client('team', 'phone', transport);
  client.put('note', 'one');
  await client.sync();
  client.put('note', 'two');
  fail = true;
  await expect(client.sync()).rejects.toThrow('pull failed');
  expect(client.pending()).toEqual([]);
  fail = false;
  await f.client('team', 'phone', transport).sync();
  expect(cursors).toEqual([0, 1, 1]);
  expect((await remote.pull(0)).cursor).toBe(2);
});

test('tenant-bound transport rejects cross-tenant writes without accepting them', async () => {
  const f = fixture();
  const op = f.client('other').put('note', 'secret');
  const remote = f.server.transport('team');
  await expect(remote.apply(op)).rejects.toThrow('TENANT_MISMATCH');
  expect(await remote.pull(0)).toEqual({ operations: [], cursor: 0 });
  expect(f.server.get('team', 'note')).toBeUndefined();
});

test('a foreign operation rejects the whole feed without changing records, clock or cursor', async () => {
  const f = fixture();
  const source = f.client('team', 'source');
  const valid = source.put('note', 'remote');
  const foreign = f.client('other', 'source').put('private', 'secret');
  let invalid = true;
  const cursors: number[] = [];
  const transport: Transport = {
    async apply() {},
    async pull(cursor) {
      cursors.push(cursor);
      return invalid ? { operations: [valid, foreign], cursor: 2 } : { operations: [], cursor: 0 };
    },
  };
  const client = f.client('team', 'reader', transport);
  await expect(client.sync()).rejects.toThrow('TENANT_MISMATCH');
  expect(client.list()).toEqual({});
  expect(client.put('local', 'draft').clock).toBe(1);
  invalid = false;
  const reopened = f.client('team', 'reader', transport);
  await reopened.sync();
  expect(reopened.get('note')).toBeUndefined();
  expect(cursors).toEqual([0, 0]);
});

test('opaque strings preserve distinct UTF-16 keys and identities', async () => {
  const f = fixture();
  const client = f.client('\ud800', '\ud800');
  client.put('\ud800', 'surrogate');
  client.put('\ufffd', 'replacement');
  expect(client.get('\ud800')).toBe('surrogate');
  expect(client.get('\ufffd')).toBe('replacement');
  expect(f.client('\ufffd', '\ud800').list()).toEqual({});
  expect(f.client('\ud800', '\ufffd').list()).toEqual({});
  await client.sync();
  expect(f.server.get('\ud800', '\ud800')).toBe('surrogate');
  expect(f.server.get('\ufffd', '\ud800')).toBeUndefined();
});

test('encoded strings matching Object prototype names remain ordinary keys and tenants', async () => {
  const f = fixture();
  const name = Buffer.from('toString', 'base64url').toString('utf16le');
  const client = f.client(name);
  client.put(name, 'ordinary');
  expect(client.get(name)).toBe('ordinary');
  await client.sync();
  expect(f.server.get(name, name)).toBe('ordinary');
  expect(f.client(name).get(name)).toBe('ordinary');
});
