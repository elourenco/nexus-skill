# Pilot reliability changes

The public API and local-file transport are unchanged. README.md remains the caller contract; the supplied owner decision resolves mixed-kind ties: compare logical clock first, then deletion before put, then JavaScript device-ID ordering and sequence. Tombstones are retained. Receiving remote operations advances the durable local clock, so an ordinary put after observing deletion can recreate the note.

Client files now isolate tenant/device pairs and retain the outbox on reopen. Sync captures one ordered batch, shares its promise with concurrent callers, and removes only the acknowledged operation. Edits made while apply or pull is pending remain queued. Apply rejection stops the batch; pull rejection retains persisted acknowledgements and the previous cursor. A feed containing a foreign tenant is rejected before changing local records or clocks.

The server deduplicates opId within each tenant, including after reopen. Accepted losing operations remain in the feed and count toward its cursor. A lazy in-memory ID set avoids scanning the tenant log on every retry. Both server and client use the same order-independent merge. File/key encoding preserves JavaScript UTF-16 code units; dictionary lookups ignore inherited Object properties.

## Verification

Run `bun run test` (equivalent to `bun test tests`). The original two tests are preserved. Thirteen added regression cases cover restart persistence, identity isolation, detached snapshots, forward/reversed/duplicated delivery, conflict ordering, deletion/recreation, concurrent synchronization with edits at both transport boundaries, rejection before/after acceptance, retry after client/server restart, persistent cursors, tenant rejection, and opaque strings. Scheduling uses explicit promise gates, without sleeps. Bug reproductions were run failing before their respective fixes.

## Limits

No installed-data migration is required by the handoff; the client filename and string encoding changes do not migrate old prototype files. The fixture's one-live-handle rule still applies. JSON persistence still rewrites the file on each mutation/acknowledgement; server reads replay the tenant log, and history is not compacted. This bounds throughput and latency as history grows; no load benchmark was run. Disk-full recovery, multiple writer processes and power-loss durability beyond atomic rename remain outside the contract.

Independent review is pending: this execution is explicitly single-agent. No independent reviewer was used or claimed. No dependencies, services or commits were added.
