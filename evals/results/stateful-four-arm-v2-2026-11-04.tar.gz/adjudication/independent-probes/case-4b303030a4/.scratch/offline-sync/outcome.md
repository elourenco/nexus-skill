# Pilot sync outcome

Changed src/sync.ts; added tests/pilot.test.ts. Public API, local-file transport, README, legacy handoff, and original tests are preserved. File layout changed without migration, as allowed by the legacy handoff.

- Reopen retains the outbox, sequence, logical clock, records and cursor. Client storage separates tenant/device tuples.
- Both server and client merge by clock, then delete priority, then JavaScript device ordering and sequence. Tombstones remain stored. Receipt advances the durable clock so an intentional later put recreates a deleted note.
- Server acceptance deduplicates per-tenant operation IDs, rebuilding its in-memory Set from the durable log on reopen. Losing operations remain in the unique feed; retries do not advance its cursor.
- Concurrent sync calls share one promise and initial queue snapshot. Each resolved apply removes only its own operation and persists the acknowledgement. Edits during transport waits remain queued. Rejection stops the sync and permits safe retry, including after uncertain remote acceptance.
- Returned operations, pending snapshots and feeds remain detached. Opaque JS strings are encoded through JSON to avoid UTF-8 replacement collisions.

Verification: baseline 2 tests passed. New durable-state, merge, clock, deduplication, concurrent-sync and opaque-string regressions were observed failing before their fixes. Final `bun test tests`: 13 passed, 0 failed, 111 assertions. `bun build src/sync.ts --target=bun --outdir=.scratch/offline-sync/build` succeeded. Transport scheduling uses controlled promises, without sleeps. There is no configured/available typechecker; Bun build is not a typecheck.

Direct source comparison and self-check against README found no remaining scoped discrepancies. Independent Standards and Spec reviews required by the frozen method remain pending: this task prohibits subagents. No reviewer is claimed.

Limits: one live client per tenant/device file and one server per root, as documented. Full JSON snapshots still use synchronous writes and rename; server reads replay the tenant log. No load benchmark or large-history latency claim. Disk-full recovery, file corruption and stronger power-loss guarantees remain outside the pilot contract. No dependency installation, external action or commit.

Retrospective: the original suite covered only uninterrupted single-device use. Keep the new restart, controlled-failure and concurrency regressions in the existing `bun test tests` check. No CI configuration exists here; wiring that check into a future integration pipeline is pending and outside this local task.
