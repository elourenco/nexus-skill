# Pilot sync repair

Source of truth: README.md caller contract, docs/legacy-handoff.md, and the supplied owner decision. Public sources and existing tests remain unchanged. Work is local, single-agent, without Git or external services.

Approved seams: openClient mutations/reads/pending/reopen/sync; openServer get/transport/reopen; Transport wrappers controlling acceptance, failure, and delivery. These cover durable state, isolation, convergence, acknowledgement, and concurrent editing. Filesystem corruption, power loss beyond rename, and multiple live handles for the same identity are outside the contract.

Owner decision: at equal clocks, delete beats put before device ordering; same-kind ties use JS device comparison then sequence. An observed deletion can be recreated with a later put.

Local workflow: one session, local notes as tracker, README as domain vocabulary. Setup confirmation and further interviews are superseded by explicit scoped approval and the supplied owner answer. No new product questions remain. Use vertical red/green slices, then full suite and direct source comparison against sync.before.ts. Independent Standards/Spec review remains pending because subagents are forbidden. No commit.

Slices: durable identity state; deterministic conflict resolution/clock receipt; server retry deduplication; serialized sync and precise acknowledgements; failure/restart and detached/opaque boundary regressions.
