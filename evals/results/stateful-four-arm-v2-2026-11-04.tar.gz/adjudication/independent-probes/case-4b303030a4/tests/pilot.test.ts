import { afterEach, expect, test } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { openClient, openServer, type Transport, type Operation } from '../src/sync';

const roots: string[] = [];
afterEach(() => {
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true });
});
function fixture() {
  const root = mkdtempSync(join(import.meta.dir, 'pilot-'));
  roots.push(root);
  const serverRoot = join(root, 'server');
  const server = openServer({ root: serverRoot });
  function client(tenantId = 'team', deviceId = 'phone', transport = server.transport(tenantId)) {
    return openClient({ root: join(root, 'shared'), tenantId, deviceId, transport });
  }
  return { root, serverRoot, server, client };
}
function deferred() {
  let resolve!: () => void;
  const promise = new Promise<void>(done => { resolve = done; });
  return { promise, resolve };
}

test('reopen preserves edits, outbox and sequence and isolates tenant/device identities', async () => {
  const f = fixture();
  let phone = f.client();
  const first = phone.put('note', 'offline');
  phone = f.client();
  expect(phone.get('note')).toBe('offline');
  expect(phone.pending()).toEqual([first]);
  const otherTenant = f.client('other');
  expect(otherTenant.list()).toEqual({});
  expect(otherTenant.pending()).toEqual([]);
  otherTenant.put('note', 'private');
  const otherDevice = f.client('team', 'tablet');
  expect(otherDevice.list()).toEqual({});
  phone = f.client();
  const second = phone.put('note', 'updated');
  expect(second.seq).toBe(first.seq + 1);
  expect(second.clock).toBeGreaterThan(first.clock);
  await phone.sync();
  expect(f.server.get('team', 'note')).toBe('updated');
  expect(f.client().pending()).toEqual([]);
  expect(f.client('other').get('note')).toBe('private');
});

test('conflicts converge with reordered/duplicated delivery and delete wins equal clocks', async () => {
  for (const reverse of [false, true]) {
    const f = fixture();
    const low = f.client('team', 'a');
    const high = f.client('team', 'z');
    const operations = [
      low.delete('deleted'), high.put('deleted', 'must lose'),
      high.put('device-tie', 'z wins'), low.put('device-tie', 'a loses'),
      low.put('clock-wins', 'old'), low.put('clock-wins', 'new'),
    ];
    const wire = f.server.transport('team');
    for (const op of reverse ? operations.toReversed() : operations) await wire.apply(op);
    const reader = f.client('team', 'reader', {
      apply: op => wire.apply(op),
      async pull(cursor) {
        const feed = await wire.pull(cursor);
        return { operations: [...feed.operations.toReversed(), ...feed.operations], cursor: feed.cursor };
      },
    });
    await reader.sync();
    expect(reader.list()).toEqual({ 'device-tie': 'z wins', 'clock-wins': 'new' });
    expect(f.server.get('team', 'deleted')).toBeUndefined();
    expect(f.server.get('team', 'device-tie')).toBe('z wins');
    expect(f.server.get('team', 'clock-wins')).toBe('new');
    expect(openServer({ root: f.serverRoot }).get('team', 'deleted')).toBeUndefined();
    expect(f.client('team', 'reader').list()).toEqual(reader.list());
  }
});

test('receiving a deletion advances a durable logical clock so a later put recreates it', async () => {
  const f = fixture();
  const author = f.client('team', 'z');
  for (let i = 0; i < 5; i++) author.put('note', String(i));
  const deletion = author.delete('note');
  await author.sync();
  let reader = f.client('team', 'a');
  await reader.sync();
  expect(reader.get('note')).toBeUndefined();
  reader = f.client('team', 'a');
  const recreation = reader.put('note', 'recreated');
  expect(recreation.clock).toBe(deletion.clock + 1);
  await reader.sync();
  await author.sync();
  expect(author.get('note')).toBe('recreated');
  expect(f.server.get('team', 'note')).toBe('recreated');
});

test('server retries survive reopen without duplicating the feed or cursor, including losing ops', async () => {
  const f = fixture();
  const loser = f.client('team', 'a').put('note', 'loser');
  const winner = f.client('team', 'z').put('note', 'winner');
  let wire = f.server.transport('team');
  await wire.apply(winner);
  await wire.apply(loser);
  await wire.apply(loser);
  wire = openServer({ root: f.serverRoot }).transport('team');
  await wire.apply(winner);
  expect(await wire.pull(0)).toEqual({ operations: [winner, loser], cursor: 2 });
  expect(await wire.pull(1)).toEqual({ operations: [loser], cursor: 2 });
  expect(await wire.pull(2)).toEqual({ operations: [], cursor: 2 });
  await expect(wire.apply({ ...loser, tenantId: 'wrong' })).rejects.toThrow('TENANT_MISMATCH');
  expect(await wire.pull(0)).toEqual({ operations: [winner, loser], cursor: 2 });
  const other = openServer({ root: f.serverRoot }).transport('other');
  const otherOp = f.client('other', 'a').put('note', 'other');
  await other.apply(otherOp);
  expect(await other.pull(0)).toEqual({ operations: [otherOp], cursor: 1 });
});

test('concurrent sync calls join one snapshot and edits during upload stay pending', async () => {
  const f = fixture();
  const wire = f.server.transport('team');
  const entered = deferred();
  const release = deferred();
  const sent: Operation[] = [];
  const client = f.client('team', 'phone', {
    async apply(op) {
      sent.push(op);
      entered.resolve();
      await release.promise;
      await wire.apply(op);
    },
    pull: cursor => wire.pull(cursor),
  });
  const firstOp = client.put('note', 'first');
  const secondOp = client.put('note', 'second');
  const first = client.sync();
  await entered.promise;
  const laterOp = client.put('note', 'during upload');
  const joined = client.sync();
  release.resolve();
  await Promise.all([first, joined]);
  expect(joined).toBe(first);
  expect(sent).toEqual([firstOp, secondOp]);
  expect(client.get('note')).toBe('during upload');
  expect(client.pending()).toEqual([laterOp]);
  const reopened = f.client();
  expect(reopened.pending()).toEqual([laterOp]);
  await reopened.sync();
  expect(f.server.get('team', 'note')).toBe('during upload');
});

test('a failed apply retains its operation and the unsent tail; retry is safe after uncertain acceptance', async () => {
  for (const acceptBeforeError of [false, true]) {
    for (const restart of [false, true]) {
      const f = fixture();
      let wire = f.server.transport('team');
      const attempts: Operation[] = [];
      let fail = true;
      let pulls = 0;
      const transport: Transport = {
        async apply(op) {
          attempts.push(structuredClone(op));
          if (op.seq === 2 && fail) {
            fail = false;
            if (acceptBeforeError) await wire.apply(op);
            throw new Error('connection lost');
          }
          await wire.apply(op);
        },
        pull(cursor) { pulls++; return wire.pull(cursor); },
      };
      let client = f.client('team', 'phone', transport);
      const first = client.put('one', '1');
      const second = client.put('two', '2');
      const third = client.delete('three');
      await expect(client.sync()).rejects.toThrow('connection lost');
      expect(attempts).toEqual([first, second]);
      expect(pulls).toBe(0);
      expect(client.pending()).toEqual([second, third]);
      wire = openServer({ root: f.serverRoot }).transport('team');
      if (restart) client = f.client('team', 'phone', transport);
      expect(client.pending()).toEqual([second, third]);
      await client.sync();
      expect(attempts).toEqual([first, second, second, third]);
      expect(client.pending()).toEqual([]);
      expect(await wire.pull(0)).toEqual({ operations: [first, second, third], cursor: 3 });
      expect(client.list()).toEqual({ one: '1', two: '2' });
    }
  }
});

test('pull failure preserves acknowledgements and cursor across reopen', async () => {
  const f = fixture();
  const wire = f.server.transport('team');
  const cursors: number[] = [];
  let fail = true;
  let uploads = 0;
  const transport: Transport = {
    async apply(op) { uploads++; await wire.apply(op); },
    async pull(cursor) {
      cursors.push(cursor);
      if (fail) { fail = false; throw new Error('pull unavailable'); }
      return wire.pull(cursor);
    },
  };
  let client = f.client('team', 'phone', transport);
  client.put('note', 'saved');
  await expect(client.sync()).rejects.toThrow('pull unavailable');
  client = f.client('team', 'phone', transport);
  expect(client.pending()).toEqual([]);
  await client.sync();
  client = f.client('team', 'phone', transport);
  await client.sync();
  expect(cursors).toEqual([0, 0, 1]);
  expect(uploads).toBe(1);
  expect(client.get('note')).toBe('saved');
});

test('edits during a waiting pull remain visible and queued after replay and reopen', async () => {
  const f = fixture();
  const wire = f.server.transport('team');
  const entered = deferred();
  const release = deferred();
  const client = f.client('team', 'phone', {
    apply: op => wire.apply(op),
    async pull(cursor) {
      const feed = await wire.pull(cursor);
      entered.resolve();
      await release.promise;
      return feed;
    },
  });
  client.put('note', 'old');
  const syncing = client.sync();
  await entered.promise;
  const edit = client.put('note', 'while pulling');
  release.resolve();
  await syncing;
  expect(client.get('note')).toBe('while pulling');
  expect(client.pending()).toEqual([edit]);
  expect(f.client().get('note')).toBe('while pulling');
  expect(f.client().pending()).toEqual([edit]);
});

test('same-kind ties use JavaScript device ordering, then sequence', async () => {
  const f = fixture();
  const upper = f.client('team', 'Z').put('device', 'upper loses');
  const lower = f.client('team', 'a').put('device', 'lower wins');
  const longHistory = f.client('team', 'same');
  for (let i = 0; i < 3; i++) longHistory.put('sequence', 'old');
  const highSeq = longHistory.put('sequence', 'higher sequence');

  const isolated = fixture();
  const seed = isolated.client('team', 'seed');
  for (let i = 0; i < 3; i++) seed.put('seed', 'remote');
  await seed.sync();
  const shortHistory = isolated.client('team', 'same');
  shortHistory.put('sequence', 'old');
  await shortHistory.sync();
  const lowSeq = shortHistory.put('sequence', 'lower sequence');
  expect(lowSeq.clock).toBe(highSeq.clock);
  expect(lowSeq.seq).toBeLessThan(highSeq.seq);
  const wire = f.server.transport('team');
  for (const op of [lower, upper, highSeq, lowSeq]) await wire.apply(op);
  const reader = f.client('team', 'reader');
  await reader.sync();
  expect(reader.list()).toEqual({ device: 'lower wins', sequence: 'higher sequence' });
  expect(f.server.get('team', 'device')).toBe('lower wins');
  expect(f.server.get('team', 'sequence')).toBe('higher sequence');
});

test('opaque strings and detached snapshots survive local edits, transport and reopen', async () => {
  const f = fixture();
  const tenantId = '../team\0雪';
  const deviceId = '/phone\0';
  const wire = f.server.transport(tenantId);
  const client = f.client(tenantId, deviceId, {
    async apply(op) {
      await wire.apply(op);
      op.opId = 'modified by adapter';
      op.value = 'modified by adapter';
    },
    pull: cursor => wire.pull(cursor),
  });
  const expected = Object.fromEntries([
    ['', ''], ['__proto__', 'prototype note'], ['constructor', 'constructor note'],
    ['toString', 'string note'], ['../note\0雪', '☃'],
  ]);
  for (const [key, value] of Object.entries(expected)) {
    const returned = client.put(key, value);
    returned.value = 'changed return';
    returned.opId = 'changed return';
  }
  const snapshot = client.pending();
  snapshot[0].value = 'changed snapshot';
  snapshot.splice(1);
  expect(client.list()).toEqual(expected);
  expect(client.pending()).toHaveLength(5);
  await client.sync();
  expect(client.pending()).toEqual([]);
  expect(f.client(tenantId, deviceId).list()).toEqual(expected);
  const feed = await wire.pull(0);
  feed.operations[0].value = 'changed feed';
  feed.operations.splice(1);
  expect((await wire.pull(0)).operations).toHaveLength(5);
  for (const [key, value] of Object.entries(expected)) expect(f.server.get(tenantId, key)).toBe(value);
  expect(f.client('different', deviceId).list()).toEqual({});
});

test('opaque strings retain distinct JavaScript identities even for unpaired surrogates', async () => {
  const f = fixture();
  const client = f.client('\ud800', 'phone');
  client.put('\ud800', 'surrogate');
  client.put('\ufffd', 'replacement');
  expect(client.list()).toEqual({ '\ud800': 'surrogate', '\ufffd': 'replacement' });
  await client.sync();
  const other = f.client('\ufffd', 'phone');
  await other.sync();
  expect(other.list()).toEqual({});
  other.put('\ud800', 'other tenant');
  await other.sync();
  expect(f.server.get('\ud800', '\ud800')).toBe('surrogate');
  expect(f.server.get('\ud800', '\ufffd')).toBe('replacement');
  expect(f.server.get('\ufffd', '\ud800')).toBe('other tenant');
});
