import { mkdirSync, readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { join } from 'node:path';

export type Operation = {
  opId: string; tenantId: string; deviceId: string; seq: number; clock: number;
  key: string; kind: 'put' | 'delete'; value?: string;
};
export type Feed = { operations: Operation[]; cursor: number };
export interface Transport { apply(op: Operation): Promise<void>; pull(cursor: number): Promise<Feed> }
type Local = { seq: number; clock: number; cursor: number; records: Record<string, Operation>; outbox: Operation[] };
// JSON preserves distinct JS strings, including unpaired UTF-16 surrogates.
const encoded = (s: string) => Buffer.from(JSON.stringify(s)).toString('base64url');
const clone = <T>(v: T): T => structuredClone(v);
function read<T>(file: string, initial: T): T {
  return existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : initial;
}
function save(file: string, value: unknown): void {
  writeFileSync(file + '.tmp', JSON.stringify(value));
  renameSync(file + '.tmp', file);
}
function compare(a: Operation, b: Operation): number {
  if (a.clock !== b.clock) return a.clock - b.clock;
  if (a.kind !== b.kind) return a.kind === 'delete' ? 1 : -1;
  if (a.deviceId !== b.deviceId) return a.deviceId < b.deviceId ? -1 : 1;
  return a.seq - b.seq;
}
function merge(records: Record<string, Operation>, op: Operation): void {
  const key = encoded(op.key);
  if (!records[key] || compare(op, records[key]) > 0) records[key] = clone(op);
}
export function openServer({ root }: { root: string }) {
  mkdirSync(root, { recursive: true });
  const file = join(root, 'server.json');
  const data = read<{ tenants: Record<string, Operation[]> }>(file, { tenants: {} });
  const accepted = new Map<string, Set<string>>();
  function log(tenantId: string): Operation[] { return data.tenants[encoded(tenantId)] ?? []; }
  return {
    transport(tenantId: string): Transport {
      return {
        async apply(op) {
          if (op.tenantId !== tenantId) throw new Error('TENANT_MISMATCH');
          const entries = log(tenantId);
          let ids = accepted.get(tenantId);
          if (!ids) {
            ids = new Set(entries.map(entry => entry.opId));
            accepted.set(tenantId, ids);
          }
          if (ids.has(op.opId)) return;
          entries.push(clone(op));
          data.tenants[encoded(tenantId)] = entries;
          save(file, data);
          ids.add(op.opId);
        },
        async pull(cursor) {
          const entries = log(tenantId);
          return { operations: clone(entries.slice(cursor)), cursor: entries.length };
        },
      };
    },
    get(tenantId: string, key: string): string | undefined {
      const records: Record<string, Operation> = {};
      for (const op of log(tenantId)) merge(records, op);
      const op = records[encoded(key)];
      return op?.kind === 'put' ? op.value : undefined;
    },
  };
}
export function openClient({ root, tenantId, deviceId, transport }: {
  root: string; tenantId: string; deviceId: string; transport: Transport;
}) {
  mkdirSync(root, { recursive: true });
  const file = join(root, `client-${encoded(JSON.stringify([tenantId, deviceId]))}.json`);
  const state = read<Local>(file, { seq: 0, clock: 0, cursor: 0, records: {}, outbox: [] });
  let active: Promise<void> | undefined;
  function mutate(key: string, kind: 'put' | 'delete', value?: string): Operation {
    const seq = ++state.seq;
    const op: Operation = { opId: JSON.stringify([deviceId, seq]), tenantId, deviceId,
      seq, clock: ++state.clock, key, kind, ...(kind === 'put' ? { value } : {}) };
    merge(state.records, op);
    state.outbox.push(op);
    save(file, state);
    return clone(op);
  }
  return {
    put(key: string, value: string): Operation { return mutate(key, 'put', value); },
    delete(key: string): Operation { return mutate(key, 'delete'); },
    get(key: string): string | undefined {
      const op = state.records[encoded(key)];
      return op?.kind === 'put' ? op.value : undefined;
    },
    list(): Record<string, string> {
      return Object.fromEntries(Object.values(state.records)
        .filter(op => op.kind === 'put').map(op => [op.key, op.value!]));
    },
    pending(): Operation[] { return clone(state.outbox); },
    sync(): Promise<void> {
      if (active) return active;
      const batch = clone(state.outbox);
      active = Promise.resolve().then(async () => {
        for (const op of batch) {
          await transport.apply(clone(op));
          state.outbox = state.outbox.filter(pending => pending.opId !== op.opId);
          save(file, state);
        }
        const feed = await transport.pull(state.cursor);
        for (const op of feed.operations) {
          if (op.tenantId !== tenantId) throw new Error('TENANT_MISMATCH');
          merge(state.records, op);
          state.clock = Math.max(state.clock, op.clock);
        }
        state.cursor = feed.cursor;
        save(file, state);
      }).finally(() => { active = undefined; });
      return active;
    },
  };
}
