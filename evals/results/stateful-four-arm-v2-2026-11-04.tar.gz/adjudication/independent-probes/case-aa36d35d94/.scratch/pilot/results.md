# Pilot repair outcome

Implemented in src/sync.ts; 16 new public-API regression tests in tests/pilot.test.ts. README.md, docs/legacy-handoff.md, package.json and the two original tests were preserved.

- Client files are scoped by a SHA-256 digest of the JSON tenant/device tuple, allowing opaque names without path or filename-length constraints. The durable outbox, sequence, clock, records and cursor survive reopen.
- Merge selects the maximum logical clock, then deletion over put, then JavaScript device ordering and sequence. Tombstones remain stored. All received clocks are observed; later puts can recreate deleted notes.
- Server retries deduplicate by tenant/opId with an in-memory Set rebuilt from persisted logs. Losing operations still enter the feed exactly once.
- Sync captures its batch immediately, publishes one shared promise before transport runs, acknowledges individual operations durably, and leaves later edits queued. The first rejection propagates and releases the active sync for retry.
- JSON-before-UTF8 encoding preserves distinct lone UTF-16 surrogates in opaque keys and tenants. Returned operations, feeds, lists and pending snapshots remain detached.

Validation: initial `bun test tests`: 2 passed. Observed failing regressions before fixes for lost outbox, order-dependent conflict replay, ambiguous-acceptance duplication, concurrent sync, surrogate collisions, and long identity filenames. Final `bun test tests`: 18 passed, 0 failed, 93 assertions (Bun 1.4.2). Scheduling tests use deferred promises; no sleeps. No TypeScript compiler was available; Bun executed/transpiled the source, but no static typecheck was run.

Local source inspection against sync.before.ts checked the README and supplied owner policy, exported API preservation, and scope. Independent Standards and Spec reviews required by the frozen code-review method remain PENDING: this run is explicitly single-agent. No reviewer was fabricated. No commit, dependency install, external service or method-installation modification occurred.

Limits retained from the contract: one live client per tenant/device and one live server per root; atomic-rename durability; no legacy-data migration, multi-process coordination or disk-full recovery. File writes serialize full state and server.get replays the tenant log; no load/latency benchmark or log compaction was added. The pilot should run the regression suite as a future CI guardrail; this fixture has no CI or static-check script.
