# Pilot sync repair

Source of truth: README.md, docs/legacy-handoff.md, and the supplied owner answer.
Approved public seams: openClient mutations/reads/pending/reopen/sync and openServer transport/get/reopen. Transport wrappers control failures and scheduling without sleeps. Public legacy files stay intact.

Single-session vertical slices:
1. Persist pending operations and isolate tenant/device identities.
2. Deterministic conflict ordering, tombstones and observed clocks.
3. Unique server acceptance across ambiguous retries and restart.
4. Single-flight sync, operation-specific acknowledgement and failure recovery.
5. Detached snapshots, opaque strings and tenant rejection coverage.

No migration is required. Atomic rename is the durability boundary. One live handle per identity/root is assumed. Full-log retention is acceptable for this pilot; no compaction protocol is introduced.

Method adaptation: local artifacts only, existing approvals used; no commit or external tracker. Independent Standards/Spec review pending because single-agent execution is required. Baseline source retained locally for direct comparison.
