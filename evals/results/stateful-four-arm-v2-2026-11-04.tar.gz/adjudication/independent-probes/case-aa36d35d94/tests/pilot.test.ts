import { afterEach, expect, test } from 'bun:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openClient, openServer, type Transport } from '../src/sync';
const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'pilot-sync-')); roots.push(root);
  const serverRoot = join(root, 'server');
  const server = openServer({ root: serverRoot });
  const client = (tenantId = 'team', deviceId = 'phone', transport = server.transport(tenantId)) =>
    openClient({ root: join(root, 'clients'), tenantId, deviceId, transport });
  return { root, serverRoot, server, client };
}

test('reopening preserves queued edits, identity counters and tenant isolation', async () => {
  const f = fixture();
  let a = f.client();
  const first = a.put('note', 'offline');
  a = f.client();
  expect(a.pending()).toEqual([first]);
  expect(a.get('note')).toBe('offline');
  const b = f.client('other');
  expect(b.list()).toEqual({});
  expect(b.pending()).toEqual([]);
  b.put('note', 'private');
  await b.sync();
  a = f.client();
  const second = a.delete('note');
  expect(second.seq).toBe(first.seq + 1);
  expect(second.clock).toBeGreaterThan(first.clock);
  await a.sync();
  expect(f.server.get('team', 'note')).toBeUndefined();
  expect(f.server.get('other', 'note')).toBe('private');
  expect(f.client().pending()).toEqual([]);
});

test('conflicts converge despite replay, deletion wins clock ties and observed deletion can be recreated', async () => {
  const f = fixture();
  const low = f.client('team', 'a');
  const high = f.client('team', 'z');
  const deletion = low.delete('note');
  const edit = high.put('note', 'concurrent');
  await high.sync(); await low.sync(); await high.sync();
  expect(high.get('note')).toBeUndefined();
  expect(low.get('note')).toBeUndefined();
  expect(f.server.get('team', 'note')).toBeUndefined();
  // Deliver the stale put again, in reverse order and duplicated.
  const replay = f.client('team', 'reader', {
    apply: op => f.server.transport('team').apply(op),
    async pull() { return { operations: [deletion, edit, edit], cursor: 2 }; },
  });
  await replay.sync();
  expect(replay.get('note')).toBeUndefined();
  const reopened = f.client('team', 'reader');
  const recreation = reopened.put('note', 'recreated');
  expect(recreation.clock).toBeGreaterThan(deletion.clock);
  await reopened.sync(); await low.sync(); await high.sync();
  expect(low.get('note')).toBe('recreated');
  expect(high.get('note')).toBe('recreated');
  expect(f.server.get('team', 'note')).toBe('recreated');
});

test('ambiguous acceptance retries once in the feed across server and client restart', async () => {
  const f = fixture();
  const transport = f.server.transport('team');
  const client = f.client('team', 'phone', {
    async apply(op) { await transport.apply(op); throw new Error('connection lost'); },
    pull: cursor => transport.pull(cursor),
  });
  const op = client.put('note', 'saved');
  await expect(client.sync()).rejects.toThrow('connection lost');
  expect(client.pending()).toEqual([op]);
  const restarted = openServer({ root: f.serverRoot });
  const retry = f.client('team', 'phone', restarted.transport('team'));
  await retry.sync();
  expect(retry.pending()).toEqual([]);
  expect(await restarted.transport('team').pull(0)).toEqual({ operations: [op], cursor: 1 });
  expect(await restarted.transport('team').pull(1)).toEqual({ operations: [], cursor: 1 });
  expect(restarted.get('team', 'note')).toBe('saved');
});

function deferred() {
  let resolve!: () => void;
  const promise = new Promise<void>(done => { resolve = done; });
  return { promise, resolve };
}

test('concurrent sync joins one batch and acknowledgement preserves edits made during upload', async () => {
  const f = fixture(); const base = f.server.transport('team');
  const entered = deferred(); const release = deferred();
  let applies = 0;
  const a = f.client('team', 'phone', {
    async apply(op) { applies++; entered.resolve(); await release.promise; await base.apply(op); },
    pull: cursor => base.pull(cursor),
  });
  a.put('note', 'first');
  const firstSync = a.sync(); await entered.promise;
  const joined = a.sync();
  const later = a.put('note', 'second');
  expect(joined).toBe(firstSync);
  release.resolve(); await Promise.all([firstSync, joined]);
  expect(applies).toBe(1);
  expect(a.pending()).toEqual([later]);
  expect(a.get('note')).toBe('second');
  const reopened = f.client();
  expect(reopened.pending()).toEqual([later]);
  await reopened.sync();
  expect(f.server.get('team', 'note')).toBe('second');
});

test('partial upload failure preserves only unacknowledged operations and stops before pull', async () => {
  const f = fixture(); const base = f.server.transport('team');
  let attempts = 0; let pulls = 0;
  const client = f.client('team', 'phone', {
    async apply(op) { if (++attempts === 2) throw new Error('offline'); await base.apply(op); },
    async pull(cursor) { pulls++; return base.pull(cursor); },
  });
  const first = client.put('a', 'one'); const second = client.put('b', 'two');
  const third = client.delete('a');
  await expect(client.sync()).rejects.toThrow('offline');
  expect(pulls).toBe(0);
  expect(client.pending()).toEqual([second, third]);
  expect(await base.pull(0)).toEqual({ operations: [first], cursor: 1 });
  const reopened = f.client();
  expect(reopened.pending()).toEqual([second, third]);
  await reopened.sync();
  expect(reopened.list()).toEqual({ b: 'two' });
});

test('pull failure is retryable and successful cursor and observed clocks survive reopening', async () => {
  const f = fixture(); const base = f.server.transport('team');
  const remote = f.client('team', 'remote');
  remote.put('note', '1'); remote.put('note', '2'); remote.delete('note'); await remote.sync();
  let fail = true; const cursors: number[] = [];
  const transport: Transport = {
    apply: op => base.apply(op),
    async pull(cursor) {
      cursors.push(cursor);
      if (fail) { fail = false; throw new Error('pull offline'); }
      const feed = await base.pull(cursor);
      return { ...feed, operations: [...feed.operations].reverse().flatMap(op => [op, op]) };
    },
  };
  let client = f.client('team', 'phone', transport);
  await expect(client.sync()).rejects.toThrow('pull offline');
  await client.sync();
  client = f.client('team', 'phone', transport); await client.sync();
  expect(cursors).toEqual([0, 0, 3]);
  expect(client.get('note')).toBeUndefined();
  expect(client.put('note', 'again').clock).toBe(4);
  await client.sync();
  expect(f.server.get('team', 'note')).toBe('again');
});

test('same-kind ties use JS device ordering and a higher clock beats a higher device ID', async () => {
  const f = fixture(); const t = f.server.transport('team');
  const lower = f.client('team', 'z'); const higher = f.client('team', 'ä');
  const low = lower.put('note', 'low'); const high = higher.put('note', 'high');
  await t.apply(high); await t.apply(low);
  expect(f.server.get('team', 'note')).toBe('high');
  const latest = higher.put('note', 'latest');
  await t.apply(latest); await t.apply(high);
  lower.put('note', 'intermediate');
  const higherClock = lower.put('note', 'highest clock');
  await t.apply(higherClock);
  const reader = f.client('team', 'reader'); await reader.sync();
  expect(reader.get('note')).toBe('highest clock');
  // A clock learned from a losing operation must also advance local time.
  const observer = f.client('team', 'observer', {
    apply: op => t.apply(op),
    async pull() { return { operations: [latest, high], cursor: 3 }; },
  });
  await observer.sync();
  expect(observer.put('next', 'value').clock).toBe(3);
});

test('snapshots are detached, opaque keys round-trip, and tenant mismatch leaves no feed entry', async () => {
  const f = fixture(); const client = f.client();
  const op = client.put('__proto__', 'safe');
  op.value = 'mutated'; client.pending()[0].value = 'mutated again';
  const listing = client.list(); listing.__proto__ = 'changed';
  expect(client.get('__proto__')).toBe('safe');
  await client.sync();
  const t = f.server.transport('team');
  const feed = await t.pull(0); feed.operations[0].value = 'changed feed';
  expect(f.server.get('team', '__proto__')).toBe('safe');
  await expect(f.server.transport('other').apply(op)).rejects.toThrow('TENANT_MISMATCH');
  expect(await f.server.transport('other').pull(0)).toEqual({ operations: [], cursor: 0 });
  const remote = f.client('team', 'reader'); await remote.sync();
  expect(remote.list()).toEqual(Object.fromEntries([['__proto__', 'safe']]));
});

test('opaque strings include empty strings and distinct unpaired UTF-16 surrogates', async () => {
  const f = fixture(); const a = f.client('\ud800', '');
  a.put('', ''); a.put('\ud800', 'first'); a.put('\ud801', 'second');
  expect(a.get('\ud800')).toBe('first');
  expect(a.get('\ud801')).toBe('second');
  await a.sync();
  const b = f.client('\ud801', ''); b.put('', 'other tenant'); await b.sync();
  expect(f.server.get('\ud800', '')).toBe('');
  expect(f.server.get('\ud801', '')).toBe('other tenant');
  expect(f.client('\ud800', '').get('\ud800')).toBe('first');
});

for (const deleteDevice of ['a', 'z']) {
  for (const deleteFirst of [false, true]) {
    test(`delete wins an equal clock with device ${deleteDevice}, delete first: ${deleteFirst}`, async () => {
      const f = fixture(); const t = f.server.transport('team');
      const deletion = f.client('team', deleteDevice).delete('note');
      const edit = f.client('team', deleteDevice === 'a' ? 'z' : 'a').put('note', 'edit');
      for (const op of deleteFirst ? [deletion, edit] : [edit, deletion]) await t.apply(op);
      expect(f.server.get('team', 'note')).toBeUndefined();
      const reader = f.client('team', 'reader'); await reader.sync();
      expect(reader.get('note')).toBeUndefined();
      expect((await t.pull(0)).operations).toHaveLength(2);
      const server = openServer({ root: f.serverRoot });
      expect(server.get('team', 'note')).toBeUndefined();
      expect(f.client('team', 'reader').get('note')).toBeUndefined();
    });
  }
}

test('a rejection before acceptance keeps the first operation and releases joined callers for retry', async () => {
  const f = fixture(); const base = f.server.transport('team');
  let offline = true;
  const client = f.client('team', 'phone', {
    async apply(op) { if (offline) throw new Error('offline'); await base.apply(op); },
    pull: cursor => base.pull(cursor),
  });
  const op = client.put('note', 'value');
  const first = client.sync(); const joined = client.sync();
  expect(joined).toBe(first);
  await expect(first).rejects.toThrow('offline');
  await expect(joined).rejects.toThrow('offline');
  expect(client.pending()).toEqual([op]);
  expect(await base.pull(0)).toEqual({ operations: [], cursor: 0 });
  offline = false; await client.sync();
  expect(client.pending()).toEqual([]);
  expect(f.server.get('team', 'note')).toBe('value');
});

test('edits made while pulling remain queued and follow normal conflict ordering', async () => {
  const f = fixture(); const base = f.server.transport('team');
  const remote = f.client('team', 'remote'); remote.put('note', 'old'); await remote.sync();
  const entered = deferred(); const release = deferred();
  const client = f.client('team', 'phone', {
    apply: op => base.apply(op),
    async pull(cursor) { const feed = await base.pull(cursor); entered.resolve(); await release.promise; return feed; },
  });
  const sync = client.sync(); await entered.promise;
  const edit = client.put('note', 'local');
  release.resolve(); await sync;
  // Equal-clock same-kind tie uses the README's device ordering.
  expect(client.get('note')).toBe('old');
  expect(client.pending()).toEqual([edit]);
  await client.sync();
  expect((await base.pull(0)).operations).toHaveLength(2);
  expect(client.pending()).toEqual([]);
});

test('identity names are opaque strings without filename length or separator constraints', async () => {
  const f = fixture(); const tenant = 'tenant/../:' + 't'.repeat(300);
  const device = 'device/../:' + 'd'.repeat(300);
  const client = f.client(tenant, device); client.put('note', 'value');
  await client.sync();
  expect(f.client(tenant, device).get('note')).toBe('value');
  expect(f.server.get(tenant, 'note')).toBe('value');
});
