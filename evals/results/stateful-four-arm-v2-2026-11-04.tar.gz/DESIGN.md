# Stateful four-arm benchmark v2

Owner request authorizes preparation, pilot, confirmatory execution and local reporting, no commit/push/publication. Shared checkout stays unchanged except new benchmark evidence and narrowly appended README results after final analysis.

Source decision: fetch requested 2026-11-03; latest origin/main 29ff9ac224ce94571320b1fbb3220e9ba078173c is evaluated verbatim. Initial local snapshot 46bf2267 retained. Local differences were reviewed: feature docs already upstream or superseded by selective-routing extraction; no hand-merged skill is evaluated. Explicit latest-remote steering selects this revision.

Architecture: fixture-specific Bun modules with persisted local state, public legacy/consumer sources, public smoke tests; hidden deterministic behavior/repair/recovery checks outside executor workspace. Four explicit-entry arms, same model requested Sol/medium, single agent, no automatic review workers; independent grading outside executor. Source snapshots readonly by protocol and verified hashes before/after. No global changes or credentials copied.

Plan:
1. Prepare four fixtures (requirements discovery, offline sync, migration, actual inter-session continuity), private truth and reference implementations.
2. Review oracles independently; verify buggy/reference outcomes. Operational pilot baseline requirements and continuity; record adjustments separately, never pool pilot.
3. Freeze canonical protocol, hashes, standardized owner packets, hidden tests, 4 scenarios x 4 conditions x 2 repetitions, 32 deliveries, 48 expected fresh CLI processes. Rotating arm order, sequential executor processes. Two repetitions are descriptive variation, not statistical equivalence.
4. Execute complete matrix; record every process wall duration, input/cache/output, commands and file state. Preserve timeouts/errors, no automatic retries, maximum 900 seconds per implementation session. Discovery phase max 240; preparation phase max 420.
5. Grade copy of final artifacts with hidden tests; adjudicate every material failure a second time in fresh context, labels/metrics hidden. Discovery questions evaluated separately from implementation after shared standardized owner answers.
6. Publish local reproducible fixture/protocol/controller/source inventory/results/report, preserve prior study; append README table only if evidence complete. Run required project validation.

Limits: installed CLI native model effective unobserved; internal host prompt not fully attestable; single host load/cache not controlled; same-provider independent grading is not double-blind; convenience authored corpus. No financial prices. Cached input subset, total=input+output. Preparation/controller/review excluded from executor costs, recorded separately when observable.
